"""
OS Guardian – Flask Application Entry Point
============================================
This module creates the Flask application, registers blueprints,
and defines top-level routes for the dashboard and all functional modules:
  - Dashboard
  - CPU Scheduling
  - Memory Allocation
  - Page Replacement
  - Deadlock Management (Banker's Algorithm)
  - Thread Synchronization (Producer-Consumer & Reader-Writer)
  - Simulation History (SQLite Persistence)
  - Performance Comparison

This is an educational simulator. All algorithm results are computed
by the simulator and do not represent real kernel operations.
"""

from flask import Flask, render_template, request, jsonify, send_file
from algorithms.cpu_scheduling import fcfs, sjf, priority_scheduling, round_robin
from algorithms.memory_management import first_fit, best_fit, worst_fit
from algorithms.page_replacement import fifo, lru, optimal
from algorithms.deadlock import bankers_safety, resource_request
from algorithms.synchronization import producer_consumer_demo, reader_writer_demo
from algorithms.comparison import compare_cpu_scheduling, compare_memory_allocation, compare_page_replacement
from algorithms.system_monitor import get_system_snapshot, detect_deadlock
from algorithms.export_utils import (
    export_system_snapshot_excel,
    export_deadlock_analysis_excel,
    export_comparison_excel,
    export_history_excel,
)
from database.db_utils import (
    save_simulation,
    get_all_simulations,
    get_simulation_by_id,
    delete_simulation,
    clear_all_simulations,
    get_simulation_counts,
    init_db,
)


def create_app():
    """Application factory. Returns a configured Flask app instance."""
    app = Flask(__name__)
    app.secret_key = "os-guardian-dev-key-change-in-production"

    # Initialize SQLite database tables on startup
    with app.app_context():
        init_db()

    # ------------------------------------------------------------------ #
    #  Dashboard                                                           #
    # ------------------------------------------------------------------ #

    @app.route("/")
    def index():
        """Dashboard – overview of all modules."""
        return render_template("index.html", active="dashboard")

    # ------------------------------------------------------------------ #
    #  CPU Scheduling                                                      #
    # ------------------------------------------------------------------ #

    @app.route("/scheduling", methods=["GET"])
    def scheduling():
        """CPU Scheduling module – GET renders the input form."""
        return render_template("scheduling.html", active="scheduling")

    @app.route("/scheduling/run", methods=["POST"])
    def scheduling_run():
        """
        CPU Scheduling – POST endpoint.
        Expects JSON body:
          {
            "algorithm": "fcfs" | "sjf" | "priority" | "rr",
            "quantum":   <int>   (required only for "rr"),
            "processes": [
              {"pid": str, "arrival_time": int, "burst_time": int, "priority": int},
              ...
            ]
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        algorithm = str(data.get("algorithm", "")).strip().lower()
        processes = data.get("processes", [])
        quantum = data.get("quantum", 1)

        if algorithm not in ("fcfs", "sjf", "priority", "rr"):
            return jsonify({"error": f"Unknown algorithm '{algorithm}'. Choose: fcfs, sjf, priority, rr."}), 400

        try:
            if algorithm == "fcfs":
                result = fcfs(processes)
            elif algorithm == "sjf":
                result = sjf(processes)
            elif algorithm == "priority":
                result = priority_scheduling(processes)
            else:  # rr
                result = round_robin(processes, quantum)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    # ------------------------------------------------------------------ #
    #  Memory Allocation                                                  #
    # ------------------------------------------------------------------ #

    @app.route("/memory", methods=["GET"])
    def memory():
        """Memory Allocation module – GET renders interactive simulator."""
        return render_template("memory.html", active="memory")

    @app.route("/memory/run", methods=["POST"])
    def memory_run():
        """
        Memory Allocation – POST endpoint.
        Expects JSON body:
          {
            "strategy": "first_fit" | "best_fit" | "worst_fit",
            "blocks": [int | {"id": str, "size": int}],
            "processes": [int | {"pid": str, "size": int}]
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        strategy = str(data.get("strategy", "")).strip().lower()
        blocks = data.get("blocks", [])
        processes = data.get("processes", [])

        if strategy not in ("first_fit", "best_fit", "worst_fit"):
            return jsonify({"error": f"Unknown strategy '{strategy}'. Choose: first_fit, best_fit, worst_fit."}), 400

        try:
            if strategy == "first_fit":
                result = first_fit(blocks, processes)
            elif strategy == "best_fit":
                result = best_fit(blocks, processes)
            else:
                result = worst_fit(blocks, processes)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    # ------------------------------------------------------------------ #
    #  Page Replacement                                                  #
    # ------------------------------------------------------------------ #

    @app.route("/paging", methods=["GET"])
    def paging():
        """Page Replacement module – GET renders interactive simulator."""
        return render_template("paging.html", active="paging")

    @app.route("/paging/run", methods=["POST"])
    def paging_run():
        """
        Page Replacement – POST endpoint.
        Expects JSON body:
          {
            "algorithm": "fifo" | "lru" | "optimal",
            "pages": [int | str] or comma/space-separated string,
            "num_frames": int
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        algo = str(data.get("algorithm", "")).strip().lower()
        pages = data.get("pages", [])
        num_frames = data.get("num_frames", 3)

        if algo not in ("fifo", "lru", "optimal"):
            return jsonify({"error": f"Unknown algorithm '{algo}'. Choose: fifo, lru, optimal."}), 400

        try:
            if algo == "fifo":
                result = fifo(pages, num_frames)
            elif algo == "lru":
                result = lru(pages, num_frames)
            else:
                result = optimal(pages, num_frames)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    # ------------------------------------------------------------------ #
    #  Deadlock Management (Banker's Algorithm)                           #
    # ------------------------------------------------------------------ #

    @app.route("/deadlock", methods=["GET"])
    def deadlock():
        """Deadlock Management – GET renders Banker's Algorithm simulator."""
        return render_template("deadlock.html", active="deadlock")

    @app.route("/deadlock/run", methods=["POST"])
    def deadlock_run():
        """
        Banker's Safety Algorithm – POST endpoint.
        Expects JSON body:
          {
            "allocation": [[int]],
            "maximum": [[int]],
            "available": [int],
            "process_names": [str] (optional),
            "resource_names": [str] (optional)
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        allocation = data.get("allocation")
        maximum = data.get("maximum")
        available = data.get("available")
        process_names = data.get("process_names")
        resource_names = data.get("resource_names")

        if allocation is None or maximum is None or available is None:
            return jsonify({"error": "Missing required fields: allocation, maximum, available."}), 400

        try:
            result = bankers_safety(allocation, maximum, available, process_names, resource_names)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    @app.route("/deadlock/request", methods=["POST"])
    def deadlock_request():
        """
        Banker's Resource-Request Algorithm – POST endpoint.
        Expects JSON body:
          {
            "allocation": [[int]],
            "maximum": [[int]],
            "available": [int],
            "process_index": int,
            "request_vector": [int],
            "process_names": [str] (optional),
            "resource_names": [str] (optional)
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        allocation = data.get("allocation")
        maximum = data.get("maximum")
        available = data.get("available")
        process_index = data.get("process_index")
        request_vector = data.get("request_vector")
        process_names = data.get("process_names")
        resource_names = data.get("resource_names")

        if allocation is None or maximum is None or available is None or process_index is None or request_vector is None:
            return jsonify({"error": "Missing required fields for resource request."}), 400

        try:
            result = resource_request(
                allocation, maximum, available, process_index, request_vector, process_names, resource_names
            )
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    # ------------------------------------------------------------------ #
    #  Thread Synchronization                                             #
    # ------------------------------------------------------------------ #

    @app.route("/synchronization", methods=["GET"])
    def synchronization():
        """Thread Synchronization – GET renders interactive simulations."""
        return render_template("synchronization.html", active="synchronization")

    @app.route("/synchronization/producer-consumer", methods=["POST"])
    def sync_producer_consumer():
        """
        Producer–Consumer simulation – POST endpoint.
        Expects JSON body:
          { "buffer_capacity": int, "num_items": int, "delay": float }
        """
        data = request.get_json(silent=True) or {}
        buffer_capacity = data.get("buffer_capacity", 5)
        num_items = data.get("num_items", 8)
        delay = data.get("delay", 0.002)

        try:
            result = producer_consumer_demo(
                buffer_capacity=int(buffer_capacity),
                num_items=int(num_items),
                delay=float(delay),
            )
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    @app.route("/synchronization/reader-writer", methods=["POST"])
    def sync_reader_writer():
        """
        Reader–Writer simulation – POST endpoint.
        Expects JSON body:
          { "num_readers": int, "num_writers": int, "operations_per_thread": int, "delay": float }
        """
        data = request.get_json(silent=True) or {}
        num_readers = data.get("num_readers", 3)
        num_writers = data.get("num_writers", 2)
        operations_per_thread = data.get("operations_per_thread", 2)
        delay = data.get("delay", 0.002)

        try:
            result = reader_writer_demo(
                num_readers=int(num_readers),
                num_writers=int(num_writers),
                operations_per_thread=int(operations_per_thread),
                delay=float(delay),
            )
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(result), 200

    # ------------------------------------------------------------------ #
    #  Simulation History (SQLite Persistence)                           #
    # ------------------------------------------------------------------ #

    @app.route("/history", methods=["GET"])
    def history():
        """Simulation History – GET renders the history table."""
        return render_template("history.html", active="history")

    @app.route("/history/records", methods=["GET"])
    def history_records():
        """Return JSON array of simulation records, optionally filtered by module."""
        module_filter = request.args.get("module", "").strip() or None
        records = get_all_simulations(module_type=module_filter)
        counts = get_simulation_counts()
        return jsonify({"records": records, "counts": counts}), 200

    @app.route("/history/view/<int:sim_id>", methods=["GET"])
    def history_view(sim_id):
        """Retrieve single simulation record details."""
        rec = get_simulation_by_id(sim_id)
        if not rec:
            return jsonify({"error": f"Simulation record #{sim_id} not found."}), 404
        return jsonify(rec), 200

    @app.route("/history/save", methods=["POST"])
    def history_save():
        """
        Save simulation run to SQLite.
        Expects JSON body:
          {
            "module_type": str,
            "algorithm": str,
            "parameters": object,
            "results": object,
            "summary_metrics": object,
            "summary_text": str (optional)
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        module_type = data.get("module_type") or data.get("module")
        algorithm = data.get("algorithm")
        parameters = data.get("parameters") if "parameters" in data else data.get("inputs", {})
        results = data.get("results", {})
        summary_metrics = data.get("summary_metrics") or data.get("metrics", {})
        summary_text = data.get("summary_text")

        if not module_type or not str(module_type).strip() or not algorithm or not str(algorithm).strip():
            return jsonify({"error": "module_type and algorithm are required."}), 400

        try:
            rec_id = save_simulation(
                module_type=str(module_type).strip(),
                algorithm=str(algorithm).strip(),
                parameters=parameters,
                results=results,
                summary_metrics=summary_metrics,
                summary_text=summary_text,
            )
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify({"status": "ok", "id": rec_id, "message": "Simulation saved to history."}), 201

    @app.route("/history/delete/<int:sim_id>", methods=["POST", "DELETE"])
    def history_delete(sim_id):
        """Delete single simulation record."""
        deleted = delete_simulation(sim_id)
        if not deleted:
            return jsonify({"error": f"Record #{sim_id} not found or could not be deleted."}), 404
        return jsonify({"status": "ok", "message": f"Record #{sim_id} deleted."}), 200

    @app.route("/history/clear", methods=["POST"])
    def history_clear():
        """Clear all simulation history or records for a specific module."""
        data = request.get_json(silent=True) or {}
        module_type = data.get("module_type")
        cleared_count = clear_all_simulations(module_type=module_type)
        return jsonify({"status": "ok", "cleared_count": cleared_count}), 200

    # ------------------------------------------------------------------ #
    #  Performance Comparison                                            #
    # ------------------------------------------------------------------ #

    @app.route("/comparison", methods=["GET"])
    def comparison():
        """Performance Comparison – GET renders comparative analytics view."""
        return render_template("comparison.html", active="comparison")

    @app.route("/comparison/run", methods=["POST"])
    def comparison_run():
        """
        Execute performance comparison across compatible algorithms for a given subsystem.
        Expects JSON body:
          {
            "subsystem": "cpu" | "memory" | "paging",
            "data": { ...subsystem specific parameters... }
          }
        """
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        subsystem = str(data.get("subsystem", "")).strip().lower()
        payload = data.get("data")
        if not isinstance(payload, dict):
            payload = data

        selected_algorithms = payload.get("selected_algorithms") or data.get("selected_algorithms")

        if subsystem not in ("cpu", "memory", "paging"):
            return jsonify({"error": f"Unknown subsystem '{subsystem}'. Choose: cpu, memory, paging."}), 400

        try:
            if subsystem == "cpu":
                processes = payload.get("processes", [])
                quantum = payload.get("quantum", 2)
                res = compare_cpu_scheduling(processes, quantum=quantum, selected_algorithms=selected_algorithms)
            elif subsystem == "memory":
                blocks = payload.get("blocks", [])
                processes = payload.get("processes", [])
                res = compare_memory_allocation(blocks, processes, selected_algorithms=selected_algorithms)
            else:  # paging
                pages = payload.get("pages") or payload.get("reference_string", [])
                num_frames = payload.get("num_frames") or payload.get("frame_count", 3)
                res = compare_page_replacement(pages, num_frames=int(num_frames), selected_algorithms=selected_algorithms)
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 422

        return jsonify(res), 200

    @app.route("/comparison/export", methods=["GET"])
    def comparison_export():
        """Export benchmark comparison results to Excel."""
        subsystem = request.args.get("subsystem", "cpu").lower().strip()
        if subsystem == "memory":
            res = compare_memory_allocation([100, 500, 200, 300, 600], [212, 417, 112, 426])
        elif subsystem == "paging":
            res = compare_page_replacement([7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1], num_frames=3)
        else:
            sample_procs = [
                {"pid": "P1", "arrival_time": 0, "burst_time": 6, "priority": 2},
                {"pid": "P2", "arrival_time": 1, "burst_time": 8, "priority": 1},
                {"pid": "P3", "arrival_time": 2, "burst_time": 7, "priority": 3},
                {"pid": "P4", "arrival_time": 3, "burst_time": 3, "priority": 4},
            ]
            res = compare_cpu_scheduling(sample_procs, quantum=2)

        bio = export_comparison_excel(res, subsystem=subsystem)
        return send_file(
            bio,
            as_attachment=True,
            download_name=f"os_guardian_{subsystem}_comparison.xlsx",
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    # ------------------------------------------------------------------ #
    #  System Monitor & Deadlock Detection                               #
    # ------------------------------------------------------------------ #

    @app.route("/system-monitor", methods=["GET"])
    def system_monitor():
        """System Monitor – Live Windows Telemetry and Deadlock Detection."""
        return render_template("system_monitor.html", active="system_monitor")

    @app.route("/system-monitor/snapshot", methods=["GET"])
    def system_monitor_snapshot():
        """Return real-time Windows host snapshot via psutil."""
        try:
            snapshot = get_system_snapshot(max_processes=50)
            return jsonify(snapshot), 200
        except Exception as exc:
            return jsonify({"error": f"Failed to sample host metrics: {str(exc)}"}), 500

    @app.route("/system-monitor/deadlock-detect", methods=["POST"])
    def system_monitor_deadlock_detect():
        """Execute multi-resource deadlock detection algorithm."""
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"error": "Invalid or empty JSON body."}), 400

        allocation = data.get("allocation", [])
        req_matrix = data.get("request", [])
        available = data.get("available", [])

        try:
            res = detect_deadlock(allocation, req_matrix, available)
            return jsonify(res), 200
        except (ValueError, TypeError) as exc:
            return jsonify({"error": str(exc)}), 422

    @app.route("/system-monitor/export", methods=["GET"])
    def system_monitor_export():
        """Export live system snapshot or deadlock analysis to Excel."""
        export_type = request.args.get("type", "snapshot").lower().strip()
        if export_type == "deadlock":
            analysis = detect_deadlock(
                [[0, 1, 0], [2, 0, 0], [3, 0, 3]],
                [[0, 0, 0], [2, 0, 2], [0, 0, 0]],
                [0, 0, 0],
            )
            bio = export_deadlock_analysis_excel(analysis)
            return send_file(
                bio,
                as_attachment=True,
                download_name="os_guardian_deadlock_analysis.xlsx",
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        else:
            snapshot = get_system_snapshot(max_processes=100)
            bio = export_system_snapshot_excel(snapshot)
            return send_file(
                bio,
                as_attachment=True,
                download_name="os_guardian_system_snapshot.xlsx",
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

    @app.route("/history/export", methods=["GET"])
    def history_export():
        """Export all saved simulation records to Excel."""
        module_filter = request.args.get("module")
        records = get_all_simulations(module_type=module_filter, limit=500)
        bio = export_history_excel(records)
        return send_file(
            bio,
            as_attachment=True,
            download_name="os_guardian_simulation_history.xlsx",
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    # ------------------------------------------------------------------ #
    #  Health check                                                        #
    # ------------------------------------------------------------------ #

    @app.route("/health")
    def health():
        """Health-check endpoint used by automated tests."""
        return {"status": "ok", "app": "OS Guardian"}, 200

    return app


# Run directly with `python app.py` (development only)
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="127.0.0.1", port=5000)
