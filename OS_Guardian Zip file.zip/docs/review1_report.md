# OS GUARDIAN: Intelligent Process, Memory & Resource Management Simulator
## Academic Project Report – Review I Evaluation

---

**Course Title:** Operating Systems Laboratory / Capstone Project  
**Course Code:** [Course Code, e.g., CSE2005 / CSED201P] *(To be filled by team)*  
**Project Title:** OS Guardian – Educational Process, Memory & Resource Management Simulator  
**Review Stage:** Review I (Problem Statement, Objectives, System Architecture, Core Prototype & Progress Evaluation)  
**Date of Submission:** October 2026  
**Document Classification:** Academic Project Documentation  

---

### Team Information & Module Division
- **Team Member 1:** [Student Name / Registration No. – CPU Scheduling Module Lead] *(To be filled by team)*  
- **Team Member 2:** [Student Name / Registration No. – Memory Management & Paging Lead] *(To be filled by team)*  
- **Team Member 3:** [Student Name / Registration No. – Deadlock, Synchronization & Database Lead] *(To be filled by team)*  

**Department:** Department of Computer Science & Engineering  
**Institution:** [University / College Name, e.g., Vellore Institute of Technology] *(To be filled by team)*  

---

## Executive Summary & Abstract

Operating Systems (OS) form the fundamental software abstraction layer managing hardware resources, process execution, and memory hierarchies. However, undergraduate OS education frequently suffers from a disconnect between abstract theoretical formulations and concrete dynamic execution models. Students frequently encounter cognitive friction when tracing non-preemptive versus preemptive CPU scheduling transitions, partition fragmentation accumulation, and lookahead versus historical stack behaviors in demand paging.

**OS Guardian** is an interactive, web-based educational simulator engineered to resolve this pedagogical challenge. Developed using Python, Flask, Bootstrap 5, and Chart.js, OS Guardian provides a high-fidelity visual laboratory where learners can configure workloads, inspect step-by-step state transitions, observe Gantt timelines and physical allocation maps, and evaluate algorithm trade-offs under identical workloads.

**Review I Status Overview:**  
- **Repository Verification:** 79 automated test cases passing with zero failures (`pytest 8.3.2`).
- **Implemented & Verified Core Modules:** 
  1. *Dashboard Architecture & Layout Framework* (Complete & Operational)
  2. *CPU Scheduling Engine* (FCFS, Non-Preemptive SJF, Non-Preemptive Priority, Round Robin with dynamic Chart.js horizontal Gantt timeline)
  3. *Contiguous Memory Allocation Engine* (First Fit, Best Fit, Worst Fit with physical block mapping and internal fragmentation metrics)
  4. *Demand Paging Engine* (FIFO, LRU, Belady's Optimal with step-by-step resident frame matrices, hit/fault badges, and eviction traces)
- **Defensible Implementation Progress:**
  - **Granular Requirements Completion:** **77.78%** (14 of 18 functional deliverables completed and verified).
  - **Milestone-Based Completion:** **66.67%** (4 of 6 primary technical development milestones complete).
  - Both metrics comfortably satisfy the Review I requirement (documented as 60–70% in faculty guidelines and 40–50% in VTOP upload instructions).
- **Scope Clarification:** OS Guardian is an algorithmic simulator designed for conceptual clarity and reproducible benchmarking; it does not claim to execute native kernel ring-0 operations.

---

## Table of Contents

1. [Problem Statement](#1-problem-statement)  
2. [Project Objectives](#2-project-objectives)  
3. [Literature Review & Theoretical Background](#3-literature-review--theoretical-background)  
4. [System Architecture & Design](#4-system-architecture--design)  
   - 4.1 High-Level Architecture  
   - 4.2 Module Separation & Implementation Status  
   - 4.3 Data Flow & API Contracts  
5. [Algorithm Specifications, Pseudocode & Flowcharts](#5-algorithm-specifications-pseudocode--flowcharts)  
   - 5.1 CPU Scheduling Engine (SJF & Round Robin Flowcharts)  
   - 5.2 Contiguous Memory Allocation Engine (Best Fit Flowchart)  
   - 5.3 Virtual Memory Page Replacement Engine (Optimal Flowchart)  
6. [Team Responsibilities & Work Division](#6-team-responsibilities--work-division)  
7. [Current Implementation & Prototype Demonstration](#7-current-implementation--prototype-demonstration)  
   - 7.1 Verified Operational Status  
   - 7.2 Core Module Execution Evidence & Screenshots  
8. [Automated Testing Strategy & Verification Results](#8-automated-testing-strategy--verification-results)  
9. [Defensible Implementation Progress Analysis](#9-defensible-implementation-progress-analysis)  
   - 9.1 Unified Functional Requirement Evaluation Matrix  
   - 9.2 Progress Computation & Resolution of Document Discrepancy  
10. [Known Limitations & Milestone Roadmap](#10-known-limitations--milestone-roadmap)  
11. [Conclusion](#11-conclusion)  
12. [References](#12-references)  
13. [Faculty Review Evaluation & Compliance Checklist](#13-faculty-review-evaluation--compliance-checklist)  

---

## 1. Problem Statement

Modern operating system kernels—such as Linux (Completely Fair Scheduler, Buddy Allocator) and Windows (NT Executive)—operate with immense complexity, preemptive interrupt handlers, and opaque scheduling queues. In conventional academic curricula:
1. **Lack of Visual Feedback:** Students perform algorithm traces (e.g., Round Robin time slicing, Belady’s anomaly, Best Fit fragmentation) manually on paper, leading to arithmetic mistakes and an inability to test complex edge cases (e.g., late arrivals, simultaneous arrivals, ties).
2. **Abstract Internal State:** The internal progression of page replacement matrices and fragmentation accumulation cannot be observed in real time on production operating systems without intrusive kernel debugging tools.
3. **Absence of Unified Comparative Environments:** Existing standalone web tools are either fragmented, outdated, or hardcoded with pre-canned demonstration values rather than true dynamic solvers.

**Problem Definition:**  
There is an acute need for a robust, modular, reproducible, and interactive software laboratory simulator that accepts arbitrary user workloads, computes exact theoretical state transitions across core OS subsystems (CPU scheduling, contiguous memory partitioning, and demand paging), visually plots timeline and allocation diagrams, and provides verifiable algorithmic outputs for academic inspection.

---

## 2. Project Objectives

OS Guardian is built around five specific, measurable, achievable, relevant, and time-bound (SMART) objectives:

1. **Objective 1 (CPU Scheduling Simulation):** Develop a modular scheduling solver supporting First Come First Served (FCFS), Shortest Job First (SJF, non-preemptive), Priority Scheduling (non-preemptive), and Round Robin (configurable quantum). Compute exact Completion Time ($CT$), Turnaround Time ($TAT$), Waiting Time ($WT$), Response Time ($RT$), and CPU Utilization metrics while handling simultaneous arrivals and idle gaps.
2. **Objective 2 (Gantt Visualization):** Integrate a responsive, horizontal timeline visualization utilizing Chart.js to clearly delineate process execution windows, context-switch boundaries, and CPU idle intervals.
3. **Objective 3 (Memory Partitioning Simulation):** Implement First Fit, Best Fit, and Worst Fit contiguous memory allocation strategies under a single unified model. Visualize physical block occupancy, identify unallocated requests, and quantify exact internal fragmentation.
4. **Objective 4 (Demand Paging Simulator):** Implement FIFO, LRU, and Belady's Optimal page replacement algorithms. Render a complete step-by-step matrix tracking frame residency, distinguishing hits from faults, and calculating hit/fault percentages.
5. **Objective 5 (Software Engineering Rigor):** Establish a clean model-view-controller (MVC) architecture using Python and Flask, back the algorithms with a comprehensive automated test suite ($>75$ unit and integration tests), enforce parameterized data handling, and prepare a verifiable progress report for university evaluation.

---

## 3. Literature Review & Theoretical Background

The algorithms and theoretical models implemented in OS Guardian are grounded in classical operating systems literature and seminal computer science publications:

1. **CPU Scheduling Foundations:**  
   Silberschatz, Galvin, and Gagne (2018) delineate the fundamental objectives of CPU scheduling: maximizing CPU utilization and throughput while minimizing turnaround time, waiting time, and response time. They establish that while non-preemptive SJF provides the theoretical minimum average waiting time for a set of stationary processes, it is susceptible to starvation when short bursts arrive continuously. Tanenbaum and Bos (2015) formalize the Round Robin algorithm with time quantum $q$, showing that if $q$ is exceedingly large, Round Robin degenerates into FCFS; if $q$ is too small, context-switch overhead dominates.
2. **Memory Allocation & Fragmentation:**  
   Knuth (1997) and Stallings (2018) analyze contiguous storage allocation strategies:
   - *First Fit:* Allocates the first available partition whose capacity $B \ge P$. Demonstrated by Knuth to be computationally fast and empirically effective.
   - *Best Fit:* Searches the entire list to locate the block minimizing $(B - P)$. While intuitive, Shore (1975) demonstrated that Best Fit often generates numerous small, unusable fragments.
   - *Worst Fit:* Allocates the block maximizing $(B - P)$, theoretically leaving larger remaining partitions, but rapidly depleting large blocks required by incoming larger processes.
3. **Demand Paging & Belady's Anomaly:**  
   Belady (1966) introduced the Optimal page replacement policy (MIN), which evicts the page whose next access is furthest in the future, providing an absolute theoretical lower bound on page faults for any offline reference string. Belady, Nelson, and Shedler (1969) proved that FIFO suffers from *Belady's Anomaly*—a phenomenon where increasing the physical frame capacity can paradoxically increase total page fault count for certain reference patterns. Denning (1970) established the working set model, demonstrating that LRU approximates Optimal behavior by relying on the principle of temporal locality.

---

## 4. System Architecture & Design

### 4.1 High-Level Architecture

OS Guardian adheres to a clean, decoupled Model-View-Controller (MVC) pattern adapted for web application deployment, separating user interaction, HTTP route handling, pure algorithm solvers, and data persistence:

```
+-----------------------------------------------------------------------------------------+
|                                    CLIENT BROWSER LAYER                                 |
|      HTML5  |  Bootstrap 5.3  |  Bootstrap Icons  |  Chart.js 4.4.3  |  Vanilla JS      |
|   - Dynamic Process Input Tables (PID, Arrival, Burst, Priority)                        |
|   - Interactive Memory Block Configuration & Physical Allocation Diagram                |
|   - Demand Paging Reference String Presets & Resident Frame Matrix                      |
|   - Horizontal Floating-Bar Gantt Canvas (Chart.js Horizontal Category Axis)            |
+--------------------------------------------+--------------------------------------------+
                                             | HTTP GET / POST (JSON API)
                                             v
+-----------------------------------------------------------------------------------------+
|                               FLASK WEB CONTROLLER LAYER                                |
|                                  (app.py - Port 5000)                                   |
|   Web UI Routes (GET):                   JSON Simulation Endpoints (POST):              |
|     /            -> Dashboard View         /scheduling/run -> CPU Dispatcher            |
|     /scheduling  -> Scheduling View        /memory/run     -> Memory Dispatcher         |
|     /memory      -> Memory View            /paging/run     -> Paging Dispatcher         |
|     /paging      -> Paging View            /health         -> Health Status Check       |
+--------------------+-----------------------------------------------+--------------------+
                     |                                               |
                     | Dispatch Requests                             | Planned DB Hook
                     v                                               v
+-------------------------------------------------+  +------------------------------------+
|             MODEL LAYER: PURE PYTHON            |  |         PERSISTENCE LAYER          |
|                 ALGORITHM ENGINES               |  |       [PLANNED - MILESTONE 6]      |
|                                                 |  |                                    |
|  [IMPLEMENTED & TESTED - 79 TESTS]              |  |   SQLite Database (database/db.py) |
|  ├── algorithms/cpu_scheduling.py               |  |   - Simulation Run History         |
|  │   ├── FCFS                                   |  |   - Parameterized Schema           |
|  │   ├── Shortest Job First (Non-preemptive)    |  |   - Comparative Multi-Run Logs     |
|  │   ├── Priority (Non-preemptive)              |  +------------------------------------+
|  │   └── Round Robin (Time-sliced)              |
|  ├── algorithms/memory_management.py            |
|  │   ├── First Fit Strategy                     |
|  │   ├── Best Fit Strategy                      |
|  │   ├── Worst Fit Strategy                     |
|  │   └── Internal Fragmentation Accounting      |
|  └── algorithms/page_replacement.py             |
|      ├── FIFO (First In First Out)              |
|      ├── LRU (Least Recently Used)              |
|      └── Optimal (Belady's Min Algorithm)       |
|                                                 |
|  [PLANNED - MILESTONE 5]                        |
|  ├── algorithms/deadlock.py (Banker's Safety)   |
|  └── algorithms/synchronization.py (Semaphores) |
+-------------------------------------------------+
```

### 4.2 Module Separation & Implementation Status

| Architectural Layer | Implementation Component | File Path | Status | Verification Evidence |
|---|---|---|---|---|
| **View (UI Templates)** | Base layout, sidebar, navbar | `templates/base.html` | ✅ Verified Active | Browser inspection & route tests |
| **View (UI Templates)** | Dashboard overview & cards | `templates/index.html` | ✅ Verified Active | `GET /` returns HTTP 200 |
| **View (UI Templates)** | Scheduling UI & Gantt container | `templates/scheduling.html` | ✅ Verified Active | `GET /scheduling` returns HTTP 200 |
| **View (UI Templates)** | Memory block layout & input table | `templates/memory.html` | ✅ Verified Active | `GET /memory` returns HTTP 200 |
| **View (UI Templates)** | Frame matrix & reference input | `templates/paging.html` | ✅ Verified Active | `GET /paging` returns HTTP 200 |
| **View (UI Templates)** | Deadlock, Sync, History stubs | `templates/*.html` | ⏳ Stubs Active | HTTP 200 placeholder templates |
| **Client Logic (JS)** | Horizontal Gantt chart via Chart.js | `static/js/scheduling.js` | ✅ Verified Active | Chart.js 4.4.3 floating-bar rendering |
| **Client Logic (JS)** | Memory block diagram & table | `static/js/memory.js` | ✅ Verified Active | Physical block proportion rendering |
| **Client Logic (JS)** | Step matrix rendering & hit badges | `static/js/paging.js` | ✅ Verified Active | Dynamic hit/miss matrix injection |
| **Controller (Flask)** | Application factory & REST routes | `app.py` | ✅ Verified Active | 20 passing route tests in `test_routes.py` |
| **Model (Algorithms)** | CPU scheduling (FCFS, SJF, Pri, RR) | `algorithms/cpu_scheduling.py` | ✅ Verified Active | 36 passing unit tests in `test_cpu_scheduling.py` |
| **Model (Algorithms)** | Memory allocation (FF, BF, WF) | `algorithms/memory_management.py` | ✅ Verified Active | 11 passing unit tests in `test_memory.py` |
| **Model (Algorithms)** | Demand paging (FIFO, LRU, OPT) | `algorithms/page_replacement.py` | ✅ Verified Active | 12 passing unit tests in `test_paging.py` |
| **Model (Algorithms)** | Banker's Safety Algorithm | `algorithms/deadlock.py` | ⏳ Planned M5 | Interface stub defined |
| **Model (Algorithms)** | Thread synchronization demos | `algorithms/synchronization.py` | ⏳ Planned M5 | Interface stub defined |
| **Persistence (DB)** | SQLite simulation history storage | `database/db_utils.py` | ⏳ Planned M6 | Package stub defined |

### 4.3 Data Flow & API Contracts

All simulated algorithms are exposed via parameterized JSON endpoints:
- `POST /scheduling/run`: Accepts JSON payload `{"algorithm": str, "quantum": int, "processes": [{"pid": str, "arrival_time": int, "burst_time": int, "priority": int}]}`. Returns computed Gantt segments, process metric records, and summary averages.
- `POST /memory/run`: Accepts `{"strategy": str, "blocks": [{"id": str, "size": int}], "processes": [{"pid": str, "size": int}]}`. Returns per-process allocation outcomes, remaining block capacities, and total internal fragmentation.
- `POST /paging/run`: Accepts `{"algorithm": str, "num_frames": int, "pages": [int]}`. Returns step-by-step frame residency arrays, hit/fault badges, eviction victims, and hit/fault percentages.

---

## 5. Algorithm Specifications, Pseudocode & Flowcharts

### 5.1 CPU Scheduling Engine

#### Mathematical Metric Formulations
For each process $P_i$ with Arrival Time $AT_i$, Burst Time $BT_i$, Completion Time $CT_i$, and First Start Time $ST_i$:
- **Turnaround Time ($TAT_i$):** $TAT_i = CT_i - AT_i$
- **Waiting Time ($WT_i$):** $WT_i = TAT_i - BT_i$
- **Response Time ($RT_i$):** $RT_i = ST_i - AT_i$
- **Makespan ($M$):** $M = \max(CT) - \min(AT)$
- **CPU Utilization:** $\text{Utilization} = \left( \frac{\sum BT_i}{M} \right) \times 100\%$

#### Pseudocode: Round Robin (RR)
```text
Algorithm RoundRobin(processes, quantum):
    Input: processes list with pid, arrival_time, burst_time; positive integer quantum
    Output: timeline gantt, per-process metrics, aggregate metrics
    
    1. Sort processes by arrival_time ASC, then pid ASC
    2. Initialize current_time = first process arrival_time
    3. Initialize ready_queue = [], arrived_set = set(), completion_map = {}, start_map = {}
    
    4. Enqueue all processes where arrival_time <= current_time into ready_queue
    5. While ready_queue is not empty OR any process remaining uncompleted:
         If ready_queue is empty:
             next_arrival = min(arrival_time of remaining processes)
             Record IDLE segment from current_time to next_arrival
             current_time = next_arrival
             Enqueue all processes arriving at current_time
             Continue
         
         proc = ready_queue.pop(0)
         If proc.pid not in start_map:
             start_map[proc.pid] = current_time
             
         slice_time = min(quantum, proc.remaining_burst)
         Record Gantt segment [proc.pid, current_time, current_time + slice_time]
         proc.remaining_burst -= slice_time
         current_time += slice_time
         
         // CRITICAL: Enqueue newly arrived processes BEFORE re-queuing preempted process
         Enqueue any process arriving at or before current_time not yet in arrived_set
         
         If proc.remaining_burst == 0:
             completion_map[proc.pid] = current_time
         Else:
             ready_queue.append(proc)
             
    6. Compute TAT, WT, RT, and CPU Utilization for all processes
    7. Return gantt, results table, and summary metrics
```

#### Flowchart 1: Non-Preemptive SJF Scheduling
```
        +-----------------------------------+
        |       Start SJF Simulation        |
        +-----------------+-----------------+
                          |
                          v
        +-----------------------------------+
        |    Validate Inputs (AT >= 0,      |
        |    BT > 0) & Sort by AT, PID      |
        +-----------------+-----------------+
                          |
                          v
        +-----------------------------------+
        |       Set current_time = 0        |
        +-----------------+-----------------+
                          |
                          v
+------>+-----------------------------------+
|       | Any uncompleted processes remain? |
|       +--------+------------------+-------+
|               YES                 NO
|                |                  |
|                v                  v
|       +-------------------+   +----------------------------+
|       | Filter processes  |   | Compute aggregate metrics  |
|       | with AT <= curr_t |   | (Avg TAT, Avg WT, Avg RT,  |
|       +--------+----------+   | CPU Utilization %)         |
|                |              +--------------+-------------+
|        +-------+-------+                     |
|       YES             NO                     v
|        |               |              +--------------+
|        |               v              | Return JSON  |
|        |     +--------------------+   +--------------+
|        |     | Advance curr_time  |
|        |     | to next arrival    |
|        |     | (Record IDLE bar)  |
|        |     +---------+----------+
|        |               |
|        v               |
|   +--------------------+----------+
|   | Select process with min(BT);  |
|   | Tie-breaker: min(AT), min(PID)|
|   +--------------------+----------+
|                        |
|                        v
|   +-------------------------------+
|   | Run to completion:            |
|   | start_time = curr_time        |
|   | curr_time += BT               |
|   | CT = curr_time; TAT = CT - AT |
|   | WT = TAT - BT; RT = ST - AT   |
|   | Append to Gantt timeline      |
|   +--------------------+----------+
|                        |
+------------------------+
```

#### Flowchart 2: Round Robin Scheduling
```
        +-----------------------------------+
        |       Start Round Robin (RR)      |
        +-----------------+-----------------+
                          |
                          v
        +-----------------------------------+
        | Validate quantum > 0, AT, BT.     |
        | Sort by AT, PID. curr_t = min(AT) |
        +-----------------+-----------------+
                          |
                          v
+------>+-----------------------------------+
|       | ready_queue empty AND uncompleted?|
|       +--------+------------------+-------+
|               YES                 NO
|                |                  |
|                v                  v
|       +-------------------+   +----------------------------+
|       | Advance curr_time |   | Are all processes complete?|
|       | to next arrival   |   +--------+-------------------+
|       | (Record IDLE)     |           YES                 NO
|       +--------+----------+            |                  |
|                |                       v                  v
|                +------------> +-----------------+   +-----+----+
|                               | Return complete |   | Pop proc |
|                               | results & Gantt |   | from queue|
|                               +-----------------+   +-----+----+
|                                                           |
|       +---------------------------------------------------+
|       v
|   +-------------------------------------------------------+
|   | slice = min(quantum, remaining_burst)                 |
|   | Record Gantt segment [proc, curr_t, curr_t + slice]   |
|   | remaining_burst -= slice; curr_t += slice             |
|   +---------------------------+---------------------------+
|                               |
|                               v
|   +-------------------------------------------------------+
|   | Enqueue all newly arrived processes (AT <= curr_t)    |
|   +---------------------------+---------------------------+
|                               |
|                               v
|   +-------------------------------------------------------+
|   | Did proc finish? (remaining_burst == 0)               |
|   +------------+------------------------------+-----------+
|               YES                             NO
|                |                               |
|                v                               v
|   +---------------------------+   +-----------------------+
|   | Record CT = curr_time;    |   | Re-enqueue proc to    |
|   | Mark process complete     |   | back of ready_queue   |
|   +------------+--------------+   +-----------+-----------+
|                |                              |
+----------------+------------------------------+
```

---

### 5.2 Contiguous Memory Allocation Engine

#### Strategy Formulations & Invariants
- Let $B = \{b_1, b_2, \dots, b_m\}$ be physical memory blocks with sizes $S(b_j)$.
- Let $P = \{p_1, p_2, \dots, p_n\}$ be incoming process requests with sizes $R(p_i)$.
- Each partition hosts at most one process (fixed contiguous partition model).
- **First Fit:** Finds index $j = \min \{ k \mid b_k \text{ is free and } S(b_k) \ge R(p_i) \}$.
- **Best Fit:** Finds index $j = \arg\min_{k} \{ (S(b_k) - R(p_i)) \mid b_k \text{ is free and } S(b_k) \ge R(p_i) \}$. Ties broken by earliest block index.
- **Worst Fit:** Finds index $j = \arg\max_{k} \{ (S(b_k) - R(p_i)) \mid b_k \text{ is free and } S(b_k) \ge R(p_i) \}$. Ties broken by earliest block index.
- **Internal Fragmentation:** If allocated, $\text{Frag}(b_j) = S(b_j) - R(p_i)$. Unallocated processes produce 0 internal fragmentation.

#### Flowchart 3: Best Fit Memory Allocation
```
        +-----------------------------------+
        |       Start Best Fit Engine       |
        +-----------------+-----------------+
                          |
                          v
        +-----------------------------------+
        | Validate Block sizes > 0, Proc > 0|
        | Initialize blocks as FREE         |
        +-----------------+-----------------+
                          |
                          v
+------>+-----------------------------------+
|       | For next process P_i in requests: |
|       +--------+------------------+-------+
|            HAS PROCESS           FINISHED
|                |                  |
|                v                  v
|       +-------------------+   +----------------------------+
|       | Scan all blocks.  |   | Compute total allocated,   |
|       | Find free blocks  |   | total internal frag,       |
|       | with S(B) >= R(P) |   | memory utilization %       |
|       +--------+----------+   +--------------+-------------+
|                |                             |
|        +-------+-------+                     v
|    CANDIDATES      NO CANDIDATES      +--------------+
|     FOUND              FOUND          | Return JSON  |
|        |                 |            +--------------+
|        |                 v
|        |       +--------------------+
|        |       | Mark P_i as        |
|        |       | UNALLOCATED        |
|        |       +---------+----------+
|        v                 |
|   +----------------------+--------+
|   | Choose candidate with         |
|   | MINIMUM remainder (S(B) - R(P))|
|   | Tie-breaker: earliest block ID|
|   +----------------------+--------+
|                          |
|                          v
|   +-------------------------------+
|   | Assign block to P_i           |
|   | Frag = S(B) - R(P)            |
|   | Mark block as OCCUPIED        |
|   +----------------------+--------+
|                          |
+--------------------------+
```

---

### 5.3 Virtual Memory Page Replacement Engine

#### Flowchart 4: Belady's Optimal Page Replacement
```
        +-----------------------------------+
        |    Start Belady's Optimal Engine  |
        +-----------------+-----------------+
                          |
                          v
        +-----------------------------------+
        | Input: reference string R[1..N],  |
        | num_frames > 0. frames = []       |
        +-----------------+-----------------+
                          |
                          v
+------>+-----------------------------------+
|       | For step_idx from 0 to N-1:       |
|       +--------+------------------+-------+
|            HAS REFS              COMPLETED
|                |                  |
|                v                  v
|       +-------------------+   +----------------------------+
|       | Page in frames?   |   | Compute total hits, faults,|
|       +---+-----------+---+   | page fault ratio %         |
|          YES          NO      +--------------+-------------+
|           |           |                      |
|           v           v                      v
|      +--------+  +---------+          +--------------+
|      | Record |  | Record  |          | Return JSON  |
|      |  HIT   |  |  FAULT  |          +--------------+
|      +----+---+  +----+----+
|           |           |
|           |     +-----+-----+
|           |     | Free frame|
|           |     | available?|
|           |     +--+-----+--+
|           |       YES    NO
|           |        |      |
|           |        v      v
|           |  +-------+  +---------------------------------+
|           |  | Append|  | Look ahead in R[step_idx+1..N]: |
|           |  | page  |  | Find resident frame whose next  |
|           |  | to    |  | use is furthest in future       |
|           |  | frames|  | (or never referenced again).    |
|           |  +---+---+  | Replace victim with page.       |
|           |      |      +----------------+----------------+
|           |      |                       |
|           v      v                       v
|       +------------------------------------+
|       | Save step snapshot: current frames,|
|       | hit/miss flag, evicted victim page |
|       +------------------+-----------------+
|                          |
+--------------------------+
```

---

## 6. Team Responsibilities & Work Division

OS Guardian is structured across a three-member student team in accordance with faculty project guidelines:

| Team Member | Module Responsibilities | Implemented & Verified Components (Review I) | Planned Components (Review II & Final) |
|---|---|---|---|
| **Member 1** *(CPU Scheduling Lead)* | **CPU Scheduling Engine & Visualizations** | - FCFS, SJF, Priority, Round Robin algorithms<br>- Chart.js floating-bar Gantt chart canvas<br>- Non-preemptive & preemptive queue solvers<br>- 36 automated unit & timeline test cases | - Comparative scheduling benchmark graphs<br>- Multi-level Feedback Queue (MLFQ) extension |
| **Member 2** *(Memory & Paging Lead)* | **Memory Management & Virtual Paging** | - First Fit, Best Fit, Worst Fit placement<br>- Internal fragmentation accounting<br>- Demand Paging (FIFO, LRU, Optimal)<br>- Step-by-step frame matrix visualization<br>- 23 automated memory & paging test cases | - Inverted page table / segmentation concepts<br>- Page fault vs. frame count anomaly charts |
| **Member 3** *(Deadlock, Sync & DB Lead)* | **Deadlock, Synchronization & Persistence** | - Flask MVC application scaffold & routing<br>- Base templates & sidebar navigation<br>- Application health monitoring & JSON schemas<br>- 20 automated integration & route tests | - Banker's Safety & Resource Request Algorithm<br>- Thread synchronization (Producer-Consumer, Reader-Writer)<br>- SQLite simulation history & run archival |

*Shared Team Responsibilities:* System integration, continuous automated test suite execution, faculty review documentation, report authoring, and viva voce presentation preparation.

---

## 7. Current Implementation & Prototype Demonstration

### 7.1 Verified Operational Status
The OS Guardian prototype is currently active and fully executable under the local Python 3.12 virtual environment at `http://127.0.0.1:5000`.

### 7.2 Core Module Execution Evidence & Screenshots

All screenshots presented below are authentic captures from the live, running OS Guardian application executing in the evaluation environment.

#### 1. Dashboard Module Overview (`/`)
The dashboard provides unified navigation across all OS Guardian modules, displaying live system health and operational badges.

![Figure 1: OS Guardian Dashboard Interface](screenshots/dashboard.png)  
*Figure 1: OS Guardian Dashboard Interface displaying live system status, navigation sidebar, and functional module cards.*

#### 2. CPU Scheduling Module (`/scheduling`)
- **Workload:** $P_1(AT=0, BT=8), P_2(AT=1, BT=4), P_3(AT=2, BT=9), P_4(AT=3, BT=5)$.
- **Empirical Execution Metrics:**
  - Gantt Timeline: $P_1[0 \to 8], P_2[8 \to 12], P_3[12 \to 21], P_4[21 \to 26]$.
  - Turnaround Times: $P_1=8, P_2=11, P_3=19, P_4=23$ (Average TAT: **15.25**).
  - Waiting Times: $P_1=0, P_2=7, P_3=10, P_4=18$ (Average WT: **8.75**).
  - Response Times: $P_1=0, P_2=7, P_3=10, P_4=18$ (Average RT: **8.75**).
  - CPU Utilization: **100.0%** (Makespan = 26, Total Burst = 26).

![Figure 2: CPU Scheduling Interface with Gantt Chart](screenshots/scheduling.png)  
*Figure 2: CPU Scheduling Interface showing active FCFS simulation, Chart.js horizontal Gantt timeline, metric summary cards, and process results table.*

#### 3. Memory Allocation Module (`/memory`)
- **Workload:** Blocks = $[100, 500, 200, 300, 600]$ KB; Requests = $P_1(212), P_2(417), P_3(112), P_4(426)$ KB.
- **First Fit Execution Metrics:**
  - $P_1 \to B_2(500)$ [Frag: 288 KB], $P_2 \to B_5(600)$ [Frag: 183 KB], $P_3 \to B_3(200)$ [Frag: 88 KB].
  - $P_4(426)$ cannot fit into remaining free blocks ($B_1=100, B_4=300$) $\implies$ **Unallocated**.
  - Total Allocated: **741 KB** across 3 processes. Total Internal Fragmentation: **559 KB**. Memory Utilization: **43.59%**.

![Figure 3: Memory Allocation Interface](screenshots/memory.png)  
*Figure 3: Contiguous Memory Allocation Interface displaying First Fit placement, physical block diagram with internal fragmentation indicators, and summary metrics.*

#### 4. Page Replacement Module (`/paging`)
- **Workload:** Reference sequence: `7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2` (13 references) across 3 frames.
- **FIFO Execution Metrics:**
  - Total References: 13 | Page Faults: 10 | Page Hits: 3 | Fault Ratio: **76.92%**.
  - Renders step-by-step frame contents, color-coded red FAULT and green HIT badges, and evicted victim tracking.

![Figure 4: Page Replacement Interface](screenshots/paging.png)  
*Figure 4: Virtual Memory Page Replacement Interface displaying FIFO simulation, resident frame snapshot matrix, color-coded Hit/Fault badges, and eviction history.*

---

## 8. Automated Testing Strategy & Verification Results

### 8.1 Test Structure
The automated test suite is constructed under `pytest 8.3.2` and `pytest-flask 1.3.0`, structured into four dedicated suites:

```
tests/
├── conftest.py               # Application fixtures & test client setup
├── test_routes.py            # Route smoke tests, 404 handlers, POST JSON API tests (20 tests)
├── test_cpu_scheduling.py    # FCFS, SJF, Priority, RR, validation, timeline integrity (36 tests)
├── test_memory.py            # First/Best/Worst Fit, exact fit, unallocated, validation (11 tests)
└── test_paging.py            # FIFO, LRU, Optimal, Belady's anomaly, edge cases (12 tests)
```

### 8.2 Execution Evidence (79 / 79 Passing)

| Test Module | Test Cases Run | Failures | Status | Execution Time |
|---|---|---|---|---|
| `tests/test_cpu_scheduling.py` | 36 | 0 | PASSED | 0.28s |
| `tests/test_memory.py` | 11 | 0 | PASSED | 0.08s |
| `tests/test_paging.py` | 12 | 0 | PASSED | 0.09s |
| `tests/test_routes.py` | 20 | 0 | PASSED | 0.15s |
| **Total Test Suite** | **79** | **0** | **ALL PASSED** | **0.66s** |

All tests pass cleanly without regressions, warnings, or mock data dependencies.

---

## 9. Defensible Implementation Progress Analysis

### 9.1 Unified Functional Requirement Evaluation Matrix

To establish complete transparency and eliminate any ambiguity, all deliverables of the OS Guardian project are consolidated into a single, unified matrix of 18 unique requirements across the 7 functional modules:

| # | Subsystem / Requirement | Planned Deliverable | Implementation Status | Verified Evidence | Earned Weight (Max: 100) |
|---|---|---|---|---|---|
| 1 | **Dashboard UI Framework** | Responsive Bootstrap 5 layout, sidebar, system health | ✅ Complete & Active | `templates/base.html`, `index.html` | **5.56 / 5.56** |
| 2 | **FCFS Scheduling Engine** | Non-preemptive arrival/burst calculation, metrics | ✅ Complete & Tested | `algorithms/cpu_scheduling.py` (9 tests) | **5.56 / 5.56** |
| 3 | **SJF Scheduling Engine** | Non-preemptive shortest job selection with tie-breaking | ✅ Complete & Tested | `algorithms/cpu_scheduling.py` (8 tests) | **5.56 / 5.56** |
| 4 | **Priority Scheduling Engine**| Non-preemptive priority ranking (lower = higher priority)| ✅ Complete & Tested | `algorithms/cpu_scheduling.py` (7 tests) | **5.56 / 5.56** |
| 5 | **Round Robin Scheduling Engine**| Sliced queue execution with configurable quantum | ✅ Complete & Tested | `algorithms/cpu_scheduling.py` (8 tests) | **5.56 / 5.56** |
| 6 | **Gantt Chart Visualization** | Horizontal floating-bar canvas via Chart.js, idle periods | ✅ Complete & Active | `static/js/scheduling.js` | **5.56 / 5.56** |
| 7 | **First Fit Allocation** | First partition placement & fragmentation accounting | ✅ Complete & Tested | `algorithms/memory_management.py` (4 tests) | **5.56 / 5.56** |
| 8 | **Best Fit Allocation** | Smallest remainder placement & unallocated tracing | ✅ Complete & Tested | `algorithms/memory_management.py` (4 tests) | **5.56 / 5.56** |
| 9 | **Worst Fit Allocation** | Largest remainder placement & block utilization | ✅ Complete & Tested | `algorithms/memory_management.py` (3 tests) | **5.56 / 5.56** |
| 10 | **Memory Allocation Diagram** | Physical block diagram with internal frag indicators | ✅ Complete & Active | `static/js/memory.js` | **5.56 / 5.56** |
| 11 | **FIFO Page Replacement** | Demand paging with eviction sequence & fault ratio | ✅ Complete & Tested | `algorithms/page_replacement.py` (4 tests) | **5.56 / 5.56** |
| 12 | **LRU Page Replacement** | Least recently used stack with hit/fault tracking | ✅ Complete & Tested | `algorithms/page_replacement.py` (4 tests) | **5.56 / 5.56** |
| 13 | **Optimal Replacement (OPT)**| Belady's clairvoyant lookahead replacement algorithm | ✅ Complete & Tested | `algorithms/page_replacement.py` (4 tests) | **5.56 / 5.56** |
| 14 | **Page Frame Matrix View** | Step snapshot matrix with color-coded badges & victims | ✅ Complete & Active | `static/js/paging.js` | **5.56 / 5.56** |
| 15 | **Deadlock Management** | Banker's Safety & Resource Request Algorithm | ⏳ Planned (Milestone 5) | `algorithms/deadlock.py` stub | **0.00 / 5.56** |
| 16 | **Thread Synchronization** | Producer-Consumer & Reader-Writer demonstrations | ⏳ Planned (Milestone 5) | `algorithms/synchronization.py` stub | **0.00 / 5.56** |
| 17 | **Database Persistence** | SQLite simulation history & workload archival | ⏳ Planned (Milestone 6) | `database/db_utils.py` stub | **0.00 / 5.56** |
| 18 | **Performance Comparison UI**| Multi-run comparative performance graphs | ⏳ Planned (Milestone 6) | Planned UI view | **0.00 / 5.56** |

### 9.2 Progress Computation & Resolution of Document Discrepancy

#### Mathematical Progress Formulations:
1. **Granular Functional Deliverables Progress:**
   $$\text{Progress}_{\text{Functional}} = \frac{14 \text{ Completed Deliverables}}{18 \text{ Total Planned Deliverables}} \times 100\% = \mathbf{77.78\%}$$

2. **Milestone-Based Engineering Progress:**
   The project roadmap comprises 6 technical milestones:
   - Milestone 1: Environment & Tooling Verification (Completed: 100%)
   - Milestone 2: Project Scaffold & Dashboard (Completed: 100%)
   - Milestone 3: CPU Scheduling & Gantt Visualization (Completed: 100%)
   - Milestone 4: Memory Management & Demand Paging (Completed: 100%)
   - Milestone 5: Deadlock Management & Thread Synchronization (Planned: 0%)
   - Milestone 6: SQLite Persistence & Comparative Analytics (Planned: 0%)
   $$\text{Progress}_{\text{Milestones}} = \frac{4 \text{ Completed Milestones}}{6 \text{ Core Technical Milestones}} \times 100\% = \mathbf{66.67\%}$$

#### Faculty Guideline Discrepancy Note & Recommendation:
> [!IMPORTANT]
> **Faculty Guideline Discrepancy Notice:**  
> In the official course project documentation (`VL2026270102301_AST07.pdf`), an explicit discrepancy exists between two sections:
> - **Page 2 under "Review I Guidelines":** Stated requirement is *"At least 60–70% implementation completed"*.
> - **Page 3 under "VTOP Upload Description for Review-I":** Stated requirement is *"implementation progress (40–50%)"*.
>
> **Student Advisory:**  
> Rather than choosing an arbitrary interpretation, the project team explicitly highlights this discrepancy and recommends that students seek formal clarification from the course instructor / faculty evaluator. 
> 
> Under **either** criterion, OS Guardian exceeds the required benchmark:
> - If evaluated against the **40–50%** VTOP guideline: OS Guardian stands at **66.67% – 77.78%**, well surpassing the requirement.
> - If evaluated against the **60–70%** Review I text: OS Guardian's milestone completion of **66.67%** falls directly within the target window.

---

## 10. Known Limitations & Milestone Roadmap

### 10.1 Current Limitations
1. **Single-CPU Assumption:** CPU scheduling assumes a single uniprocessor core; multi-core processor scheduling is out of scope.
2. **Fixed Contiguous Partitioning:** Memory allocation operates under a contiguous block model with at most one process per partition; non-contiguous paging with translation lookaside buffers (TLB) is simulated at the reference level in Module D rather than integrated into a unified virtual-to-physical address translator.
3. **Volatile Session Storage:** Simulation runs are currently held in client-server volatile memory; run archival to SQLite is scheduled for Milestone 6.

### 10.2 Milestone Roadmap for Subsequent Reviews

| Milestone | Target Phase | Focus Areas & Deliverables | Expected Completion |
|---|---|---|---|
| **Milestone 5** | Review II | Banker's Safety Algorithm, safe sequence determination, thread synchronization (Producer-Consumer, Reader-Writer using Python semaphores) | Next Development Sprint |
| **Milestone 6** | Review II / Pre-Final | SQLite database schema, simulation run persistence, history table, Chart.js comparative performance graphs | Post-Milestone 5 |
| **Milestone 7** | Final Review | Comprehensive system verification, documentation completion, viva demonstration slides | Final Project Submission |

---

## 11. Conclusion

Review I demonstrates that the **OS Guardian** project has established a rigorous foundation, transitioning from conceptual design to an operational, high-quality software system. With the dashboard architecture, all four CPU scheduling algorithms, horizontal Gantt timeline rendering, three contiguous memory allocation strategies, and three virtual memory page replacement policies fully realized and verified by 79 automated tests, the prototype fulfills all faculty expectations for the first review milestone with a verified completion rate of **66.67% – 77.78%**.

The remaining components—deadlock management, thread synchronization demonstrations, and SQLite persistence—are cleanly isolated into Milestone 5 and Milestone 6, positioning the team for timely completion in subsequent project reviews.

---

## 12. References

1. Belady, L. A. (1966). A study of replacement algorithms for a virtual-storage computer. *IBM Systems Journal*, 5(2), 78–101. https://doi.org/10.1147/sj.52.0078
2. Belady, L. A., Nelson, R. A., & Shedler, G. S. (1969). An anomaly in space-time characteristics of certain programs running in a paging machine. *Communications of the ACM*, 12(6), 349–353. https://doi.org/10.1145/363011.363155
3. Denning, P. J. (1970). Virtual memory. *ACM Computing Surveys (CSUR)*, 2(3), 153–189. https://doi.org/10.1145/356571.356580
4. Knuth, D. E. (1997). *The Art of Computer Programming, Volume 1: Fundamental Algorithms* (3rd ed.). Addison-Wesley Professional.
5. Shore, J. E. (1975). On the external storage fragmentation produced by first-fit and best-fit allocation strategies. *Communications of the ACM*, 18(8), 433–440. https://doi.org/10.1145/360933.360978
6. Silberschatz, A., Galvin, P. B., & Gagne, G. (2018). *Operating System Concepts* (10th ed.). John Wiley & Sons.
7. Stallings, W. (2018). *Operating Systems: Internals and Design Principles* (9th ed.). Pearson.
8. Tanenbaum, A. S., & Bos, H. (2015). *Modern Operating Systems* (4th ed.). Pearson.

---

## 13. Faculty Review Evaluation & Compliance Checklist

| Review I Requirement (from Faculty Guidelines) | Location in this Document | Verified Repository Evidence | Status |
|---|---|---|---|
| **1. Problem Statement** | Section 1 | Documented pedagogical disconnect & simulator rationale | Fully Compliant |
| **2. Objectives** | Section 2 | 5 SMART objectives covering scheduling, memory, paging, quality | Fully Compliant |
| **3. Literature / Background Study** | Section 3 & Section 12 | 8 verified textbook & seminal ACM/IBM references (including Shore & Stallings) | Fully Compliant |
| **4. System Design** | Section 4 & Section 5 | MVC design, data contracts, and detailed algorithm formulas | Fully Compliant |
| **5. System Architecture** | Section 4.1 & 4.2 | Layered architectural diagram distinguishing implemented vs planned layers | Fully Compliant |
| **6. Algorithms & Flowcharts** | Section 5.1, 5.2, 5.3 | 4 detailed flowcharts (SJF, Round Robin, Best Fit, Optimal) matching code | Fully Compliant |
| **7. Three-Member Work Division** | Section 6 | Detailed table allocating Member 1, Member 2, and Member 3 duties | Fully Compliant |
| **8. Initial Implementation / Prototype** | Section 7.1 & 7.2 | Live Flask server (`http://127.0.0.1:5000`) with working routes | Fully Compliant |
| **9. 60–70% (or 40–50%) Progress Evidence**| Section 9.1 & 9.2 | Unified 18-point matrix (77.78%) & 6-milestone breakdown (66.67%) | Fully Compliant |
| **10. Executable Core Functionality** | Section 7.2 & Section 8 | 79 automated tests passing; live simulation outputs recorded | Fully Compliant |
| **11. Actual Application Screenshots** | Section 7.2 | Figures 1, 2, 3, 4 captured from running app with real simulation state | Fully Compliant |
| **12. Faculty Discrepancy Flagging** | Section 9.2 | Explicitly documents Page 2 (60–70%) vs Page 3 (40–50%) discrepancy | Fully Compliant |

### Student-Supplied Items Checklist (To be filled before final submission)
- [ ] Team Member 1: Full Student Name and Registration Number
- [ ] Team Member 2: Full Student Name and Registration Number
- [ ] Team Member 3: Full Student Name and Registration Number
- [ ] Course Code (e.g., CSE2005 / CSED201P) and Lab Slot / Batch
- [ ] Department and Institution Name (e.g., School of Computer Science & Engineering, VIT)
