"""
algorithms/comparison.py
========================
Cross-Algorithm Performance Comparison Engine.
Executes compatible algorithm suites on identical workloads to evaluate
empirical trade-offs and identify optimal metrics across:
  1. CPU Scheduling (FCFS vs SJF vs Priority vs Round Robin)
  2. Memory Allocation (First Fit vs Best Fit vs Worst Fit)
  3. Page Replacement (FIFO vs LRU vs Optimal)

Supports focused comparisons allowing users to evaluate a subset (2 to 4)
of algorithms and provides comprehensive, grounded trade-off analysis.
"""

from typing import List, Dict, Any, Union, Optional
from algorithms.cpu_scheduling import fcfs, sjf, priority_scheduling, round_robin
from algorithms.memory_management import first_fit, best_fit, worst_fit
from algorithms.page_replacement import fifo, lru, optimal


def _normalize_cpu_processes(processes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Ensure process list has standardized keys: pid, arrival_time, burst_time, priority."""
    normalized = []
    for idx, p in enumerate(processes):
        pid = str(p.get("pid") or p.get("id") or f"P{idx + 1}").strip()
        arr = p.get("arrival_time") if p.get("arrival_time") is not None else p.get("arrival", 0)
        burst = p.get("burst_time") if p.get("burst_time") is not None else p.get("burst", 1)
        pri = p.get("priority", 1)
        normalized.append({
            "pid": pid,
            "arrival_time": int(arr),
            "burst_time": int(burst),
            "priority": int(pri if pri is not None else 1),
        })
    return normalized


def compare_cpu_scheduling(
    processes: List[Dict[str, Any]],
    quantum: int = 2,
    selected_algorithms: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Run selected CPU scheduling algorithms on the exact same process workload.

    Parameters
    ----------
    processes : List[Dict[str, Any]]
        List of process dictionaries.
    quantum : int
        Round Robin time quantum.
    selected_algorithms : Optional[List[str]]
        Subset of algorithms to compare (e.g. ['FCFS', 'Round Robin']).
        Must contain at least 2 algorithms if provided.

    Returns
    -------
    dict with comparison_table, best_metrics, best_performer, tradeoff_analysis, results.
    """
    if not processes:
        raise ValueError("Process list cannot be empty for comparison.")

    norm_procs = _normalize_cpu_processes(processes)
    all_available = {
        "FCFS": lambda: fcfs(norm_procs),
        "SJF": lambda: sjf(norm_procs),
        "Priority": lambda: priority_scheduling(norm_procs),
        "Round Robin": lambda: round_robin(norm_procs, quantum=quantum),
    }

    if selected_algorithms:
        # Match case-insensitively
        norm_selected = []
        for s in selected_algorithms:
            cleaned = str(s).strip()
            for k in all_available.keys():
                if cleaned.lower() == k.lower():
                    norm_selected.append(k)
                    break
        if len(norm_selected) < 2:
            raise ValueError("Please select at least 2 algorithms to compare.")
        active_algos = norm_selected
    else:
        active_algos = list(all_available.keys())

    results_map = {}
    for name in active_algos:
        res = all_available[name]()
        # Ensure both 'metrics' and 'summary' keys exist for UI compatibility
        res["summary"] = res["metrics"]
        results_map[name] = res

    table = []
    for name in active_algos:
        m = results_map[name]["metrics"]
        table.append({
            "algorithm": name,
            "avg_turnaround_time": m["avg_turnaround"],
            "avg_waiting_time": m["avg_waiting"],
            "avg_response_time": m["avg_response"],
            "cpu_utilization": m["cpu_utilization"],
            "makespan": m["makespan"],
            "total_burst_time": m["total_burst"],
        })

    # Best metric determinations
    min_tat = min(table, key=lambda x: x["avg_turnaround_time"])["algorithm"]
    min_wait = min(table, key=lambda x: x["avg_waiting_time"])["algorithm"]
    min_resp = min(table, key=lambda x: x["avg_response_time"])["algorithm"]
    max_util = max(table, key=lambda x: x["cpu_utilization"])["algorithm"]
    min_make = min(table, key=lambda x: x["makespan"])["algorithm"]

    best = {
        "min_turnaround": min_tat,
        "min_turnaround_time": min_tat,
        "min_waiting": min_wait,
        "min_waiting_time": min_wait,
        "min_response": min_resp,
        "min_response_time": min_resp,
        "max_utilization": max_util,
        "min_makespan": min_make,
    }

    tradeoffs = _generate_cpu_tradeoffs(active_algos, table, best, quantum)

    return {
        "workload_process_count": len(norm_procs),
        "quantum_used": quantum,
        "selected_algorithms": active_algos,
        "comparison_table": table,
        "best_metrics": best,
        "best_performer": best,
        "tradeoff_analysis": tradeoffs,
        "results": results_map,
    }


def _generate_cpu_tradeoffs(
    active_algos: List[str],
    table: List[Dict[str, Any]],
    best: Dict[str, str],
    quantum: int,
) -> Dict[str, Any]:
    """Generate structured architectural trade-offs comparing CPU algorithms."""
    algo_descriptions = {
        "FCFS": {
            "title": "First-Come, First-Served (FCFS)",
            "pros": "Simple FIFO queue, minimal context switching, zero scheduling overhead.",
            "cons": "Subject to the Convoy Effect where short I/O bound jobs wait behind long CPU bursts.",
            "best_for": "Batch processing workloads with uniform job runtimes.",
        },
        "SJF": {
            "title": "Shortest Job First (SJF Non-preemptive)",
            "pros": "Provably optimal for minimizing average waiting time among non-preemptive schedulers.",
            "cons": "Risk of long job starvation; requires predicting or knowing burst times in advance.",
            "best_for": "Long-term batch scheduling where job durations are known.",
        },
        "Priority": {
            "title": "Priority Scheduling (Non-preemptive)",
            "pros": "Enforces external urgency and SLA guarantees for mission-critical tasks.",
            "cons": "Low-priority processes can suffer indefinite postponement (starvation) without aging.",
            "best_for": "Real-time or stratified task environments with strict criticality tiers.",
        },
        "Round Robin": {
            "title": f"Round Robin (RR, Quantum={quantum})",
            "pros": "Fair CPU sharing, guarantees bounded response time, avoids starvation completely.",
            "cons": "Higher context switching overhead; performance heavily depends on quantum size.",
            "best_for": "Interactive, time-sharing, and general-purpose operating systems.",
        },
    }

    insights = [algo_descriptions[a] for a in active_algos if a in algo_descriptions]

    # Grounded comparative summary
    wait_winner = best["min_waiting"]
    summary = (
        f"In this workload of {len(table)} algorithms, {wait_winner} achieved the lowest average waiting time. "
    )
    if "Round Robin" in active_algos and wait_winner != "Round Robin":
        summary += (
            f"While {wait_winner} minimizes average wait time, Round Robin (q={quantum}) provides superior fairness "
            "and responsiveness for interactive applications."
        )
    elif "FCFS" in active_algos and "SJF" in active_algos:
        summary += "SJF successfully mitigated the queue delays seen in FCFS by prioritizing shorter burst tasks."

    return {
        "summary": summary,
        "algorithm_insights": insights,
        "best_performer": best,
    }


def compare_memory_allocation(
    blocks: List[Any],
    processes: List[Any],
    selected_algorithms: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Run selected memory allocation strategies on identical blocks and process requests.
    """
    if not blocks or not processes:
        raise ValueError("Memory blocks and processes cannot be empty for comparison.")

    # Convert to integer lists
    int_blocks = [int(b) for b in blocks if int(b) > 0]
    int_procs = [int(p) for p in processes if int(p) > 0]

    all_available = {
        "First Fit": lambda: first_fit(int_blocks, int_procs),
        "Best Fit": lambda: best_fit(int_blocks, int_procs),
        "Worst Fit": lambda: worst_fit(int_blocks, int_procs),
    }

    if selected_algorithms:
        norm_selected = []
        for s in selected_algorithms:
            cleaned = str(s).strip().lower().replace("_", " ")
            for k in all_available.keys():
                if cleaned == k.lower():
                    norm_selected.append(k)
                    break
        if len(norm_selected) < 2:
            raise ValueError("Please select at least 2 memory strategies to compare.")
        active_algos = norm_selected
    else:
        active_algos = list(all_available.keys())

    results_map = {}
    for name in active_algos:
        res = all_available[name]()
        res["summary"] = res["metrics"]
        results_map[name] = res

    table = []
    for name in active_algos:
        m = results_map[name]["metrics"]
        table.append({
            "strategy": name,
            "allocated_processes": m["allocated_processes_count"],
            "unallocated_processes": m["unallocated_processes_count"],
            "total_allocated_kb": m["allocated_memory"],
            "total_internal_frag_kb": m["total_internal_fragmentation"],
            "memory_utilization": m["utilization_percentage"],
            "total_free_kb": m["free_blocks_memory"],
        })

    best = {
        "max_allocated": max(table, key=lambda x: x["allocated_processes"])["strategy"],
        "most_allocated": max(table, key=lambda x: x["allocated_processes"])["strategy"],
        "min_internal_frag": min(table, key=lambda x: x["total_internal_frag_kb"])["strategy"],
        "least_fragmentation": min(table, key=lambda x: x["total_internal_frag_kb"])["strategy"],
        "max_utilization": max(table, key=lambda x: x["memory_utilization"])["strategy"],
        "highest_utilization": max(table, key=lambda x: x["memory_utilization"])["strategy"],
    }

    # Map for JS compatibility keys
    key_map = {
        "First Fit": "first_fit",
        "Best Fit": "best_fit",
        "Worst Fit": "worst_fit",
    }
    compat_results = {}
    for name, r in results_map.items():
        compat_results[name] = r
        compat_results[key_map[name]] = r

    tradeoffs = _generate_memory_tradeoffs(active_algos, table, best)

    return {
        "block_count": len(int_blocks),
        "process_count": len(int_procs),
        "selected_algorithms": active_algos,
        "comparison_table": table,
        "best_metrics": best,
        "best_performer": best,
        "tradeoff_analysis": tradeoffs,
        "results": compat_results,
    }


def _generate_memory_tradeoffs(
    active_algos: List[str],
    table: List[Dict[str, Any]],
    best: Dict[str, str],
) -> Dict[str, Any]:
    """Generate trade-off explanations for memory strategies."""
    descriptions = {
        "First Fit": {
            "title": "First Fit",
            "pros": "Fastest allocation time; terminates search at the first block that fits.",
            "cons": "Tends to crowd the beginning of memory with small fragments, increasing search time over time.",
            "best_for": "General memory allocation where rapid request turnaround is paramount.",
        },
        "Best Fit": {
            "title": "Best Fit",
            "pros": "Allocates the tightest matching block, preserving larger blocks for large requests.",
            "cons": "Must search entire memory table; produces tiny unusable slivers of internal/external fragmentation.",
            "best_for": "Workloads with a wide variance in process sizes where large blocks must be guarded.",
        },
        "Worst Fit": {
            "title": "Worst Fit",
            "pros": "Leaves the largest remaining hole after allocation, which may be useful for subsequent processes.",
            "cons": "Rapidly breaks down large contiguous blocks, leaving no space for large process requests.",
            "best_for": "Workloads dominated by small, uniform process allocations.",
        },
    }

    insights = [descriptions[a] for a in active_algos if a in descriptions]
    alloc_winner = best["max_allocated"]
    summary = (
        f"{alloc_winner} successfully satisfied the greatest number of process requests. "
        "Best Fit typically maximizes utilization in diverse workloads, whereas First Fit offers the lowest algorithmic latency."
    )

    return {
        "summary": summary,
        "algorithm_insights": insights,
        "best_performer": best,
    }


def compare_page_replacement(
    pages: Union[List[Any], str],
    num_frames: int,
    selected_algorithms: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Run selected page replacement algorithms on identical page references and frame count.
    """
    if num_frames <= 0:
        raise ValueError("Number of frames must be positive.")

    all_available = {
        "FIFO": lambda: fifo(pages, num_frames),
        "LRU": lambda: lru(pages, num_frames),
        "Optimal": lambda: optimal(pages, num_frames),
    }

    if selected_algorithms:
        norm_selected = []
        for s in selected_algorithms:
            cleaned = str(s).strip().upper()
            if cleaned == "OPT" or cleaned == "OPTIMAL":
                norm_selected.append("Optimal")
            elif cleaned == "FIFO":
                norm_selected.append("FIFO")
            elif cleaned == "LRU":
                norm_selected.append("LRU")
        if len(norm_selected) < 2:
            raise ValueError("Please select at least 2 page replacement algorithms to compare.")
        active_algos = norm_selected
    else:
        active_algos = list(all_available.keys())

    results_map = {}
    for name in active_algos:
        res = all_available[name]()
        results_map[name] = res

    table = []
    for name in active_algos:
        res = results_map[name]
        table.append({
            "algorithm": name,
            "total_references": res["total_references"],
            "page_hits": res["page_hits"],
            "page_faults": res["page_faults"],
            "hit_ratio": res["hit_ratio"],
            "fault_ratio": res["fault_ratio"],
        })

    best = {
        "min_faults": min(table, key=lambda x: x["page_faults"])["algorithm"],
        "lowest_page_faults": min(table, key=lambda x: x["page_faults"])["algorithm"],
        "max_hits": max(table, key=lambda x: x["page_hits"])["algorithm"],
        "highest_hit_ratio": max(table, key=lambda x: x["hit_ratio"])["algorithm"],
    }

    key_map = {"FIFO": "fifo", "LRU": "lru", "Optimal": "optimal"}
    compat_results = {}
    for name, r in results_map.items():
        compat_results[name] = r
        compat_results[key_map[name]] = r

    tradeoffs = _generate_paging_tradeoffs(active_algos, table, best, num_frames)

    return {
        "num_frames": num_frames,
        "total_references": table[0]["total_references"],
        "selected_algorithms": active_algos,
        "comparison_table": table,
        "best_metrics": best,
        "best_performer": best,
        "tradeoff_analysis": tradeoffs,
        "results": compat_results,
    }


def _generate_paging_tradeoffs(
    active_algos: List[str],
    table: List[Dict[str, Any]],
    best: Dict[str, str],
    num_frames: int,
) -> Dict[str, Any]:
    """Generate trade-off explanations for page replacement algorithms."""
    descriptions = {
        "FIFO": {
            "title": "First-In, First-Out (FIFO)",
            "pros": "Simple queue implementation, low hardware overhead.",
            "cons": "Does not account for reference frequency or recency; vulnerable to Belady's Anomaly.",
            "best_for": "Systems with strict low-overhead constraints and sequentially accessed memory.",
        },
        "LRU": {
            "title": "Least Recently Used (LRU)",
            "pros": "Exploits the principle of locality well; approximates optimal replacement in real workloads.",
            "cons": "Requires hardware assistance (stack or timestamp counters) to track access recency efficiently.",
            "best_for": "General-purpose operating system virtual memory management.",
        },
        "Optimal": {
            "title": "Optimal (OPT / Belady's Min)",
            "pros": "Provably guarantees the lowest possible page fault rate for any given frame allocation.",
            "cons": "Unrealizable in real operating systems as it requires clairvoyant knowledge of future memory requests.",
            "best_for": "Theoretical upper-bound benchmark for comparing realizable page replacement heuristics.",
        },
    }

    insights = [descriptions[a] for a in active_algos if a in descriptions]
    fault_winner = best["min_faults"]
    summary = (
        f"Across {num_frames} physical frames, {fault_winner} produced the fewest page faults. "
    )
    if "Optimal" in active_algos and fault_winner == "Optimal":
        summary += "Optimal demonstrates the theoretical minimum page fault rate, serving as the benchmark standard."

    return {
        "summary": summary,
        "algorithm_insights": insights,
        "best_performer": best,
    }
