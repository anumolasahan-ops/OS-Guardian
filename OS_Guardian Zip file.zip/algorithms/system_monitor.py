"""
algorithms/system_monitor.py
============================
System Monitor and Formal Deadlock Detection Engine for OS Guardian.

Provides:
  1. Live Windows Host Metrics via psutil:
     - Real-time CPU, RAM, and Swap utilization
     - Process enumeration with robust exception guards (NoSuchProcess, AccessDenied)
     - Safe, read-only system telemetry (ZERO kernel modifications or termination)

  2. Formal Resource-Allocation Deadlock Detection Algorithm:
     - Multi-resource deadlock detection algorithm (Silberschatz / Galvin)
     - Step-by-step Work/Finish vector progression trace
     - Identification of deadlocked processes or safe execution sequence
     - Clear distinction between theoretical deadlock models and live OS metrics
"""

from datetime import datetime
from typing import List, Dict, Any, Optional
import psutil


def get_system_snapshot(max_processes: int = 50) -> Dict[str, Any]:
    """
    Capture a live, read-only snapshot of the Windows operating system host.

    Guards against transient process state changes and permission restrictions.

    Parameters
    ----------
    max_processes : int
        Maximum number of active processes to return (sorted by CPU & Memory usage).

    Returns
    -------
    dict containing timestamp, cpu, memory, swap, and sanitized process list.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # CPU metrics (interval=0.1 provides responsive, non-blocking sampling)
    cpu_percent = psutil.cpu_percent(interval=0.1)
    cpu_count_logical = psutil.cpu_count(logical=True) or 1
    cpu_count_physical = psutil.cpu_count(logical=False) or cpu_count_logical

    # Memory metrics
    vmem = psutil.virtual_memory()
    swap = psutil.swap_memory()

    # Process enumeration with safe access handling
    procs = []
    for proc in psutil.process_iter(attrs=["pid", "name", "status", "cpu_percent", "memory_info", "memory_percent", "username"]):
        try:
            info = proc.info
            pid = info["pid"]
            name = info["name"] or "Unknown"
            status = info["status"] or "unknown"
            cpu_p = info["cpu_percent"] if info["cpu_percent"] is not None else 0.0
            mem_info = info["memory_info"]
            mem_mb = round(mem_info.rss / (1024 * 1024), 2) if mem_info else 0.0
            mem_p = round(info["memory_percent"], 2) if info["memory_percent"] is not None else 0.0
            username = info.get("username") or "System / Protected"

            procs.append({
                "pid": pid,
                "name": name,
                "status": str(status).capitalize(),
                "cpu_percent": float(cpu_p),
                "memory_mb": float(mem_mb),
                "memory_percent": float(mem_p),
                "username": username,
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        except Exception:
            continue

    total_proc_count = len(procs)

    # Sort processes by CPU usage descending, then Memory descending
    procs.sort(key=lambda x: (x["cpu_percent"], x["memory_mb"]), reverse=True)
    top_procs = procs[:max_processes]

    return {
        "timestamp": timestamp,
        "cpu": {
            "percent": cpu_percent,
            "logical_cores": cpu_count_logical,
            "physical_cores": cpu_count_physical,
        },
        "memory": {
            "total_mb": round(vmem.total / (1024 * 1024), 1),
            "available_mb": round(vmem.available / (1024 * 1024), 1),
            "used_mb": round(vmem.used / (1024 * 1024), 1),
            "percent": vmem.percent,
        },
        "swap": {
            "total_mb": round(swap.total / (1024 * 1024), 1),
            "used_mb": round(swap.used / (1024 * 1024), 1),
            "free_mb": round(swap.free / (1024 * 1024), 1),
            "percent": swap.percent,
        },
        "process_count": total_proc_count,
        "processes": top_procs,
    }


def detect_deadlock(
    allocation: List[List[int]],
    request: List[List[int]],
    available: List[int],
    process_names: Optional[List[str]] = None,
    resource_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Formal Multi-Resource Deadlock Detection Algorithm.

    Given:
      - Allocation matrix: current resource units allocated to each process
      - Request matrix: current resource units requested by each process
      - Available vector: unallocated resource units available in the system

    Algorithm steps:
      1. Work = Available[:]
      2. For i in 0..n-1:
           if Allocation[i] == 0: Finish[i] = True else Finish[i] = False
      3. Find i such that Finish[i] == False and Request[i] <= Work:
           Work = Work + Allocation[i]
           Finish[i] = True
           Record execution step. Repeat until no such process exists.
      4. If Finish[i] == False for any i, those processes are deadlocked.

    Parameters
    ----------
    allocation : List[List[int]]
        n x m matrix.
    request : List[List[int]]
        n x m matrix.
    available : List[int]
        m-element vector.
    process_names : Optional[List[str]]
        Identifiers for processes (default: P0, P1, ...).
    resource_names : Optional[List[str]]
        Identifiers for resources (default: R0, R1, ...).

    Returns
    -------
    dict with:
      - is_deadlocked : bool
      - deadlocked_processes : List[str]
      - safe_sequence : List[str]
      - step_trace : List[Dict[str, Any]]
      - summary : str
    """
    if not allocation or not request or not available:
        raise ValueError("Allocation, Request, and Available structures cannot be empty.")

    n = len(allocation)
    m = len(available)

    if len(request) != n:
        raise ValueError(f"Allocation has {n} processes but Request has {len(request)}.")

    for i in range(n):
        if len(allocation[i]) != m:
            raise ValueError(f"Allocation row {i} has {len(allocation[i])} resources, expected {m}.")
        if len(request[i]) != m:
            raise ValueError(f"Request row {i} has {len(request[i])} resources, expected {m}.")

    p_names = process_names or [f"P{i}" for i in range(n)]
    r_names = resource_names or [f"R{j}" for j in range(m)]

    # Work and Finish vectors
    work = list(available)
    finish = [False] * n

    # Step 2: Processes holding no resources cannot be part of a deadlock
    for i in range(n):
        if all(allocation[i][j] == 0 for j in range(m)):
            finish[i] = True

    step_trace = []
    step_num = 1

    # Record initial state
    step_trace.append({
        "step": 0,
        "action": "Initialization",
        "description": "Initialized Work vector to Available resources. Processes with 0 allocation marked Finish=True.",
        "work": list(work),
        "finish": {p_names[k]: finish[k] for k in range(n)},
        "satisfied_process": None,
    })

    safe_sequence = []

    # Step 3: Find an unfinished process whose request can be satisfied by Work
    while True:
        found_process = False
        for i in range(n):
            if not finish[i]:
                # Check if Request[i] <= Work
                can_satisfy = all(request[i][j] <= work[j] for j in range(m))
                if can_satisfy:
                    # Satisfy process: reclaim allocated resources
                    old_work = list(work)
                    for j in range(m):
                        work[j] += allocation[i][j]
                    finish[i] = True
                    safe_sequence.append(p_names[i])

                    step_trace.append({
                        "step": step_num,
                        "action": f"Process {p_names[i]} Satisfied",
                        "description": (
                            f"{p_names[i]}'s request {request[i]} <= Work {old_work}. "
                            f"{p_names[i]} completes and releases allocation {allocation[i]}. New Work = {work}."
                        ),
                        "work": list(work),
                        "finish": {p_names[k]: finish[k] for k in range(n)},
                        "satisfied_process": p_names[i],
                    })
                    step_num += 1
                    found_process = True
                    break  # Restart loop to check all remaining

        if not found_process:
            break

    # Step 4: Identify deadlocked processes
    deadlocked = [p_names[i] for i in range(n) if not finish[i]]
    is_deadlocked = len(deadlocked) > 0

    if is_deadlocked:
        summary = (
            f"DEADLOCK DETECTED! Processes {', '.join(deadlocked)} are deadlocked. "
            "Available resources are insufficient to satisfy their outstanding requests."
        )
    else:
        summary = (
            f"NO DEADLOCK DETECTED. System is in a safe state with resolution sequence: "
            f"{' → '.join(safe_sequence)}."
        )

    return {
        "is_deadlocked": is_deadlocked,
        "deadlocked_processes": deadlocked,
        "safe_sequence": safe_sequence,
        "step_trace": step_trace,
        "summary": summary,
        "resources": r_names,
        "processes": p_names,
        "initial_work": list(available),
        "final_work": list(work),
    }
