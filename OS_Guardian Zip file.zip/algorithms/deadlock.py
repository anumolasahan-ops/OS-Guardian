"""
algorithms/deadlock.py
======================
Banker's Algorithm for Deadlock Avoidance.
Provides:
  1. Need Matrix calculation
  2. Banker's Safety Algorithm with step-by-step execution trace
  3. Resource-Request Algorithm with tentative allocation and rollback
"""

from typing import List, Dict, Any, Tuple, Optional
import copy


def calculate_need(allocation: List[List[int]], maximum: List[List[int]]) -> List[List[int]]:
    """
    Calculate Need matrix = Maximum - Allocation.

    Raises
    ------
    ValueError
        If dimensions mismatch, elements are negative, or Allocation > Maximum.
    """
    if not allocation or not maximum:
        raise ValueError("Allocation and Maximum matrices must not be empty.")

    n_proc = len(allocation)
    if len(maximum) != n_proc:
        raise ValueError(f"Process count mismatch: Allocation has {n_proc}, Maximum has {len(maximum)}.")

    n_res = len(allocation[0])
    if n_res == 0:
        raise ValueError("Matrices must contain at least one resource column.")

    need = []
    for i in range(n_proc):
        if len(allocation[i]) != n_res or len(maximum[i]) != n_res:
            raise ValueError(f"Row {i} dimension mismatch: expected {n_res} resource types.")

        row = []
        for j in range(n_res):
            alloc_val = allocation[i][j]
            max_val = maximum[i][j]

            if not isinstance(alloc_val, int) or not isinstance(max_val, int):
                raise ValueError(f"Matrix elements must be integers. Found non-integer at P{i}, R{j}.")
            if alloc_val < 0 or max_val < 0:
                raise ValueError(f"Matrix values must be non-negative. Found negative value at P{i}, R{j}.")
            if alloc_val > max_val:
                raise ValueError(
                    f"Allocation exceeds Maximum for process P{i}, resource R{j}: "
                    f"Allocated {alloc_val} > Max {max_val}."
                )

            row.append(max_val - alloc_val)
        need.append(row)

    return need


def validate_bankers_inputs(
    allocation: List[List[int]],
    maximum: List[List[int]],
    available: List[int],
    process_names: Optional[List[str]] = None,
    resource_names: Optional[List[str]] = None,
) -> Tuple[int, int, List[str], List[str]]:
    """
    Validate all inputs for Banker's Algorithm.
    Returns (num_processes, num_resources, process_names, resource_names).
    """
    if not allocation or not maximum or not available:
        raise ValueError("Allocation, Maximum, and Available inputs must not be empty.")

    n_proc = len(allocation)
    n_res = len(allocation[0]) if n_proc > 0 else 0

    if n_proc == 0 or n_res == 0:
        raise ValueError("System must have at least 1 process and 1 resource type.")

    if len(available) != n_res:
        raise ValueError(f"Available vector length ({len(available)}) does not match resource count ({n_res}).")

    for j, avail in enumerate(available):
        if not isinstance(avail, int) or avail < 0:
            raise ValueError(f"Available resource R{j} must be a non-negative integer (got {avail}).")

    # Validate matrices & calculate need (validates alloc <= max)
    calculate_need(allocation, maximum)

    # Process and resource names
    if not process_names or len(process_names) != n_proc:
        proc_names = [f"P{i}" for i in range(n_proc)]
    else:
        proc_names = [str(p).strip() for p in process_names]

    if not resource_names or len(resource_names) != n_res:
        res_names = [chr(65 + j) if j < 26 else f"R{j}" for j in range(n_res)]
    else:
        res_names = [str(r).strip() for r in resource_names]

    return n_proc, n_res, proc_names, res_names


def bankers_safety(
    allocation: List[List[int]],
    maximum: List[List[int]],
    available: List[int],
    process_names: Optional[List[str]] = None,
    resource_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Execute Banker's Safety Algorithm.

    Returns
    -------
    dict with:
      - is_safe: bool
      - safe_sequence: list of str (process names in execution order)
      - steps: list of dict recording each step:
          step_number, process_index, process_name, work_before, need, alloc, work_after
      - need_matrix: list[list[int]]
      - allocation: list[list[int]]
      - maximum: list[list[int]]
      - available: list[int]
      - process_names: list[str]
      - resource_names: list[str]
      - unfinished_processes: list[str] (if unsafe)
      - explanation: str
    """
    n_proc, n_res, p_names, r_names = validate_bankers_inputs(
        allocation, maximum, available, process_names, resource_names
    )

    need = calculate_need(allocation, maximum)
    work = list(available)
    finish = [False] * n_proc
    safe_sequence = []
    steps = []

    step_count = 0
    while True:
        found_process = False
        for i in range(n_proc):
            if not finish[i]:
                # Check if Need[i] <= Work
                can_allocate = all(need[i][j] <= work[j] for j in range(n_res))
                if can_allocate:
                    step_count += 1
                    work_before = list(work)
                    # Simulate process completion and resource reclamation
                    for j in range(n_res):
                        work[j] += allocation[i][j]

                    finish[i] = True
                    safe_sequence.append(p_names[i])
                    steps.append({
                        "step_number": step_count,
                        "process_index": i,
                        "process_name": p_names[i],
                        "work_before": work_before,
                        "need": list(need[i]),
                        "allocated": list(allocation[i]),
                        "work_after": list(work),
                    })
                    found_process = True
                    break  # Restart scan to find next eligible process

        if not found_process:
            break

    is_safe = all(finish)
    unfinished = [p_names[i] for i in range(n_proc) if not finish[i]]

    if is_safe:
        explanation = (
            f"The system is in a SAFE state. A valid safe execution sequence was identified: "
            f"{' -> '.join(safe_sequence)}. All {n_proc} processes can finish without deadlock."
        )
    else:
        explanation = (
            f"The system is in an UNSAFE state. No safe sequence exists. "
            f"Processes {unfinished} cannot satisfy their maximum resource requirements "
            f"with currently available resources. Deadlock may occur."
        )

    return {
        "is_safe": is_safe,
        "safe_sequence": safe_sequence if is_safe else [],
        "steps": steps,
        "need_matrix": need,
        "allocation": allocation,
        "maximum": maximum,
        "available": available,
        "final_work": work,
        "process_names": p_names,
        "resource_names": r_names,
        "unfinished_processes": unfinished,
        "explanation": explanation,
    }


def resource_request(
    allocation: List[List[int]],
    maximum: List[List[int]],
    available: List[int],
    process_index: int,
    request_vector: List[int],
    process_names: Optional[List[str]] = None,
    resource_names: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Banker's Resource-Request Algorithm.
    Simulates request for process_index with request_vector.
    Performs tentative allocation, checks safety, and rolls back if unsafe.

    Returns
    -------
    dict with:
      - granted: bool
      - message: str
      - rolled_back: bool
      - allocation: list[list[int]] (updated if granted, original if rolled back)
      - maximum: list[list[int]]
      - available: list[int] (updated if granted, original if rolled back)
      - need: list[list[int]]
      - safety_result: dict (result of safety check)
    """
    n_proc, n_res, p_names, r_names = validate_bankers_inputs(
        allocation, maximum, available, process_names, resource_names
    )

    if not isinstance(process_index, int) or process_index < 0 or process_index >= n_proc:
        raise ValueError(f"Invalid process index {process_index}. Must be between 0 and {n_proc - 1}.")

    if not request_vector or len(request_vector) != n_res:
        raise ValueError(f"Request vector length ({len(request_vector) if request_vector else 0}) must match resource count ({n_res}).")

    for j, req_val in enumerate(request_vector):
        if not isinstance(req_val, int) or req_val < 0:
            raise ValueError(f"Request amount for R{j} must be a non-negative integer (got {req_val}).")

    need = calculate_need(allocation, maximum)
    p_name = p_names[process_index]

    # Condition 1: Request <= Need
    for j in range(n_res):
        if request_vector[j] > need[process_index][j]:
            raise ValueError(
                f"Error: Process {p_name} requested {request_vector[j]} units of {r_names[j]}, "
                f"which exceeds its declared remaining Need of {need[process_index][j]} units."
            )

    # Condition 2: Request <= Available
    for j in range(n_res):
        if request_vector[j] > available[j]:
            return {
                "granted": False,
                "message": (
                    f"Request DENIED for process {p_name}: Requested {request_vector[j]} units of {r_names[j]}, "
                    f"but only {available[j]} units are currently available. Process must wait."
                ),
                "rolled_back": False,
                "allocation": allocation,
                "maximum": maximum,
                "available": available,
                "need": need,
                "process_names": p_names,
                "resource_names": r_names,
                "safety_result": None,
            }

    # Tentative Allocation
    tentative_available = list(available)
    tentative_allocation = copy.deepcopy(allocation)
    tentative_maximum = copy.deepcopy(maximum)

    for j in range(n_res):
        tentative_available[j] -= request_vector[j]
        tentative_allocation[process_index][j] += request_vector[j]

    # Test safety on tentative state
    safety_check = bankers_safety(
        tentative_allocation,
        tentative_maximum,
        tentative_available,
        process_names=p_names,
        resource_names=r_names,
    )

    if safety_check["is_safe"]:
        # Safe -> Grant request
        tentative_need = calculate_need(tentative_allocation, tentative_maximum)
        return {
            "granted": True,
            "message": (
                f"Request GRANTED for process {p_name}. Resulting system state is SAFE "
                f"with safe sequence: {' -> '.join(safety_check['safe_sequence'])}."
            ),
            "rolled_back": False,
            "allocation": tentative_allocation,
            "maximum": tentative_maximum,
            "available": tentative_available,
            "need": tentative_need,
            "process_names": p_names,
            "resource_names": r_names,
            "safety_result": safety_check,
        }
    else:
        # Unsafe -> Roll back
        return {
            "granted": False,
            "message": (
                f"Request REJECTED for process {p_name}: Tentative allocation leaves the system in an "
                f"UNSAFE state. Resources were rolled back to the original state."
            ),
            "rolled_back": True,
            "allocation": allocation,
            "maximum": maximum,
            "available": available,
            "need": need,
            "process_names": p_names,
            "resource_names": r_names,
            "safety_result": safety_check,
        }
