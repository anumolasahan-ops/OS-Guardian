"""
algorithms/export_utils.py
==========================
Excel Export Generator for OS Guardian using openpyxl.

Generates beautifully styled, multi-sheet .xlsx workbooks for:
  1. System Monitor snapshots & process lists
  2. Deadlock Analysis & Work vector traces
  3. Performance Comparison benchmarks (CPU, Memory, Paging)
  4. SQLite Simulation History audit logs
"""

import io
from datetime import datetime
from typing import Dict, Any, List, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Common styling definitions
HEADER_FILL = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
SUBHEADER_FILL = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
SUCCESS_FILL = PatternFill(start_color="D9EAD3", end_color="D9EAD3", fill_type="solid")
DANGER_FILL = PatternFill(start_color="F4CCCC", end_color="F4CCCC", fill_type="solid")

HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="Calibri", size=14, bold=True, color="1F497D")
BOLD_FONT = Font(name="Calibri", size=10, bold=True)
REGULAR_FONT = Font(name="Calibri", size=10)

THIN_BORDER = Border(
    left=Side(style="thin", color="D9D9D9"),
    right=Side(style="thin", color="D9D9D9"),
    top=Side(style="thin", color="D9D9D9"),
    bottom=Side(style="thin", color="D9D9D9"),
)


def _autofit_columns(ws, min_width=12, max_width=50):
    """Automatically adjust column widths to fit cell contents cleanly."""
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val_str = str(cell.value or "")
            if "\n" in val_str:
                lines = val_str.split("\n")
                max_len = max(max_len, max(len(line) for line in lines))
            else:
                max_len = max(max_len, len(val_str))
        ws.column_dimensions[col_letter].width = min(max(max_len + 3, min_width), max_width)


def export_system_snapshot_excel(snapshot: Dict[str, Any]) -> io.BytesIO:
    """Generate an Excel workbook for a real Windows system snapshot."""
    wb = openpyxl.Workbook()

    # Sheet 1: System Overview
    ws_summary = wb.active
    ws_summary.title = "System Overview"
    ws_summary.views.sheetView[0].showGridLines = True

    ws_summary["A1"] = "OS Guardian — Windows System Snapshot"
    ws_summary["A1"].font = TITLE_FONT
    ws_summary["A2"] = f"Captured at: {snapshot.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}"
    ws_summary["A2"].font = Font(name="Calibri", size=10, italic=True, color="595959")

    # Overview table
    cpu = snapshot.get("cpu", {})
    mem = snapshot.get("memory", {})
    swap = snapshot.get("swap", {})

    metrics = [
        ("Metric Category", "Parameter", "Value"),
        ("CPU", "Overall CPU Utilization", f"{cpu.get('percent', 0)}%"),
        ("CPU", "Logical CPU Cores", cpu.get("logical_cores", 1)),
        ("CPU", "Physical CPU Cores", cpu.get("physical_cores", 1)),
        ("Virtual Memory (RAM)", "Total Physical RAM", f"{mem.get('total_mb', 0):,.1f} MB"),
        ("Virtual Memory (RAM)", "Used RAM", f"{mem.get('used_mb', 0):,.1f} MB"),
        ("Virtual Memory (RAM)", "Available RAM", f"{mem.get('available_mb', 0):,.1f} MB"),
        ("Virtual Memory (RAM)", "RAM Utilization", f"{mem.get('percent', 0)}%"),
        ("Swap / Pagefile", "Total Swap", f"{swap.get('total_mb', 0):,.1f} MB"),
        ("Swap / Pagefile", "Used Swap", f"{swap.get('used_mb', 0):,.1f} MB"),
        ("Swap / Pagefile", "Swap Utilization", f"{swap.get('percent', 0)}%"),
        ("Process Telemetry", "Active Processes Enumerated", snapshot.get("process_count", 0)),
    ]

    start_row = 4
    for r_idx, row_data in enumerate(metrics, start=start_row):
        for c_idx, val in enumerate(row_data, start=1):
            cell = ws_summary.cell(row=r_idx, column=c_idx, value=val)
            cell.border = THIN_BORDER
            if r_idx == start_row:
                cell.fill = HEADER_FILL
                cell.font = HEADER_FONT
                cell.alignment = Alignment(horizontal="center", vertical="center")
            else:
                cell.font = REGULAR_FONT
                cell.alignment = Alignment(horizontal="left", vertical="center")
                if c_idx == 3:
                    cell.alignment = Alignment(horizontal="right", vertical="center")

    _autofit_columns(ws_summary)

    # Sheet 2: Process List
    ws_procs = wb.create_sheet(title="Process List")
    ws_procs.views.sheetView[0].showGridLines = True

    proc_headers = ["PID", "Process Name", "Status", "CPU (%)", "Memory (MB)", "Memory (%)", "User / Domain"]
    for c_idx, h in enumerate(proc_headers, start=1):
        cell = ws_procs.cell(row=1, column=c_idx, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = THIN_BORDER

    procs = snapshot.get("processes", [])
    for r_idx, p in enumerate(procs, start=2):
        row_vals = [
            p.get("pid"),
            p.get("name"),
            p.get("status"),
            p.get("cpu_percent"),
            p.get("memory_mb"),
            p.get("memory_percent"),
            p.get("username"),
        ]
        for c_idx, val in enumerate(row_vals, start=1):
            cell = ws_procs.cell(row=r_idx, column=c_idx, value=val)
            cell.font = REGULAR_FONT
            cell.border = THIN_BORDER
            if c_idx == 1:
                cell.alignment = Alignment(horizontal="center")
            elif c_idx in (4, 5, 6):
                cell.alignment = Alignment(horizontal="right")
            else:
                cell.alignment = Alignment(horizontal="left")

    _autofit_columns(ws_procs)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output


def export_deadlock_analysis_excel(analysis: Dict[str, Any]) -> io.BytesIO:
    """Generate an Excel workbook for formal deadlock detection analysis."""
    wb = openpyxl.Workbook()

    # Sheet 1: Detection Result & Summary
    ws_sum = wb.active
    ws_sum.title = "Detection Summary"
    ws_sum.views.sheetView[0].showGridLines = True

    ws_sum["A1"] = "OS Guardian — Formal Deadlock Detection Analysis"
    ws_sum["A1"].font = TITLE_FONT

    is_deadlocked = analysis.get("is_deadlocked", False)
    status_text = "DEADLOCK DETECTED" if is_deadlocked else "NO DEADLOCK (SAFE STATE)"
    fill = DANGER_FILL if is_deadlocked else SUCCESS_FILL

    ws_sum["A3"] = "Analysis Status:"
    ws_sum["A3"].font = BOLD_FONT
    ws_sum["B3"] = status_text
    ws_sum["B3"].font = Font(name="Calibri", size=11, bold=True, color="9C0006" if is_deadlocked else "274E13")
    ws_sum["B3"].fill = fill

    ws_sum["A4"] = "Summary:"
    ws_sum["A4"].font = BOLD_FONT
    ws_sum["B4"] = analysis.get("summary", "")
    ws_sum["B4"].font = REGULAR_FONT

    if is_deadlocked:
        ws_sum["A5"] = "Deadlocked Processes:"
        ws_sum["A5"].font = BOLD_FONT
        ws_sum["B5"] = ", ".join(analysis.get("deadlocked_processes", []))
        ws_sum["B5"].font = BOLD_FONT
    else:
        ws_sum["A5"] = "Safe Resolution Sequence:"
        ws_sum["A5"].font = BOLD_FONT
        ws_sum["B5"] = " → ".join(analysis.get("safe_sequence", []))
        ws_sum["B5"].font = BOLD_FONT

    # Step Trace Table
    ws_sum["A7"] = "Execution Progression Trace"
    ws_sum["A7"].font = Font(name="Calibri", size=12, bold=True, color="1F497D")

    trace_headers = ["Step", "Action", "Description", "Work Vector"]
    for c_idx, h in enumerate(trace_headers, start=1):
        cell = ws_sum.cell(row=8, column=c_idx, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = THIN_BORDER

    steps = analysis.get("step_trace", [])
    for r_idx, s in enumerate(steps, start=9):
        work_str = str(s.get("work", []))
        row_vals = [s.get("step"), s.get("action"), s.get("description"), work_str]
        for c_idx, val in enumerate(row_vals, start=1):
            cell = ws_sum.cell(row=r_idx, column=c_idx, value=val)
            cell.font = REGULAR_FONT
            cell.border = THIN_BORDER
            if c_idx == 1:
                cell.alignment = Alignment(horizontal="center")
            else:
                cell.alignment = Alignment(horizontal="left")

    _autofit_columns(ws_sum)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output


def export_comparison_excel(comparison_data: Dict[str, Any], subsystem: str = "cpu") -> io.BytesIO:
    """Generate an Excel workbook for cross-algorithm performance benchmarks."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"{subsystem.upper()} Benchmark"
    ws.views.sheetView[0].showGridLines = True

    ws["A1"] = f"OS Guardian — {subsystem.upper()} Performance Comparison Benchmark"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    ws["A2"].font = Font(name="Calibri", size=10, italic=True, color="595959")

    table = comparison_data.get("comparison_table", [])
    if table:
        headers = list(table[0].keys())
        # Clean headers for presentation
        pretty_headers = [h.replace("_", " ").title() for h in headers]
        start_row = 4
        for c_idx, h in enumerate(pretty_headers, start=1):
            cell = ws.cell(row=start_row, column=c_idx, value=h)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = THIN_BORDER

        for r_idx, row_dict in enumerate(table, start=start_row + 1):
            for c_idx, key in enumerate(headers, start=1):
                val = row_dict[key]
                if isinstance(val, float):
                    val = round(val, 2)
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.font = REGULAR_FONT
                cell.border = THIN_BORDER
                cell.alignment = Alignment(horizontal="center" if c_idx == 1 else "right")

    # Trade-offs section
    tradeoffs = comparison_data.get("tradeoff_analysis", {})
    if tradeoffs:
        tr_start = (len(table) + 6) if table else 4
        ws.cell(row=tr_start, column=1, value="Comparative Trade-off Analysis & Insights").font = Font(name="Calibri", size=12, bold=True, color="1F497D")
        ws.cell(row=tr_start + 1, column=1, value=tradeoffs.get("summary", "")).font = REGULAR_FONT

        insights = tradeoffs.get("algorithm_insights", [])
        if insights:
            ins_headers = ["Algorithm", "Strengths", "Weaknesses", "Best For"]
            for c_idx, h in enumerate(ins_headers, start=1):
                cell = ws.cell(row=tr_start + 3, column=c_idx, value=h)
                cell.fill = SUBHEADER_FILL
                cell.font = BOLD_FONT
                cell.border = THIN_BORDER
                cell.alignment = Alignment(horizontal="center")

            for r_idx, ins in enumerate(insights, start=tr_start + 4):
                vals = [ins.get("title"), ins.get("pros"), ins.get("cons"), ins.get("best_for")]
                for c_idx, val in enumerate(vals, start=1):
                    cell = ws.cell(row=r_idx, column=c_idx, value=val)
                    cell.font = REGULAR_FONT
                    cell.border = THIN_BORDER
                    cell.alignment = Alignment(horizontal="left", wrap_text=True)

    _autofit_columns(ws)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output


def export_history_excel(records: List[Dict[str, Any]]) -> io.BytesIO:
    """Generate an Excel workbook of all saved SQLite simulation history records."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Simulation Audit Log"
    ws.views.sheetView[0].showGridLines = True

    ws["A1"] = "OS Guardian — Simulation History & Audit Log"
    ws["A1"].font = TITLE_FONT
    ws["A2"] = f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Total records: {len(records)}"
    ws["A2"].font = Font(name="Calibri", size=10, italic=True, color="595959")

    headers = ["ID", "Timestamp", "Module", "Algorithm", "Summary Results", "Parameters"]
    start_row = 4
    for c_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=start_row, column=c_idx, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = THIN_BORDER

    for r_idx, r in enumerate(records, start=start_row + 1):
        summary_val = r.get("summary_text") or str(r.get("summary_metrics") or "")
        params_val = str(r.get("parameters") or "")
        if len(params_val) > 100:
            params_val = params_val[:97] + "..."

        row_vals = [
            r.get("id"),
            r.get("timestamp"),
            str(r.get("module_type") or "").upper(),
            r.get("algorithm"),
            summary_val,
            params_val,
        ]
        for c_idx, val in enumerate(row_vals, start=1):
            cell = ws.cell(row=r_idx, column=c_idx, value=val)
            cell.font = REGULAR_FONT
            cell.border = THIN_BORDER
            if c_idx == 1:
                cell.alignment = Alignment(horizontal="center")
            elif c_idx == 2:
                cell.alignment = Alignment(horizontal="center")
            else:
                cell.alignment = Alignment(horizontal="left")

    _autofit_columns(ws)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return output
