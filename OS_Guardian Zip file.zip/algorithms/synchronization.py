"""
algorithms/synchronization.py
==============================
Thread Synchronization Demonstrations.
Implements:
  1. Producer–Consumer using a bounded buffer and semaphores/locks.
  2. Reader–Writer synchronization using semaphores/locks with mutual exclusion.
"""

import threading
import time
from typing import List, Dict, Any, Optional


def producer_consumer_demo(
    buffer_capacity: int = 5,
    num_items: int = 8,
    delay: float = 0.005,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """
    Controlled Producer–Consumer simulation using Python threading primitives:
      - mutex (Lock): mutual exclusion for buffer access
      - empty_slots (Semaphore): initialized to buffer_capacity
      - full_slots (Semaphore): initialized to 0

    Parameters
    ----------
    buffer_capacity : int
        Maximum number of items the buffer can hold simultaneously.
    num_items : int
        Total number of items to produce and consume.
    delay : float
        Simulated processing time between thread operations (in seconds).
    timeout : float
        Maximum safety execution time in seconds.

    Returns
    -------
    dict with:
      - success: bool
      - buffer_capacity: int
      - total_items: int
      - event_log: list of dicts recording chronological events
      - final_buffer: list
      - peak_buffer_occupancy: int
      - items_produced: int
      - items_consumed: int
      - buffer_full_events: int
      - buffer_empty_events: int
    """
    if not isinstance(buffer_capacity, int) or buffer_capacity <= 0:
        raise ValueError(f"Buffer capacity must be a positive integer (got {buffer_capacity}).")
    if not isinstance(num_items, int) or num_items <= 0:
        raise ValueError(f"Number of items must be a positive integer (got {num_items}).")
    if buffer_capacity > 50:
        raise ValueError("Buffer capacity must not exceed 50 for visualization.")
    if num_items > 100:
        raise ValueError("Number of items must not exceed 100 for interactive simulation.")

    buffer: List[int] = []
    event_log: List[Dict[str, Any]] = []
    log_lock = threading.Lock()

    # Synchronization Primitives
    mutex = threading.Lock()
    empty_slots = threading.Semaphore(buffer_capacity)
    full_slots = threading.Semaphore(0)

    stats = {
        "items_produced": 0,
        "items_consumed": 0,
        "peak_occupancy": 0,
        "full_waits": 0,
        "empty_waits": 0,
    }

    start_time = time.time()

    def record_event(thread_name: str, action: str, item: Optional[int], buffer_snapshot: List[int], note: str = ""):
        with log_lock:
            occupancy = len(buffer_snapshot)
            if occupancy > stats["peak_occupancy"]:
                stats["peak_occupancy"] = occupancy

            event_log.append({
                "seq": len(event_log) + 1,
                "timestamp_ms": round((time.time() - start_time) * 1000, 2),
                "thread": thread_name,
                "action": action,
                "item": item,
                "buffer_state": list(buffer_snapshot),
                "occupancy": occupancy,
                "capacity": buffer_capacity,
                "note": note,
            })

    # Producer worker
    def producer_thread():
        for i in range(1, num_items + 1):
            if time.time() - start_time > timeout:
                break

            # If empty_slots is 0, producer must wait (buffer is full)
            if empty_slots._value == 0:
                with log_lock:
                    stats["full_waits"] += 1
                record_event("Producer", "BUFFER_FULL_WAIT", i, buffer, f"Buffer is full ({buffer_capacity}/{buffer_capacity}). Producer waiting...")

            acquired = empty_slots.acquire(timeout=timeout)
            if not acquired:
                break

            with mutex:
                buffer.append(i)
                stats["items_produced"] += 1
                record_event("Producer", "PRODUCED", i, buffer, f"Produced item #{i}. Buffer: {len(buffer)}/{buffer_capacity}")

            full_slots.release()
            if delay > 0:
                time.sleep(delay)

    # Consumer worker
    def consumer_thread():
        for _ in range(num_items):
            if time.time() - start_time > timeout:
                break

            # If full_slots is 0, consumer must wait (buffer is empty)
            if full_slots._value == 0:
                with log_lock:
                    stats["empty_waits"] += 1
                record_event("Consumer", "BUFFER_EMPTY_WAIT", None, buffer, "Buffer is empty (0 items). Consumer waiting...")

            acquired = full_slots.acquire(timeout=timeout)
            if not acquired:
                break

            with mutex:
                item = buffer.pop(0)
                stats["items_consumed"] += 1
                record_event("Consumer", "CONSUMED", item, buffer, f"Consumed item #{item}. Remaining in buffer: {len(buffer)}")

            empty_slots.release()
            if delay > 0:
                time.sleep(delay)

    p = threading.Thread(target=producer_thread, name="ProducerThread")
    c = threading.Thread(target=consumer_thread, name="ConsumerThread")

    p.start()
    c.start()

    p.join(timeout=timeout)
    c.join(timeout=timeout)

    success = (stats["items_produced"] == num_items and stats["items_consumed"] == num_items)

    return {
        "success": success,
        "buffer_capacity": buffer_capacity,
        "total_items": num_items,
        "items_produced": stats["items_produced"],
        "items_consumed": stats["items_consumed"],
        "peak_buffer_occupancy": stats["peak_occupancy"],
        "buffer_full_events": stats["full_waits"],
        "buffer_empty_events": stats["empty_waits"],
        "final_buffer": list(buffer),
        "event_log": event_log,
        "execution_time_ms": round((time.time() - start_time) * 1000, 2),
    }


def reader_writer_demo(
    num_readers: int = 4,
    num_writers: int = 2,
    operations_per_thread: int = 2,
    delay: float = 0.005,
    timeout: float = 5.0,
) -> Dict[str, Any]:
    """
    Controlled Reader–Writer synchronization demonstration.
    Implements standard first reader-writer solution (reader preference):
      - read_count: number of active readers
      - mutex (Lock): protects read_count
      - write_lock (Semaphore/Lock): ensures exclusive access for writers,
        acquired by the first reader and released by the last reader.

    Parameters
    ----------
    num_readers : int
        Number of concurrent reader threads (1..10).
    num_writers : int
        Number of writer threads (1..5).
    operations_per_thread : int
        Number of read/write cycles each thread executes (1..5).
    delay : float
        Simulated read/write operation duration.
    timeout : float
        Maximum total execution safety timeout.

    Returns
    -------
    dict with:
      - success: bool
      - total_readers: int
      - total_writers: int
      - peak_concurrent_readers: int
      - event_log: list of dicts recording chronological events
      - shared_data_value: int
      - reads_completed: int
      - writes_completed: int
      - mutual_exclusion_verified: bool
    """
    if not isinstance(num_readers, int) or num_readers <= 0 or num_readers > 10:
        raise ValueError("Number of readers must be between 1 and 10.")
    if not isinstance(num_writers, int) or num_writers <= 0 or num_writers > 5:
        raise ValueError("Number of writers must be between 1 and 5.")
    if not isinstance(operations_per_thread, int) or operations_per_thread <= 0 or operations_per_thread > 5:
        raise ValueError("Operations per thread must be between 1 and 5.")

    shared_resource = {"value": 0}
    event_log: List[Dict[str, Any]] = []
    log_lock = threading.Lock()

    # Reader-Writer Synchronization Primitives
    read_count = [0]
    read_count_lock = threading.Lock()
    write_lock = threading.Lock()

    active_state = {
        "active_readers": 0,
        "active_writers": 0,
        "peak_readers": 0,
        "reads_completed": 0,
        "writes_completed": 0,
        "violations": 0,
    }

    start_time = time.time()

    def record_event(thread_name: str, role: str, action: str, data_val: int, note: str = ""):
        with log_lock:
            readers = active_state["active_readers"]
            writers = active_state["active_writers"]

            # Mutual exclusion safety check
            if writers > 1 or (writers > 0 and readers > 0):
                active_state["violations"] += 1

            if readers > active_state["peak_readers"]:
                active_state["peak_readers"] = readers

            event_log.append({
                "seq": len(event_log) + 1,
                "timestamp_ms": round((time.time() - start_time) * 1000, 2),
                "thread": thread_name,
                "role": role,
                "action": action,
                "shared_value": data_val,
                "active_readers": readers,
                "active_writers": writers,
                "note": note,
            })

    def reader_worker(reader_id: int):
        name = f"Reader-{reader_id}"
        for op in range(operations_per_thread):
            if time.time() - start_time > timeout:
                break

            record_event(name, "Reader", "WAIT_ENTRY", shared_resource["value"], f"{name} requesting read access.")

            with read_count_lock:
                read_count[0] += 1
                if read_count[0] == 1:
                    # First reader acquires write_lock to block writers
                    write_lock.acquire()
                with log_lock:
                    active_state["active_readers"] = read_count[0]

            record_event(name, "Reader", "START_READ", shared_resource["value"], f"{name} reading data.")
            if delay > 0:
                time.sleep(delay)
            record_event(name, "Reader", "FINISH_READ", shared_resource["value"], f"{name} finished reading.")

            with read_count_lock:
                read_count[0] -= 1
                with log_lock:
                    active_state["active_readers"] = read_count[0]
                    active_state["reads_completed"] += 1
                if read_count[0] == 0:
                    # Last reader releases write_lock
                    write_lock.release()

            if delay > 0:
                time.sleep(delay)

    def writer_worker(writer_id: int):
        name = f"Writer-{writer_id}"
        for op in range(operations_per_thread):
            if time.time() - start_time > timeout:
                break

            record_event(name, "Writer", "WAIT_ENTRY", shared_resource["value"], f"{name} requesting exclusive write access.")

            write_lock.acquire()
            try:
                with log_lock:
                    active_state["active_writers"] = 1
                shared_resource["value"] += 10 * writer_id + op + 1
                val = shared_resource["value"]
                record_event(name, "Writer", "START_WRITE", val, f"{name} writing data (new value={val}).")
                if delay > 0:
                    time.sleep(delay)
                record_event(name, "Writer", "FINISH_WRITE", val, f"{name} finished writing.")
            finally:
                with log_lock:
                    active_state["active_writers"] = 0
                    active_state["writes_completed"] += 1
                write_lock.release()

            if delay > 0:
                time.sleep(delay)

    threads = []
    for r in range(1, num_readers + 1):
        threads.append(threading.Thread(target=reader_worker, args=(r,), name=f"Reader-{r}"))
    for w in range(1, num_writers + 1):
        threads.append(threading.Thread(target=writer_worker, args=(w,), name=f"Writer-{w}"))

    # Start all threads
    for t in threads:
        t.start()

    for t in threads:
        t.join(timeout=timeout)

    expected_reads = num_readers * operations_per_thread
    expected_writes = num_writers * operations_per_thread
    success = (
        active_state["reads_completed"] == expected_reads
        and active_state["writes_completed"] == expected_writes
        and active_state["violations"] == 0
    )

    return {
        "success": success,
        "num_readers": num_readers,
        "num_writers": num_writers,
        "operations_per_thread": operations_per_thread,
        "reads_completed": active_state["reads_completed"],
        "writes_completed": active_state["writes_completed"],
        "peak_concurrent_readers": active_state["peak_readers"],
        "mutual_exclusion_verified": (active_state["violations"] == 0),
        "violations": active_state["violations"],
        "shared_data_value": shared_resource["value"],
        "event_log": event_log,
        "execution_time_ms": round((time.time() - start_time) * 1000, 2),
    }
