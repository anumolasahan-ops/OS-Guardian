"""
algorithms/memory_management.py
================================
Contiguous Memory Allocation Simulator (Milestone 4).

Implements three classical variable-partition / fixed-partition contiguous
memory allocation placement strategies:
  - First Fit : Allocate the first block that is large enough.
  - Best Fit  : Allocate the smallest block that is large enough.
  - Worst Fit : Allocate the largest block that is large enough.

Allocation Model & Assumptions
-------------------------------
1. Single-Process Per Block: Each physical or pre-existing partition block
   can host at most one process.
2. Contiguous allocation: Processes cannot be divided across blocks.
3. Internal Fragmentation: When process of size P is assigned to a block
   of size B (B >= P), the unused remainder (B - P) within that allocated block
   is considered internal fragmentation for that allocation.
4. Unallocated processes: If no available block is large enough, the process
   remains unallocated (allocation status: None).
5. Tie-breaking rules:
   - Blocks are inspected in order of their initial block ID (0, 1, 2, ...).
   - First Fit: First available block index where block_size >= process_size.
   - Best Fit: Available block that minimizes (block_size - process_size).
     Ties broken by the lowest block index.
   - Worst Fit: Available block that maximizes (block_size - process_size).
     Ties broken by the lowest block index.
6. Validation:
   - Block sizes must be strictly positive integers (> 0).
   - Process sizes must be strictly positive integers (> 0).
   - Empty lists of blocks or processes are rejected with ValueError.
"""

from copy import deepcopy


def _validate_inputs(blocks, processes):
    """
    Validate input block sizes and process definitions.

    Parameters
    ----------
    blocks : list[int | dict]
        List of block sizes or dicts with 'id' and 'size'.
    processes : list[int | dict]
        List of process sizes or dicts with 'pid' and 'size'.

    Returns
    -------
    tuple (normalized_blocks, normalized_processes)
    """
    if not blocks:
        raise ValueError("Block list is empty. Provide at least one memory block.")
    if not processes:
        raise ValueError("Process list is empty. Provide at least one process.")

    norm_blocks = []
    for idx, b in enumerate(blocks):
        if isinstance(b, dict):
            bid = str(b.get("id", f"B{idx + 1}")).strip() or f"B{idx + 1}"
            raw_size = b.get("size")
        else:
            bid = f"B{idx + 1}"
            raw_size = b

        try:
            size = int(raw_size)
        except (TypeError, ValueError):
            raise ValueError(f"Block '{bid}' size must be a positive integer.")
        if size <= 0:
            raise ValueError(f"Block '{bid}' size must be greater than 0 (got {size}).")

        norm_blocks.append({"id": bid, "original_size": size, "current_size": size, "index": idx})

    norm_procs = []
    seen_pids = set()
    for idx, p in enumerate(processes):
        if isinstance(p, dict):
            pid = str(p.get("pid", f"P{idx + 1}")).strip() or f"P{idx + 1}"
            raw_size = p.get("size")
        else:
            pid = f"P{idx + 1}"
            raw_size = p

        if pid in seen_pids:
            raise ValueError(f"Duplicate process ID '{pid}'. Each process ID must be unique.")
        seen_pids.add(pid)

        try:
            size = int(raw_size)
        except (TypeError, ValueError):
            raise ValueError(f"Process '{pid}' size must be a positive integer.")
        if size <= 0:
            raise ValueError(f"Process '{pid}' size must be greater than 0 (got {size}).")

        norm_procs.append({"pid": pid, "size": size, "index": idx})

    return norm_blocks, norm_procs


def _allocate(blocks, processes, strategy):
    """
    Generic placement engine for contiguous memory allocation.
    """
    b_list, p_list = _validate_inputs(blocks, processes)

    # State tracking
    # Each block can hold at most 1 process: allocated_process = None or pid
    block_state = [
        {
            "id": b["id"],
            "index": b["index"],
            "total_size": b["original_size"],
            "allocated_process": None,
            "allocated_size": 0,
            "fragmentation": 0,
        }
        for b in b_list
    ]

    allocations = []
    step_trace = []

    for step_num, proc in enumerate(p_list, start=1):
        pid = proc["pid"]
        psize = proc["size"]

        # Find candidate free blocks with total_size >= psize
        candidates = [
            (i, blk)
            for i, blk in enumerate(block_state)
            if blk["allocated_process"] is None and blk["total_size"] >= psize
        ]

        chosen_idx = None
        if candidates:
            if strategy == "first_fit":
                # First available candidate by index
                chosen_idx = candidates[0][0]
            elif strategy == "best_fit":
                # Candidate with minimum remaining capacity (total_size - psize)
                # Ties broken by earliest index
                best = min(candidates, key=lambda c: (c[1]["total_size"] - psize, c[0]))
                chosen_idx = best[0]
            elif strategy == "worst_fit":
                # Candidate with maximum remaining capacity (total_size - psize)
                # Ties broken by earliest index
                worst = max(candidates, key=lambda c: (c[1]["total_size"] - psize, -c[0]))
                chosen_idx = worst[0]

        if chosen_idx is not None:
            blk = block_state[chosen_idx]
            frag = blk["total_size"] - psize
            blk["allocated_process"] = pid
            blk["allocated_size"] = psize
            blk["fragmentation"] = frag

            allocations.append({
                "pid": pid,
                "process_size": psize,
                "allocated": True,
                "block_id": blk["id"],
                "block_index": blk["index"],
                "block_size": blk["total_size"],
                "fragmentation": frag,
            })
            step_trace.append({
                "step": step_num,
                "pid": pid,
                "size": psize,
                "action": f"Allocated to {blk['id']}",
                "block_id": blk["id"],
                "block_size": blk["total_size"],
                "fragmentation": frag,
                "status": "Allocated",
                "reason": f"Block {blk['id']} ({blk['total_size']} KB) selected for process {pid} ({psize} KB) leaving {frag} KB residual space."
            })
        else:
            allocations.append({
                "pid": pid,
                "process_size": psize,
                "allocated": False,
                "block_id": None,
                "block_index": None,
                "block_size": None,
                "fragmentation": None,
            })
            step_trace.append({
                "step": step_num,
                "pid": pid,
                "size": psize,
                "action": "Unallocated",
                "block_id": None,
                "block_size": None,
                "fragmentation": None,
                "status": "Unallocated",
                "reason": f"No available memory block has sufficient capacity >= {psize} KB."
            })

    # Summary metrics
    total_memory = sum(b["total_size"] for b in block_state)
    allocated_memory = sum(b["allocated_size"] for b in block_state)
    total_internal_frag = sum(b["fragmentation"] for b in block_state if b["allocated_process"] is not None)
    unallocated_procs = [a["pid"] for a in allocations if not a["allocated"]]
    unallocated_memory_requested = sum(a["process_size"] for a in allocations if not a["allocated"])
    free_blocks_count = sum(1 for b in block_state if b["allocated_process"] is None)
    free_blocks_memory = sum(b["total_size"] for b in block_state if b["allocated_process"] is None)

    metrics = {
        "total_memory": total_memory,
        "allocated_memory": allocated_memory,
        "total_internal_fragmentation": total_internal_frag,
        "allocated_processes_count": len(p_list) - len(unallocated_procs),
        "unallocated_processes_count": len(unallocated_procs),
        "unallocated_pids": unallocated_procs,
        "unallocated_memory_requested": unallocated_memory_requested,
        "free_blocks_count": free_blocks_count,
        "free_blocks_memory": free_blocks_memory,
        "utilization_percentage": round((allocated_memory / total_memory) * 100, 2) if total_memory > 0 else 0.0,
    }

    return {
        "strategy": strategy,
        "allocations": allocations,
        "step_trace": step_trace,
        "blocks": block_state,
        "metrics": metrics,
    }


def first_fit(blocks, processes):
    """
    First Fit memory allocation.

    Allocates each process to the first memory block that is large enough.
    """
    return _allocate(blocks, processes, "first_fit")


def best_fit(blocks, processes):
    """
    Best Fit memory allocation.

    Allocates each process to the smallest memory block that is large enough.
    """
    return _allocate(blocks, processes, "best_fit")


def worst_fit(blocks, processes):
    """
    Worst Fit memory allocation.

    Allocates each process to the largest memory block that is large enough.
    """
    return _allocate(blocks, processes, "worst_fit")
