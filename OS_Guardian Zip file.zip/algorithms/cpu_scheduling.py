"""
algorithms/cpu_scheduling.py
============================
CPU Scheduling algorithm simulator (Milestone 3).

Implements four non-preemptive / cooperative scheduling algorithms:
  - FCFS  : First Come First Served
  - SJF   : Shortest Job First (non-preemptive)
  - Priority : Priority Scheduling (non-preemptive, lower number = higher priority)
  - Round Robin : with configurable time quantum

All functions share the same input/output contract:

Input
-----
processes : list[dict]
    Each dict must contain:
      pid          : str   – process identifier
      arrival_time : int   – time the process enters the ready queue (>= 0)
      burst_time   : int   – total CPU time needed (> 0)
      priority     : int   – used only by priority_scheduling (lower = higher priority)

Output (per function)
----------------------
dict with keys:
  gantt    : list[dict]  – [{pid, start, end}, ...]  (includes IDLE slots)
  results  : list[dict]  – per-process metrics (sorted by pid for display)
  metrics  : dict        – avg_turnaround, avg_waiting, avg_response, cpu_utilization
  errors   : list[str]   – non-fatal warnings (empty on clean run)

Tie-breaking rules (documented so tests can rely on them)
----------------------------------------------------------
  FCFS      : ties broken by arrival_time first, then pid (lexicographic)
  SJF       : ties on burst_time broken by arrival_time, then pid
  Priority  : ties on priority broken by arrival_time, then pid
  Round Robin: order of first arrival determines queue position;
               simultaneous arrivals sorted by pid

CPU Utilisation assumption
--------------------------
  cpu_utilization = (total_burst_time / makespan) * 100
  where makespan = last_completion_time - min_arrival_time.
  Idle gaps between processes are counted as non-utilised time.
  This is the standard textbook definition for a single-CPU simulator.

This is a SIMULATOR. Results do not reflect real kernel behaviour.
"""

from copy import deepcopy


# ──────────────────────────────────────────────────────────────────────────────
#  Input validation
# ──────────────────────────────────────────────────────────────────────────────

def _validate(processes, require_priority=False):
    """
    Validate and normalise the process list.

    Returns a deep-copied, normalised list on success.
    Raises ValueError with a descriptive message on any error.
    """
    if not processes:
        raise ValueError("Process list is empty. Enter at least one process.")

    seen_pids = set()
    normalised = []

    for raw in processes:
        p = deepcopy(raw)

        # --- pid ---
        pid = str(p.get("pid", "")).strip()
        if not pid:
            raise ValueError("Every process must have a non-empty process ID.")
        if pid in seen_pids:
            raise ValueError(f"Duplicate process ID: '{pid}'. Each PID must be unique.")
        seen_pids.add(pid)
        p["pid"] = pid

        # --- arrival_time ---
        try:
            at = int(p["arrival_time"])
        except (KeyError, TypeError, ValueError):
            raise ValueError(f"Process '{pid}': arrival_time must be a non-negative integer.")
        if at < 0:
            raise ValueError(f"Process '{pid}': arrival_time cannot be negative (got {at}).")
        p["arrival_time"] = at

        # --- burst_time ---
        try:
            bt = int(p["burst_time"])
        except (KeyError, TypeError, ValueError):
            raise ValueError(f"Process '{pid}': burst_time must be a positive integer.")
        if bt <= 0:
            raise ValueError(f"Process '{pid}': burst_time must be > 0 (got {bt}).")
        p["burst_time"] = bt

        # --- priority (only when required) ---
        if require_priority:
            try:
                pr = int(p["priority"])
            except (KeyError, TypeError, ValueError):
                raise ValueError(f"Process '{pid}': priority must be an integer.")
            p["priority"] = pr

        normalised.append(p)

    return normalised


# ──────────────────────────────────────────────────────────────────────────────
#  Metric calculation helpers
# ──────────────────────────────────────────────────────────────────────────────

def _compute_metrics(processes, completion_map, start_map):
    """
    Given completion and first-start times per pid, compute all per-process
    metrics and aggregate averages.

    completion_map : {pid: completion_time}
    start_map      : {pid: first_start_time}
    """
    results = []
    for p in processes:
        pid = p["pid"]
        at  = p["arrival_time"]
        bt  = p["burst_time"]
        ct  = completion_map[pid]
        st  = start_map[pid]

        tat = ct - at           # turnaround time
        wt  = tat - bt          # waiting time
        rt  = st - at           # response time

        results.append({
            "pid":             pid,
            "arrival_time":    at,
            "burst_time":      bt,
            "completion_time": ct,
            "turnaround_time": tat,
            "waiting_time":    wt,
            "response_time":   rt,
        })

    n = len(results)
    avg_tat = round(sum(r["turnaround_time"] for r in results) / n, 2)
    avg_wt  = round(sum(r["waiting_time"]    for r in results) / n, 2)
    avg_rt  = round(sum(r["response_time"]   for r in results) / n, 2)

    total_burst = sum(p["burst_time"] for p in processes)
    min_arrival = min(p["arrival_time"] for p in processes)
    last_ct     = max(completion_map.values())
    makespan    = last_ct - min_arrival
    cpu_util    = round((total_burst / makespan) * 100, 2) if makespan > 0 else 100.0

    metrics = {
        "avg_turnaround":   avg_tat,
        "avg_waiting":      avg_wt,
        "avg_response":     avg_rt,
        "cpu_utilization":  cpu_util,
        "total_burst":      total_burst,
        "makespan":         makespan,
    }
    return results, metrics


def _build_execution_trace(gantt):
    """Build chronological step-by-step execution trace from Gantt timeline."""
    trace = []
    for step_num, slot in enumerate(gantt, start=1):
        is_idle = slot["pid"] == "IDLE"
        duration = slot["end"] - slot["start"]
        trace.append({
            "step": step_num,
            "pid": slot["pid"],
            "start": slot["start"],
            "end": slot["end"],
            "duration": duration,
            "description": "CPU Idle — waiting for arriving processes" if is_idle else f"Process {slot['pid']} executed on CPU for {duration} ms.",
        })
    return trace


# ──────────────────────────────────────────────────────────────────────────────
#  FCFS
# ──────────────────────────────────────────────────────────────────────────────

def fcfs(processes):
    """
    First Come First Served (non-preemptive).

    Processes are executed in order of arrival_time.
    Tie-breaking: arrival_time ASC, then pid ASC (lexicographic).

    Parameters
    ----------
    processes : list[dict]  – see module docstring

    Returns
    -------
    dict  – see module docstring
    """
    procs = _validate(processes)

    # Sort: arrival_time ASC, pid ASC on ties
    ordered = sorted(procs, key=lambda p: (p["arrival_time"], p["pid"]))

    gantt          = []
    completion_map = {}
    start_map      = {}
    current_time   = 0

    for p in ordered:
        at = p["arrival_time"]
        bt = p["burst_time"]

        if current_time < at:
            # CPU is idle until this process arrives
            gantt.append({"pid": "IDLE", "start": current_time, "end": at})
            current_time = at

        start_map[p["pid"]]      = current_time
        gantt.append({"pid": p["pid"], "start": current_time, "end": current_time + bt})
        current_time            += bt
        completion_map[p["pid"]] = current_time

    results, metrics = _compute_metrics(procs, completion_map, start_map)
    return {"gantt": gantt, "execution_trace": _build_execution_trace(gantt), "results": results, "metrics": metrics, "errors": []}


# ──────────────────────────────────────────────────────────────────────────────
#  SJF (non-preemptive)
# ──────────────────────────────────────────────────────────────────────────────

def sjf(processes):
    """
    Shortest Job First – non-preemptive.

    At each scheduling decision point, the process in the ready queue with the
    smallest burst_time is selected. If the CPU becomes idle and no process is
    ready, time advances to the next earliest arrival.

    Tie-breaking: burst_time ASC, arrival_time ASC, pid ASC.

    Parameters
    ----------
    processes : list[dict]  – see module docstring

    Returns
    -------
    dict  – see module docstring
    """
    procs = _validate(processes)

    remaining    = list(procs)        # processes not yet scheduled
    gantt        = []
    completion_map = {}
    start_map      = {}
    current_time   = 0

    while remaining:
        # Collect all processes that have arrived by current_time
        ready = [p for p in remaining if p["arrival_time"] <= current_time]

        if not ready:
            # No process ready — advance to next arrival
            next_at = min(p["arrival_time"] for p in remaining)
            gantt.append({"pid": "IDLE", "start": current_time, "end": next_at})
            current_time = next_at
            ready = [p for p in remaining if p["arrival_time"] <= current_time]

        # Pick shortest job; tie-break by arrival_time, then pid
        chosen = min(ready, key=lambda p: (p["burst_time"], p["arrival_time"], p["pid"]))
        remaining.remove(chosen)

        at = chosen["arrival_time"]
        bt = chosen["burst_time"]

        start_map[chosen["pid"]]      = current_time
        gantt.append({"pid": chosen["pid"], "start": current_time, "end": current_time + bt})
        current_time                 += bt
        completion_map[chosen["pid"]] = current_time

    results, metrics = _compute_metrics(procs, completion_map, start_map)
    return {"gantt": gantt, "execution_trace": _build_execution_trace(gantt), "results": results, "metrics": metrics, "errors": []}


# ──────────────────────────────────────────────────────────────────────────────
#  Priority Scheduling (non-preemptive)
# ──────────────────────────────────────────────────────────────────────────────

def priority_scheduling(processes):
    """
    Priority Scheduling – non-preemptive.

    Lower priority number = higher priority (e.g. priority 1 runs before priority 2).
    At each scheduling decision point, the ready process with the lowest priority
    number is selected.

    Tie-breaking: priority ASC, arrival_time ASC, pid ASC.

    Parameters
    ----------
    processes : list[dict]
        Each dict must also contain priority : int

    Returns
    -------
    dict  – see module docstring
    """
    procs = _validate(processes, require_priority=True)

    remaining      = list(procs)
    gantt          = []
    completion_map = {}
    start_map      = {}
    current_time   = 0

    while remaining:
        ready = [p for p in remaining if p["arrival_time"] <= current_time]

        if not ready:
            next_at = min(p["arrival_time"] for p in remaining)
            gantt.append({"pid": "IDLE", "start": current_time, "end": next_at})
            current_time = next_at
            ready = [p for p in remaining if p["arrival_time"] <= current_time]

        # Lowest priority number wins; tie-break by arrival_time, then pid
        chosen = min(ready, key=lambda p: (p["priority"], p["arrival_time"], p["pid"]))
        remaining.remove(chosen)

        bt = chosen["burst_time"]
        start_map[chosen["pid"]]      = current_time
        gantt.append({"pid": chosen["pid"], "start": current_time, "end": current_time + bt})
        current_time                 += bt
        completion_map[chosen["pid"]] = current_time

    results, metrics = _compute_metrics(procs, completion_map, start_map)
    return {"gantt": gantt, "execution_trace": _build_execution_trace(gantt), "results": results, "metrics": metrics, "errors": []}


# ──────────────────────────────────────────────────────────────────────────────
#  Round Robin
# ──────────────────────────────────────────────────────────────────────────────

def round_robin(processes, quantum):
    """
    Round Robin scheduling with a configurable time quantum.

    Queue management:
      - A process enters the ready queue when its arrival_time <= current_time.
      - When the running process yields (quantum expired or finishes), newly
        arrived processes are enqueued BEFORE the preempted process is re-queued
        (standard textbook behaviour).
      - Simultaneous first arrivals are sorted by pid (ASC) before enqueuing.

    Parameters
    ----------
    processes : list[dict]  – see module docstring
    quantum   : int         – time quantum (must be > 0)

    Returns
    -------
    dict  – see module docstring
    """
    procs = _validate(processes)

    try:
        quantum = int(quantum)
    except (TypeError, ValueError):
        raise ValueError("Time quantum must be a positive integer.")
    if quantum <= 0:
        raise ValueError(f"Time quantum must be > 0 (got {quantum}).")

    # Work with mutable copies tracking remaining burst time
    tasks = [
        {**p, "remaining": p["burst_time"]}
        for p in sorted(procs, key=lambda p: (p["arrival_time"], p["pid"]))
    ]

    gantt          = []
    completion_map = {}
    start_map      = {}
    current_time   = tasks[0]["arrival_time"]  # start at first arrival
    queue          = []
    arrived        = set()

    def _enqueue_new_arrivals(t):
        """Add processes that have arrived by time t (first-time only), sorted by pid."""
        newcomers = sorted(
            [p for p in tasks if p["arrival_time"] <= t and p["pid"] not in arrived],
            key=lambda p: p["pid"]
        )
        for nc in newcomers:
            arrived.add(nc["pid"])
            queue.append(nc)

    # Seed the queue with processes already arrived at start
    _enqueue_new_arrivals(current_time)

    while queue or any(p["pid"] not in completion_map for p in tasks):
        if not queue:
            # CPU idle — jump to next arrival
            not_done = [p for p in tasks if p["pid"] not in completion_map]
            next_at  = min(p["arrival_time"] for p in not_done)
            gantt.append({"pid": "IDLE", "start": current_time, "end": next_at})
            current_time = next_at
            _enqueue_new_arrivals(current_time)
            continue

        proc = queue.pop(0)
        pid  = proc["pid"]

        # Record first start time
        if pid not in start_map:
            start_map[pid] = current_time

        # How long this slice runs
        slice_time   = min(quantum, proc["remaining"])
        slice_end    = current_time + slice_time
        gantt.append({"pid": pid, "start": current_time, "end": slice_end})

        proc["remaining"] -= slice_time
        current_time       = slice_end

        # Enqueue newly arrived processes (they go ahead of the preempted process)
        _enqueue_new_arrivals(current_time)

        if proc["remaining"] == 0:
            completion_map[pid] = current_time
        else:
            # Re-queue preempted process at the back
            queue.append(proc)

    results, metrics = _compute_metrics(procs, completion_map, start_map)
    return {"gantt": gantt, "execution_trace": _build_execution_trace(gantt), "results": results, "metrics": metrics, "errors": []}
