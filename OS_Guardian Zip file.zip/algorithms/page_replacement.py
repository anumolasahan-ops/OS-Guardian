"""
algorithms/page_replacement.py
================================
Page Replacement Algorithm Simulator (Milestone 4).

Implements three classical virtual memory demand paging algorithms:
  - FIFO    : First-In, First-Out replacement
  - LRU     : Least Recently Used replacement
  - Optimal : Belady's Optimal replacement (clairvoyant)

Simulation Model & Specifications
----------------------------------
1. Demand paging model:
   - Initial state: all frame slots are empty (None).
   - If a referenced page is currently in any frame, it is a PAGE HIT.
   - If not in any frame, it is a PAGE FAULT.
   - If there is an empty slot, the faulting page occupies the first empty slot.
   - If frames are full, a victim page is selected according to the algorithm policy.
2. Policies:
   - FIFO: The page that entered memory earliest is replaced.
   - LRU: The page that has not been referenced for the longest time in the past is replaced.
   - Optimal: The page that will not be referenced for the longest time in the future is replaced.
     If multiple pages in memory will never be referenced again, tie-breaking chooses
     the page with the earliest arrival in frames (FIFO order among unreferenced).
3. Frame representation:
   - Fixed capacity of `num_frames` (> 0).
   - Snapshot returned for each reference step showing the exact list of pages in frames.
4. Metrics:
   - Total references, total hits, total faults, hit ratio, fault ratio.
"""


def _validate_inputs(pages, num_frames):
    """
    Validate page reference sequence and frame count.
    """
    if pages is None:
        raise ValueError("Page reference list cannot be empty.")

    # Convert string or list to list of clean tokens
    if isinstance(pages, str):
        tokens = [t.strip() for t in pages.replace(",", " ").split() if t.strip()]
    elif isinstance(pages, (list, tuple)):
        tokens = [str(t).strip() for t in pages if str(t).strip() != ""]
    else:
        raise ValueError("Pages must be provided as a sequence or comma/space-separated string.")

    if not tokens:
        raise ValueError("Page reference sequence is empty. Provide at least one page.")

    # Convert all tokens to integer page numbers if possible, or clean strings
    norm_pages = []
    for t in tokens:
        try:
            norm_pages.append(int(t))
        except ValueError:
            norm_pages.append(t)

    try:
        frames_count = int(num_frames)
    except (TypeError, ValueError):
        raise ValueError("Number of frames must be a positive integer.")

    if frames_count <= 0:
        raise ValueError(f"Number of frames must be greater than 0 (got {frames_count}).")

    return norm_pages, frames_count


def fifo(pages, num_frames):
    """
    First-In, First-Out (FIFO) page replacement algorithm.
    """
    ref_pages, capacity = _validate_inputs(pages, num_frames)

    frames = []          # List of currently resident pages
    steps = []
    hits = 0
    faults = 0

    for idx, page in enumerate(ref_pages):
        is_hit = page in frames
        replaced_page = None

        if is_hit:
            hits += 1
        else:
            faults += 1
            if len(frames) < capacity:
                frames.append(page)
            else:
                replaced_page = frames.pop(0)  # Oldest resident is evicted
                frames.append(page)

        # Pad snapshot with None for visual clarity of empty slots
        snapshot = list(frames) + [None] * (capacity - len(frames))

        steps.append({
            "step": idx + 1,
            "page": page,
            "hit": is_hit,
            "replaced": replaced_page,
            "frames": snapshot,
        })

    total = len(ref_pages)
    fault_ratio = round((faults / total) * 100, 2)
    hit_ratio = round((hits / total) * 100, 2)

    return {
        "algorithm": "fifo",
        "num_frames": capacity,
        "total_references": total,
        "page_hits": hits,
        "page_faults": faults,
        "hit_ratio": hit_ratio,
        "fault_ratio": fault_ratio,
        "steps": steps,
    }


def lru(pages, num_frames):
    """
    Least Recently Used (LRU) page replacement algorithm.
    """
    ref_pages, capacity = _validate_inputs(pages, num_frames)

    frames = []          # List of currently resident pages
    last_used = {}       # page -> last step index accessed
    steps = []
    hits = 0
    faults = 0

    for idx, page in enumerate(ref_pages):
        is_hit = page in frames
        replaced_page = None

        if is_hit:
            hits += 1
            last_used[page] = idx
        else:
            faults += 1
            if len(frames) < capacity:
                frames.append(page)
            else:
                # Evict resident page with minimum last_used value
                victim = min(frames, key=lambda p: last_used[p])
                replaced_page = victim
                frames[frames.index(victim)] = page
            last_used[page] = idx

        snapshot = list(frames) + [None] * (capacity - len(frames))

        steps.append({
            "step": idx + 1,
            "page": page,
            "hit": is_hit,
            "replaced": replaced_page,
            "frames": snapshot,
        })

    total = len(ref_pages)
    fault_ratio = round((faults / total) * 100, 2)
    hit_ratio = round((hits / total) * 100, 2)

    return {
        "algorithm": "lru",
        "num_frames": capacity,
        "total_references": total,
        "page_hits": hits,
        "page_faults": faults,
        "hit_ratio": hit_ratio,
        "fault_ratio": fault_ratio,
        "steps": steps,
    }


def optimal(pages, num_frames):
    """
    Optimal (Belady's) page replacement algorithm.
    """
    ref_pages, capacity = _validate_inputs(pages, num_frames)

    frames = []          # List of resident pages
    steps = []
    hits = 0
    faults = 0

    for idx, page in enumerate(ref_pages):
        is_hit = page in frames
        replaced_page = None

        if is_hit:
            hits += 1
        else:
            faults += 1
            if len(frames) < capacity:
                frames.append(page)
            else:
                # Find page that will not be used for longest time in future
                future_refs = ref_pages[idx + 1:]
                farthest_idx = -1
                victim = None

                for p in frames:
                    if p not in future_refs:
                        # Never referenced again in future: prime eviction candidate
                        victim = p
                        break
                    else:
                        next_use = future_refs.index(p)
                        if next_use > farthest_idx:
                            farthest_idx = next_use
                            victim = p

                replaced_page = victim
                frames[frames.index(victim)] = page

        snapshot = list(frames) + [None] * (capacity - len(frames))

        steps.append({
            "step": idx + 1,
            "page": page,
            "hit": is_hit,
            "replaced": replaced_page,
            "frames": snapshot,
        })

    total = len(ref_pages)
    fault_ratio = round((faults / total) * 100, 2)
    hit_ratio = round((hits / total) * 100, 2)

    return {
        "algorithm": "optimal",
        "num_frames": capacity,
        "total_references": total,
        "page_hits": hits,
        "page_faults": faults,
        "hit_ratio": hit_ratio,
        "fault_ratio": fault_ratio,
        "steps": steps,
    }
