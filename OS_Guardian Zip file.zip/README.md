# OS Guardian – Intelligent Process, Memory & Resource Management Simulator

An educational Operating Systems algorithm simulator built with Python, Flask, Bootstrap 5, Chart.js, and SQLite.

> **Educational Simulator Notice:** All results are produced by simulator algorithms
> and do **not** represent real kernel operations or physical hardware measurements.

---

## Team Responsibilities

| Member | Primary Responsibility |
|--------|----------------------|
| Member 1 | CPU Scheduling · Gantt Chart Visualization · CPU Scheduling Test Suite |
| Member 2 | Memory Allocation · Page Replacement · Dynamic Frame Matrices |
| Member 3 | Banker's Algorithm · Thread Synchronization · SQLite Database · Performance Comparison |

---

## Key Features

1. **CPU Scheduling:**
   - Algorithms: First-Come First-Served (FCFS), Shortest Job First (SJF Non-preemptive), Priority Scheduling (Non-preemptive), and Round Robin (RR with configurable time quantum).
   - Metrics: Completion time, Turnaround time, Waiting time, Response time, CPU utilization %, and total makespan.
   - Visualization: Real floating-bar Gantt chart rendered with Chart.js with IDLE period tracking.

2. **Memory Allocation:**
   - Contiguous allocation strategies: First Fit, Best Fit, Worst Fit.
   - Metrics: Allocated vs. unallocated processes, memory utilization %, total internal fragmentation.
   - Visualization: Dynamic memory block proportion map with color-coded internal fragmentation slices.

3. **Page Replacement:**
   - Algorithms: First-In First-Out (FIFO), Least Recently Used (LRU), and Belady's Optimal (OPT).
   - Metrics: Total page references, page hits, page faults, hit ratio %, fault ratio %.
   - Visualization: Interactive step-by-step frame snapshot matrix with color-coded hit/miss badges and Belady's anomaly preset.

4. **Deadlock Management:**
   - Implementation: Complete Banker's Safety Algorithm with Need matrix calculation ($Need = Max - Allocation$).
   - Step trace: Step-by-step execution trace tracking Work and Finish vectors.
   - Resource-Request simulation: Tentative allocation test with automatic rollback upon unsafe state detection.

5. **Thread Synchronization:**
   - Producer–Consumer: Real multi-threaded simulation using bounded buffer, counting semaphores (`empty`, `full`), and mutex locks.
   - Reader–Writer: Classic first readers-writers problem (reader-preference) with mutual exclusion for writers and concurrent reading.
   - Zero deadlock guarantee: Controlled thread lifecycle with verified termination and real-time event logs.

6. **Performance Comparison Engine:**
   - Side-by-side benchmarking on identical workloads for CPU scheduling, memory allocation, and page replacement.
   - Selective algorithm subsets: users can choose 2 to 4 specific algorithms to evaluate focused trade-offs.
   - Automated identification and highlighting of best-performing algorithms.
   - Comparative multi-metric bar charts and grounded qualitative trade-off recommendations.

7. **Windows System Monitor & Deadlock Detection:**
   - Real-time read-only Windows host snapshot using `psutil` (CPU %, physical/logical core breakdown, RAM, Swap, and top active processes).
   - Multi-resource formal Deadlock Detection Algorithm (Work/Finish vector reduction) with complete progression trace.
   - Clear academic disclaimer distinguishing theoretical deadlock algorithms from live OS handle synchronization.
   - Zero unsafe kernel operations (pure telemetry).

8. **Excel Export Engine:**
   - Multi-worksheet styled `.xlsx` workbook generation via `openpyxl`.
   - Downloadable reports for Live System Snapshots, Deadlock Analysis, Comparison Benchmarks, and Simulation History.

9. **Step-by-Step Execution Traces:**
   - Detailed timeline traces rendered across CPU Scheduling, Memory Allocation, Page Replacement, Deadlock Management, and Synchronization.

10. **Simulation History & Persistence:**
   - Local persistence in SQLite (`database/os_guardian.db`).
   - Audit log with filter tabs (All, CPU, Memory, Paging, Deadlock, Synchronization, Comparison, System Monitor).
   - Record inspection modal, Excel export, and individual record deletion / complete history purge.

---

## Prerequisites

- Windows 10/11
- Python 3.10 to 3.12 (verify with `py --version`)
- Git 2.x or later (verify with `git --version`)
- Web browser with internet access (Bootstrap 5, Chart.js, and Bootstrap Icons loaded via CDN)

---

## Quick Start (Windows)

### 1. Open PowerShell and navigate to the project directory

```powershell
cd "C:\Users\sahan\OneDrive\Desktop\OS-Guardian"
```

### 2. Activate the virtual environment

```powershell
.\venv\Scripts\Activate.ps1
```

*(If PowerShell script execution is restricted, run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`)*

### 3. Verify dependencies

```powershell
pip install -r requirements.txt
```

### 4. Run the application

```powershell
python app.py
```

### 5. Access the Web Dashboard

Open your web browser at: **http://127.0.0.1:5000**

---

## Running Automated Tests

Run the full automated test suite (151 tests) with pytest:

```powershell
.\venv\Scripts\python.exe -m pytest tests/ -v
```

Expected output: **151 passed** (0 failures, 100% passing).

To run specific test modules:

```powershell
.\venv\Scripts\python.exe -m pytest tests/test_system_monitor.py -v
.\venv\Scripts\python.exe -m pytest tests/test_export.py -v
.\venv\Scripts\python.exe -m pytest tests/test_deadlock.py -v
.\venv\Scripts\python.exe -m pytest tests/test_synchronization.py -v
.\venv\Scripts\python.exe -m pytest tests/test_comparison.py -v
.\venv\Scripts\python.exe -m pytest tests/test_database.py -v
.\venv\Scripts\python.exe -m pytest tests/test_routes.py -v
```

---

## Project Structure

```
OS-Guardian/
├── app.py                      # Flask application factory, error handlers & all API routes
├── requirements.txt            # Pinned dependencies (Flask, pytest, psutil, openpyxl)
├── README.md                   # Project documentation & execution guide
├── algorithms/                 # Pure algorithmic core modules
│   ├── cpu_scheduling.py       # FCFS, SJF, Priority, Round Robin & execution traces
│   ├── memory_management.py    # First Fit, Best Fit, Worst Fit & placement traces
│   ├── page_replacement.py     # FIFO, LRU, Optimal & frame matrix steps
│   ├── deadlock.py             # Banker's Safety & Resource Request algorithms
│   ├── synchronization.py     # Thread-safe Producer-Consumer & Reader-Writer simulations
│   ├── comparison.py          # Unified multi-algorithm benchmark comparisons & trade-offs
│   ├── system_monitor.py      # Live Windows psutil telemetry & deadlock detection
│   └── export_utils.py        # Professional multi-sheet Excel (.xlsx) workbook generator
├── database/                   # SQLite persistence layer
│   ├── db_utils.py             # Database initialization, CRUD operations & aggregations
│   └── os_guardian.db          # SQLite database file (preserved records)
├── templates/                  # Bootstrap 5 Jinja2 HTML templates
│   ├── base.html               # Shared layout, responsive sidebar & topbar
│   ├── index.html              # Main dashboard with module cards & progress
│   ├── scheduling.html         # CPU scheduling simulator, Gantt chart & execution trace
│   ├── memory.html             # Memory allocation simulator, block map & decision trace
│   ├── paging.html             # Page replacement simulator & frame matrix
│   ├── deadlock.html           # Banker's algorithm matrix builder & safety trace
│   ├── synchronization.html    # Concurrency visualizer & live event logger
│   ├── comparison.html         # Performance comparison engine, 2-4 algorithm selector & charts
│   ├── system_monitor.html     # Live Windows host monitor & multi-resource deadlock detector
│   └── history.html            # SQLite simulation history, Excel export & inspection modal
├── static/                     # Frontend static assets
│   ├── css/style.css           # Custom modern dark-accented styling
│   └── js/                     # Modular frontend controllers
│       ├── scheduling.js       # CPU scheduling UI, Chart.js Gantt & trace builder
│       ├── memory.js           # Memory allocation UI, proportional map & decision log
│       ├── paging.js           # Paging UI & frame matrix generator
│       ├── deadlock.js         # Matrix builder, safety trace & request handler
│       ├── synchronization.js  # Thread visualizer, buffer slots & event logs
│       ├── comparison.js       # Comparison benchmark engine & selective algorithm controls
│       ├── system_monitor.js   # Live host telemetry sampling & deadlock solver
│       └── history.js          # SQLite audit log, filter tabs & details modal
└── tests/                      # Automated pytest test suite (151 tests)
    ├── conftest.py             # Pytest fixtures and test clients
    ├── test_cpu_scheduling.py  # 43 unit tests for CPU algorithms & Gantt data
    ├── test_memory.py          # 11 unit tests for contiguous allocation strategies
    ├── test_paging.py          # 12 unit tests for page replacement algorithms
    ├── test_deadlock.py        # 12 unit tests for Banker's safety & request rollback
    ├── test_synchronization.py # 7 unit tests for multithreaded concurrency
    ├── test_comparison.py      # 10 unit tests for multi-algorithm benchmarking & focused comparisons
    ├── test_system_monitor.py  # 4 unit tests for Windows telemetry & deadlock detection
    ├── test_export.py          # 4 unit tests for Excel workbook generation (.xlsx)
    ├── test_database.py        # 7 unit tests for SQLite persistence & queries
    └── test_routes.py          # 41 integration tests for Flask web routes & API endpoints
```

---

## Implementation Status Table

| Module / Requirement | Status | Verification |
|----------------------|--------|--------------|
| Dashboard & Navigation | ✅ Complete | Verified at `http://127.0.0.1:5000` |
| CPU Scheduling (FCFS, SJF, Priority, RR) | ✅ Complete | 43 unit tests passed; Chart.js Gantt chart & execution trace working |
| Memory Allocation (First, Best, Worst Fit) | ✅ Complete | 11 unit tests passed; dynamic allocation map & decision trace |
| Page Replacement (FIFO, LRU, Optimal) | ✅ Complete | 12 unit tests passed; step-by-step frame matrix |
| Deadlock Management (Banker's Safety & Request) | ✅ Complete | 12 unit tests passed; interactive matrix builder |
| Thread Synchronization (Producer-Consumer, Reader-Writer) | ✅ Complete | 7 unit tests passed; real Python threading & semaphores |
| Performance Comparison (Selective 2–4 Algorithms) | ✅ Complete | 10 unit tests passed; trade-off analysis & charts |
| Windows System Monitor & Deadlock Detection | ✅ Complete | 4 unit tests passed; live `psutil` sampling & Work/Finish detector |
| Excel Export Engine (`openpyxl`) | ✅ Complete | 4 unit tests passed; `.xlsx` workbooks for all 4 subsystems |
| SQLite Persistence & History Management | ✅ Complete | 7 unit tests passed; full CRUD, counts aggregation & Excel export |
| Flask Web & API Routes | ✅ Complete | 41 integration tests passed |
| **Total Automated Test Suite** | ✅ **151 / 151 Passed** | **100% pass rate in 23.57s** |

---

## Limitations

- **Educational Simulator:** Models theoretical Operating Systems behavior for university coursework; does not execute kernel-mode instructions or physical hardware calls.
- **Thread Timing:** Multi-threaded synchronization simulations utilize millisecond-scale sleeps for educational traceability without stalling web server workers.
- **Storage Scope:** SQLite database is configured for local application use with thread-safe connection pooling.
