"""
scripts/capture_screenshots.py
==============================
Automates real screenshot capture of running OS Guardian application
using Microsoft Edge via Chrome DevTools Protocol (CDP) over WebSocket.
Captures live rendered UI states including:
  1. Dashboard Overview (dashboard.png)
  2. CPU Scheduling with active Chart.js Gantt Chart (scheduling.png)
  3. Contiguous Memory Allocation with physical block map (memory.png)
  4. Virtual Memory Page Replacement with frame matrix (paging.png)
"""

import os
import sys
import time
import json
import socket
import base64
import struct
import urllib.request
import subprocess
import shutil

EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
SCREENSHOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "docs", "screenshots"))
DEBUG_PORT = 9222


class SimpleWebSocket:
    """Minimal RFC-6455 WebSocket client using Python standard library socket."""

    def __init__(self, host, port, path):
        self.sock = socket.create_connection((host, port), timeout=15)
        # Handshake
        key = base64.b64encode(os.urandom(16)).decode('ascii')
        req = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {host}:{port}\r\n"
            f"Upgrade: websocket\r\n"
            f"Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            f"Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(req.encode('ascii'))
        # Read response headers until \r\n\r\n
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("WebSocket handshake failed (closed)")
            resp += chunk

        if b"HTTP/1.1 101" not in resp and b"101 Switching Protocols" not in resp:
            raise ConnectionError(f"Handshake failed: {resp.decode('latin1', errors='replace')}")

    def send_json(self, payload):
        data = json.dumps(payload).encode('utf-8')
        length = len(data)
        # Client frames must be masked
        mask = os.urandom(4)
        masked_data = bytearray(b ^ mask[i % 4] for i, b in enumerate(data))

        header = bytearray([0x81])  # FIN + Text frame
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))

        header.extend(mask)
        self.sock.sendall(header + masked_data)

    def recv_json(self, target_id=None, timeout=15):
        self.sock.settimeout(timeout)
        start_t = time.time()
        while time.time() - start_t < timeout:
            # Read frame
            head = self._recv_exact(2)
            opcode = head[0] & 0x0F
            is_masked = bool(head[1] & 0x80)
            pay_len = head[1] & 0x7F
            if pay_len == 126:
                pay_len = struct.unpack("!H", self._recv_exact(2))[0]
            elif pay_len == 127:
                pay_len = struct.unpack("!Q", self._recv_exact(8))[0]

            mask = self._recv_exact(4) if is_masked else b""
            body = self._recv_exact(pay_len)
            if is_masked:
                body = bytearray(b ^ mask[i % 4] for i, b in enumerate(body))

            if opcode == 0x8:  # Close
                raise ConnectionError("WebSocket closed by server")
            elif opcode == 0x1:  # Text frame
                msg = json.loads(body.decode('utf-8'))
                if target_id is None or msg.get("id") == target_id:
                    return msg
        raise TimeoutError(f"Timed out waiting for response ID {target_id}")

    def _recv_exact(self, n):
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("Socket closed prematurely")
            buf.extend(chunk)
        return buf

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


def capture_all():
    os.makedirs(SCREENSHOT_DIR, exist_ok=True)
    temp_profile = os.path.join(os.environ.get("TEMP", "."), f"edge_cdp_{int(time.time())}")

    print(f"Launching Edge on CDP port {DEBUG_PORT}...")
    edge_cmd = [
        EDGE_PATH,
        "--headless=new",
        "--disable-gpu",
        f"--remote-debugging-port={DEBUG_PORT}",
        f"--user-data-dir={temp_profile}",
        "--window-size=1280,960",
        "about:blank",
    ]
    proc = subprocess.Popen(edge_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)

    try:
        # Fetch targets
        req = urllib.request.urlopen(f"http://127.0.0.1:{DEBUG_PORT}/json", timeout=10)
        targets = json.loads(req.read().decode('utf-8'))
        page_target = next(t for t in targets if t.get("type") == "page")
        ws_url = page_target["webSocketDebuggerUrl"]
        print("Connected to target:", ws_url)

        # Parse host, port, path
        # ws://127.0.0.1:9222/devtools/page/...
        path = "/" + ws_url.split("/", 3)[3]
        ws = SimpleWebSocket("127.0.0.1", DEBUG_PORT, path)

        # Set desktop viewport metrics
        cmd_id = 1
        cmd_id += 1
        ws.send_json({
            "id": cmd_id,
            "method": "Emulation.setDeviceMetricsOverride",
            "params": {
                "width": 1400,
                "height": 950,
                "deviceScaleFactor": 1,
                "mobile": False,
            },
        })
        ws.recv_json(target_id=cmd_id)

        scenarios = [
            {
                "url": "http://127.0.0.1:5000/",
                "action": None,
                "wait": 1.0,
                "filename": "dashboard.png",
                "desc": "Dashboard Overview",
            },
            {
                "url": "http://127.0.0.1:5000/scheduling",
                "action": "document.getElementById('runBtn').click()",
                "wait": 2.0,
                "filename": "scheduling.png",
                "desc": "CPU Scheduling with Gantt Chart",
            },
            {
                "url": "http://127.0.0.1:5000/memory",
                "action": "document.getElementById('runMemBtn').click()",
                "wait": 1.5,
                "filename": "memory.png",
                "desc": "Memory Allocation with Block Visualization",
            },
            {
                "url": "http://127.0.0.1:5000/paging",
                "action": "document.getElementById('runPagingBtn').click()",
                "wait": 1.5,
                "filename": "paging.png",
                "desc": "Page Replacement with Resident Frame Matrix",
            },
        ]

        cmd_id = 1
        for item in scenarios:
            print(f"\nProcessing {item['desc']}...")
            # Navigate
            cmd_id += 1
            ws.send_json({"id": cmd_id, "method": "Page.navigate", "params": {"url": item["url"]}})
            ws.recv_json(target_id=cmd_id)
            time.sleep(1.0)

            # Action if needed
            if item["action"]:
                print(f"Triggering simulation action: {item['action']}")
                cmd_id += 1
                ws.send_json({
                    "id": cmd_id,
                    "method": "Runtime.evaluate",
                    "params": {"expression": item["action"]},
                })
                ws.recv_json(target_id=cmd_id)
                time.sleep(item["wait"])

            # Capture screenshot
            print("Capturing screenshot...")
            cmd_id += 1
            ws.send_json({
                "id": cmd_id,
                "method": "Page.captureScreenshot",
                "params": {"format": "png"},
            })
            res = ws.recv_json(target_id=cmd_id, timeout=15)
            img_b64 = res["result"]["data"]
            img_data = base64.b64decode(img_b64)

            dest_path = os.path.join(SCREENSHOT_DIR, item["filename"])
            with open(dest_path, "wb") as f:
                f.write(img_data)
            print(f"Saved: {dest_path} ({len(img_data)} bytes)")

        ws.close()
        print("\nAll 4 screenshots captured successfully!")

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
        shutil.rmtree(temp_profile, ignore_errors=True)


if __name__ == "__main__":
    capture_all()
