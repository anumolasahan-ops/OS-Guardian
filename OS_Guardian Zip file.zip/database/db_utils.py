"""
database/db_utils.py
====================
SQLite persistence layer for OS Guardian simulation runs.
Provides thread-safe, parameterized database utilities to store,
query, filter, and delete simulation history records.
"""

import os
import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

DEFAULT_DB_PATH = os.path.join(os.path.dirname(__file__), "os_guardian.db")


def get_db_path(custom_path: Optional[str] = None) -> str:
    """Resolve and ensure the directory for the SQLite database file."""
    path = custom_path or DEFAULT_DB_PATH
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    return path


def get_db_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Return a configured SQLite connection with row_factory enabled."""
    path = get_db_path(db_path)
    conn = sqlite3.connect(path, timeout=10.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(db_path: Optional[str] = None) -> None:
    """Initialize SQLite database tables."""
    conn = get_db_connection(db_path)
    try:
        with conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS simulations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    module_type TEXT NOT NULL,
                    algorithm TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    parameters TEXT NOT NULL,
                    results TEXT NOT NULL,
                    summary_metrics TEXT NOT NULL,
                    summary_text TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_simulations_module
                ON simulations (module_type)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_simulations_timestamp
                ON simulations (timestamp DESC)
            """)
    finally:
        conn.close()


def save_simulation(
    module_type: str,
    algorithm: str,
    parameters: Any,
    results: Any,
    summary_metrics: Any,
    summary_text: Optional[str] = None,
    db_path: Optional[str] = None,
) -> int:
    """
    Save a completed simulation run to the database.

    Returns
    -------
    int : The newly created simulation record ID.
    """
    if not module_type or not str(module_type).strip():
        raise ValueError("module_type is required.")
    if not algorithm or not str(algorithm).strip():
        raise ValueError("algorithm is required.")

    # Serialize JSON fields
    params_json = json.dumps(parameters, default=str)
    results_json = json.dumps(results, default=str)
    metrics_json = json.dumps(summary_metrics, default=str)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        with conn:
            cursor = conn.execute(
                """
                INSERT INTO simulations (
                    module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    module_type.strip().lower(),
                    algorithm.strip(),
                    timestamp,
                    params_json,
                    results_json,
                    metrics_json,
                    summary_text or f"{algorithm} simulation run",
                ),
            )
            return cursor.lastrowid
    finally:
        conn.close()


def get_all_simulations(
    module_type: Optional[str] = None,
    limit: int = 100,
    db_path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Retrieve simulation history records, optionally filtered by module."""
    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        if module_type and module_type.strip():
            m = module_type.strip().lower()
            if m in ("scheduling", "cpu_scheduling"):
                cursor = conn.execute(
                    """
                    SELECT id, module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
                    FROM simulations
                    WHERE module_type IN ('scheduling', 'cpu_scheduling')
                    ORDER BY id DESC
                    LIMIT ?
                    """,
                    (max(1, limit),),
                )
            elif m in ("synchronization", "sync"):
                cursor = conn.execute(
                    """
                    SELECT id, module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
                    FROM simulations
                    WHERE module_type IN ('synchronization', 'sync')
                    ORDER BY id DESC
                    LIMIT ?
                    """,
                    (max(1, limit),),
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT id, module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
                    FROM simulations
                    WHERE module_type = ?
                    ORDER BY id DESC
                    LIMIT ?
                    """,
                    (m, max(1, limit)),
                )
        else:
            cursor = conn.execute(
                """
                SELECT id, module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
                FROM simulations
                ORDER BY id DESC
                LIMIT ?
                """,
                (max(1, limit),),
            )

        rows = cursor.fetchall()
        result = []
        for row in rows:
            result.append({
                "id": row["id"],
                "module_type": row["module_type"],
                "algorithm": row["algorithm"],
                "timestamp": row["timestamp"],
                "parameters": json.loads(row["parameters"]),
                "results": json.loads(row["results"]),
                "summary_metrics": json.loads(row["summary_metrics"]),
                "summary_text": row["summary_text"],
            })
        return result
    finally:
        conn.close()


def get_simulation_by_id(sim_id: int, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Retrieve a single simulation record by its primary key ID."""
    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        cursor = conn.execute(
            """
            SELECT id, module_type, algorithm, timestamp, parameters, results, summary_metrics, summary_text
            FROM simulations
            WHERE id = ?
            """,
            (sim_id,),
        )
        row = cursor.fetchone()
        if not row:
            return None
        return {
            "id": row["id"],
            "module_type": row["module_type"],
            "algorithm": row["algorithm"],
            "timestamp": row["timestamp"],
            "parameters": json.loads(row["parameters"]),
            "results": json.loads(row["results"]),
            "summary_metrics": json.loads(row["summary_metrics"]),
            "summary_text": row["summary_text"],
        }
    finally:
        conn.close()


def delete_simulation(sim_id: int, db_path: Optional[str] = None) -> bool:
    """Delete a simulation record by its ID. Returns True if deleted."""
    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        with conn:
            cursor = conn.execute("DELETE FROM simulations WHERE id = ?", (sim_id,))
            return cursor.rowcount > 0
    finally:
        conn.close()


def clear_all_simulations(module_type: Optional[str] = None, db_path: Optional[str] = None) -> int:
    """Delete all simulations, or all within a specific module. Returns count deleted."""
    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        with conn:
            if module_type and module_type.strip():
                m = module_type.strip().lower()
                if m in ("scheduling", "cpu_scheduling"):
                    cursor = conn.execute("DELETE FROM simulations WHERE module_type IN ('scheduling', 'cpu_scheduling')")
                elif m in ("synchronization", "sync"):
                    cursor = conn.execute("DELETE FROM simulations WHERE module_type IN ('synchronization', 'sync')")
                else:
                    cursor = conn.execute("DELETE FROM simulations WHERE module_type = ?", (m,))
            else:
                cursor = conn.execute("DELETE FROM simulations")
            return cursor.rowcount
    finally:
        conn.close()


def get_simulation_counts(db_path: Optional[str] = None) -> Dict[str, int]:
    """Return record counts grouped by module, normalizing module names."""
    init_db(db_path)
    conn = get_db_connection(db_path)
    try:
        cursor = conn.execute("""
            SELECT module_type, COUNT(*) as cnt
            FROM simulations
            GROUP BY module_type
        """)
        raw_counts = {row["module_type"]: row["cnt"] for row in cursor.fetchall()}
        counts = dict(raw_counts)
        sched_count = raw_counts.get("scheduling", 0) + raw_counts.get("cpu_scheduling", 0)
        counts["scheduling"] = sched_count
        if "cpu_scheduling" not in counts:
            counts["cpu_scheduling"] = sched_count

        sync_count = raw_counts.get("synchronization", 0) + raw_counts.get("sync", 0)
        counts["synchronization"] = sync_count
        if "sync" not in counts:
            counts["sync"] = sync_count

        counts.setdefault("memory", raw_counts.get("memory", 0))
        counts.setdefault("paging", raw_counts.get("paging", 0))
        counts.setdefault("deadlock", raw_counts.get("deadlock", 0))
        counts.setdefault("comparison", raw_counts.get("comparison", 0))
        counts.setdefault("system_monitor", raw_counts.get("system_monitor", 0))

        total_cursor = conn.execute("SELECT COUNT(*) as total FROM simulations")
        counts["total"] = total_cursor.fetchone()["total"]
        return counts
    finally:
        conn.close()
