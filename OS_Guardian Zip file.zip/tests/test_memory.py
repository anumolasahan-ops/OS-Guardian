"""
tests/test_memory.py
====================
Automated test suite for Contiguous Memory Allocation algorithms:
  - First Fit
  - Best Fit
  - Worst Fit

Includes hand-calculated expected results for:
  - Standard textbook case (Silberschatz)
  - Unallocated processes
  - Exact match fitting
  - Complete exhaustion of memory blocks
  - Input validation (empty lists, negative sizes, duplicate PIDs)
"""

import pytest
from algorithms.memory_management import first_fit, best_fit, worst_fit


class TestMemoryAllocationTextbookCase:
    """
    Standard textbook benchmark (Silberschatz):
    Blocks: [100, 500, 200, 300, 600]
    Processes:
      P1: 212
      P2: 417
      P3: 112
      P4: 426
    """
    BLOCKS = [100, 500, 200, 300, 600]
    PROCESSES = [
        {"pid": "P1", "size": 212},
        {"pid": "P2", "size": 417},
        {"pid": "P3", "size": 112},
        {"pid": "P4", "size": 426},
    ]

    def test_first_fit_textbook(self):
        """
        First Fit Allocation:
          P1 (212) -> B2 (500), frag = 500 - 212 = 288
          P2 (417) -> B5 (600), frag = 600 - 417 = 183
          P3 (112) -> B3 (200), frag = 200 - 112 = 88
          P4 (426) -> No free block >= 426 left (B1=100, B4=300 remain) -> Unallocated
        """
        res = first_fit(self.BLOCKS, self.PROCESSES)
        allocs = {a["pid"]: a for a in res["allocations"]}

        assert allocs["P1"]["allocated"] is True
        assert allocs["P1"]["block_id"] == "B2"
        assert allocs["P1"]["fragmentation"] == 288

        assert allocs["P2"]["allocated"] is True
        assert allocs["P2"]["block_id"] == "B5"
        assert allocs["P2"]["fragmentation"] == 183

        assert allocs["P3"]["allocated"] is True
        assert allocs["P3"]["block_id"] == "B3"
        assert allocs["P3"]["fragmentation"] == 88

        assert allocs["P4"]["allocated"] is False
        assert allocs["P4"]["block_id"] is None
        assert allocs["P4"]["fragmentation"] is None

        m = res["metrics"]
        assert m["allocated_processes_count"] == 3
        assert m["unallocated_processes_count"] == 1
        assert m["unallocated_pids"] == ["P4"]
        assert m["total_internal_fragmentation"] == 288 + 183 + 88

    def test_best_fit_textbook(self):
        """
        Best Fit Allocation:
          P1 (212) -> B4 (300) [min diff: 300-212=88], frag = 88
          P2 (417) -> B2 (500) [diff: 500-417=83 vs 600-417=183], frag = 83
          P3 (112) -> B3 (200) [diff: 200-112=88], frag = 88
          P4 (426) -> B5 (600) [diff: 600-426=174], frag = 174
          All 4 allocated!
        """
        res = best_fit(self.BLOCKS, self.PROCESSES)
        allocs = {a["pid"]: a for a in res["allocations"]}

        assert allocs["P1"]["allocated"] is True
        assert allocs["P1"]["block_id"] == "B4"
        assert allocs["P1"]["fragmentation"] == 88

        assert allocs["P2"]["allocated"] is True
        assert allocs["P2"]["block_id"] == "B2"
        assert allocs["P2"]["fragmentation"] == 83

        assert allocs["P3"]["allocated"] is True
        assert allocs["P3"]["block_id"] == "B3"
        assert allocs["P3"]["fragmentation"] == 88

        assert allocs["P4"]["allocated"] is True
        assert allocs["P4"]["block_id"] == "B5"
        assert allocs["P4"]["fragmentation"] == 174

        m = res["metrics"]
        assert m["allocated_processes_count"] == 4
        assert m["unallocated_processes_count"] == 0
        assert m["total_internal_fragmentation"] == 88 + 83 + 88 + 174

    def test_worst_fit_textbook(self):
        """
        Worst Fit Allocation:
          P1 (212) -> B5 (600) [max diff: 388], frag = 388
          P2 (417) -> B2 (500) [max diff: 83], frag = 83
          P3 (112) -> B4 (300) [max diff: 188], frag = 188
          P4 (426) -> No free block >= 426 left (B1=100, B3=200 remain) -> Unallocated
        """
        res = worst_fit(self.BLOCKS, self.PROCESSES)
        allocs = {a["pid"]: a for a in res["allocations"]}

        assert allocs["P1"]["allocated"] is True
        assert allocs["P1"]["block_id"] == "B5"
        assert allocs["P1"]["fragmentation"] == 388

        assert allocs["P2"]["allocated"] is True
        assert allocs["P2"]["block_id"] == "B2"
        assert allocs["P2"]["fragmentation"] == 83

        assert allocs["P3"]["allocated"] is True
        assert allocs["P3"]["block_id"] == "B4"
        assert allocs["P3"]["fragmentation"] == 188

        assert allocs["P4"]["allocated"] is False
        m_p4 = res["metrics"]["unallocated_pids"]
        assert "P4" in m_p4


class TestMemoryEdgeCases:
    def test_exact_fit(self):
        """Processes exactly matching block sizes leave 0 internal fragmentation."""
        blocks = [100, 200, 300]
        procs = [{"pid": "P1", "size": 100}, {"pid": "P2", "size": 200}, {"pid": "P3", "size": 300}]
        res = first_fit(blocks, procs)
        for a in res["allocations"]:
            assert a["allocated"] is True
            assert a["fragmentation"] == 0
        assert res["metrics"]["total_internal_fragmentation"] == 0

    def test_all_unallocated_due_to_large_process(self):
        """Process larger than any available block cannot be allocated."""
        blocks = [50, 60]
        procs = [{"pid": "P1", "size": 100}]
        res = first_fit(blocks, procs)
        assert res["allocations"][0]["allocated"] is False
        assert res["metrics"]["unallocated_processes_count"] == 1

    def test_more_processes_than_blocks(self):
        """More processes than blocks ensures some must remain unallocated."""
        blocks = [100]
        procs = [{"pid": "P1", "size": 50}, {"pid": "P2", "size": 40}]
        res = first_fit(blocks, procs)
        assert res["allocations"][0]["allocated"] is True
        assert res["allocations"][1]["allocated"] is False


class TestMemoryValidation:
    def test_empty_blocks_raises(self):
        with pytest.raises(ValueError, match="Block list is empty"):
            first_fit([], [{"pid": "P1", "size": 50}])

    def test_empty_processes_raises(self):
        with pytest.raises(ValueError, match="Process list is empty"):
            first_fit([100], [])

    def test_non_positive_block_size_raises(self):
        with pytest.raises(ValueError, match="greater than 0"):
            first_fit([0, 100], [{"pid": "P1", "size": 50}])

    def test_non_positive_process_size_raises(self):
        with pytest.raises(ValueError, match="greater than 0"):
            first_fit([100], [{"pid": "P1", "size": -10}])

    def test_duplicate_pid_raises(self):
        with pytest.raises(ValueError, match="Duplicate process ID"):
            first_fit([100, 200], [{"pid": "P1", "size": 50}, {"pid": "P1", "size": 60}])
