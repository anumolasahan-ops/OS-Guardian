"""
tests/test_cpu_scheduling.py
=============================
Automated tests for all four CPU scheduling algorithms.

Expected values are calculated INDEPENDENTLY from the implementation
using standard OS textbook formulas:
  Turnaround Time  = Completion Time - Arrival Time
  Waiting Time     = Turnaround Time - Burst Time
  Response Time    = First CPU Start - Arrival Time
  CPU Utilisation  = (Sum of Burst Times / Makespan) * 100
  Makespan         = Last Completion Time - Min Arrival Time

Tie-breaking rules verified (documented in cpu_scheduling.py):
  FCFS      : arrival_time ASC, pid ASC
  SJF       : burst_time ASC, arrival_time ASC, pid ASC
  Priority  : priority ASC (lower = higher), arrival_time ASC, pid ASC
  Round Robin: first-arrival order; simultaneous → pid ASC
"""

import pytest
from algorithms.cpu_scheduling import fcfs, sjf, priority_scheduling, round_robin


# ═══════════════════════════════════════════════════════════════════════════════
#  Shared helpers
# ═══════════════════════════════════════════════════════════════════════════════

def result_for(results, pid):
    """Return the result dict for a given pid."""
    for r in results:
        if r["pid"] == pid:
            return r
    raise KeyError(f"PID '{pid}' not found in results: {[r['pid'] for r in results]}")


def gantt_pids(gantt):
    """Return list of pids in Gantt order (for ordering checks)."""
    return [g["pid"] for g in gantt]


# ═══════════════════════════════════════════════════════════════════════════════
#  FCFS Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestFCFS:

    # ── Single process ────────────────────────────────────────────────────────
    def test_single_process_no_idle(self):
        """Single process arriving at 0: no idle gap, all metrics straightforward."""
        out = fcfs([{"pid": "P1", "arrival_time": 0, "burst_time": 5}])
        r = result_for(out["results"], "P1")
        # CT=5, TAT=5-0=5, WT=5-5=0, RT=0-0=0
        assert r["completion_time"]  == 5
        assert r["turnaround_time"]  == 5
        assert r["waiting_time"]     == 0
        assert r["response_time"]    == 0
        assert out["metrics"]["cpu_utilization"] == 100.0

    def test_single_process_late_arrival(self):
        """Single process arriving at t=5 causes an idle gap [0,5]."""
        out = fcfs([{"pid": "P1", "arrival_time": 5, "burst_time": 3}])
        r = result_for(out["results"], "P1")
        # CT=8, TAT=8-5=3, WT=0, RT=0
        assert r["completion_time"] == 8
        assert r["turnaround_time"] == 3
        assert r["waiting_time"]    == 0
        assert r["response_time"]   == 0
        # Idle from 0→5, burst 3, makespan = 8-5 = 3 → util = 100%
        assert out["metrics"]["cpu_utilization"] == 100.0

    # ── Standard textbook example ─────────────────────────────────────────────
    def test_standard_four_processes(self):
        """
        Hand-calculated FCFS example:
          P1: arrival=0, burst=6  → CT=6,  TAT=6,  WT=0,  RT=0
          P2: arrival=1, burst=4  → CT=10, TAT=9,  WT=5,  RT=5
          P3: arrival=2, burst=2  → CT=12, TAT=10, WT=8,  RT=8
          P4: arrival=3, burst=8  → CT=20, TAT=17, WT=9,  RT=9
          Avg TAT = (6+9+10+17)/4 = 10.5
          Avg WT  = (0+5+8+9)/4   = 5.5
          CPU util = 20/20 = 100%
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":6},
            {"pid":"P2","arrival_time":1,"burst_time":4},
            {"pid":"P3","arrival_time":2,"burst_time":2},
            {"pid":"P4","arrival_time":3,"burst_time":8},
        ]
        out = fcfs(procs)
        assert result_for(out["results"],"P1")["completion_time"]  == 6
        assert result_for(out["results"],"P1")["turnaround_time"]  == 6
        assert result_for(out["results"],"P1")["waiting_time"]     == 0

        assert result_for(out["results"],"P2")["completion_time"]  == 10
        assert result_for(out["results"],"P2")["turnaround_time"]  == 9
        assert result_for(out["results"],"P2")["waiting_time"]     == 5

        assert result_for(out["results"],"P3")["completion_time"]  == 12
        assert result_for(out["results"],"P3")["turnaround_time"]  == 10
        assert result_for(out["results"],"P3")["waiting_time"]     == 8

        assert result_for(out["results"],"P4")["completion_time"]  == 20
        assert result_for(out["results"],"P4")["turnaround_time"]  == 17
        assert result_for(out["results"],"P4")["waiting_time"]     == 9

        assert out["metrics"]["avg_turnaround"] == 10.5
        assert out["metrics"]["avg_waiting"]    == 5.5
        assert out["metrics"]["cpu_utilization"] == 100.0

    # ── Idle gap ──────────────────────────────────────────────────────────────
    def test_idle_gap_between_processes(self):
        """
        P1 finishes at t=3, P2 arrives at t=7 → IDLE gap [3,7].
          P1: AT=0, BT=3 → CT=3, TAT=3, WT=0
          P2: AT=7, BT=2 → CT=9, TAT=2, WT=0
          makespan = 9-0 = 9, total burst = 5
          CPU util = 5/9 * 100 ≈ 55.56%
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":3},
            {"pid":"P2","arrival_time":7,"burst_time":2},
        ]
        out = fcfs(procs)
        assert result_for(out["results"],"P1")["completion_time"] == 3
        assert result_for(out["results"],"P2")["completion_time"] == 9
        assert result_for(out["results"],"P2")["waiting_time"]    == 0

        idle = [g for g in out["gantt"] if g["pid"] == "IDLE"]
        assert len(idle) == 1
        assert idle[0]["start"] == 3
        assert idle[0]["end"]   == 7

        assert out["metrics"]["cpu_utilization"] == pytest.approx(55.56, abs=0.01)

    # ── Tie-breaking ──────────────────────────────────────────────────────────
    def test_simultaneous_arrival_ordered_by_pid(self):
        """
        P1 and P2 both arrive at t=0.
        FCFS tie: pid ASC → P1 before P2.
        """
        procs = [
            {"pid":"P2","arrival_time":0,"burst_time":4},
            {"pid":"P1","arrival_time":0,"burst_time":3},
        ]
        out = fcfs(procs)
        pids = gantt_pids(out["gantt"])
        assert pids.index("P1") < pids.index("P2")

    # ── GANTT structure ───────────────────────────────────────────────────────
    def test_gantt_is_contiguous(self):
        """Every Gantt segment must start where the previous one ended."""
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":4},
            {"pid":"P2","arrival_time":6,"burst_time":3},
        ]
        out = fcfs(procs)
        g = out["gantt"]
        for i in range(1, len(g)):
            assert g[i]["start"] == g[i-1]["end"], \
                f"Gap between segment {i-1} and {i}: {g[i-1]} → {g[i]}"


# ═══════════════════════════════════════════════════════════════════════════════
#  SJF Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestSJF:

    def test_single_process(self):
        out = sjf([{"pid":"P1","arrival_time":0,"burst_time":7}])
        r = result_for(out["results"],"P1")
        assert r["completion_time"] == 7
        assert r["waiting_time"]    == 0

    def test_standard_sjf_example(self):
        """
        Classic SJF non-preemptive example:
          P1: AT=0, BT=7
          P2: AT=2, BT=4
          P3: AT=4, BT=1
          P4: AT=5, BT=4

        At t=0: only P1 ready → P1 runs [0,7]
        At t=7: P2(4), P3(1), P4(4) ready → pick P3 [7,8]
        At t=8: P2(4), P4(4) ready → tie: arrival ASC → P2 [8,12]
        At t=12: P4 [12,16]

          P1: CT=7,  TAT=7,  WT=0,  RT=0
          P2: CT=12, TAT=10, WT=6,  RT=6
          P3: CT=8,  TAT=4,  WT=3,  RT=3
          P4: CT=16, TAT=11, WT=7,  RT=7
          Avg TAT = (7+10+4+11)/4 = 8.0
          Avg WT  = (0+6+3+7)/4   = 4.0
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":7},
            {"pid":"P2","arrival_time":2,"burst_time":4},
            {"pid":"P3","arrival_time":4,"burst_time":1},
            {"pid":"P4","arrival_time":5,"burst_time":4},
        ]
        out = sjf(procs)
        assert result_for(out["results"],"P1")["completion_time"] == 7
        assert result_for(out["results"],"P3")["completion_time"] == 8
        assert result_for(out["results"],"P2")["completion_time"] == 12
        assert result_for(out["results"],"P4")["completion_time"] == 16

        assert result_for(out["results"],"P1")["waiting_time"] == 0
        assert result_for(out["results"],"P3")["waiting_time"] == 3
        assert result_for(out["results"],"P2")["waiting_time"] == 6
        assert result_for(out["results"],"P4")["waiting_time"] == 7

        assert out["metrics"]["avg_turnaround"] == 8.0
        assert out["metrics"]["avg_waiting"]    == 4.0

    def test_sjf_picks_shortest_among_ready(self):
        """
        At t=0 only P1(BT=10) is ready; P2(BT=2) arrives at t=1.
        Non-preemptive: P1 runs to completion, then P2.
          P1: CT=10, TAT=10, WT=0
          P2: CT=12, TAT=11, WT=9
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":10},
            {"pid":"P2","arrival_time":1,"burst_time":2},
        ]
        out = sjf(procs)
        # P1 was the only option at t=0, so non-preemptive SJF keeps it running
        assert result_for(out["results"],"P1")["completion_time"] == 10
        assert result_for(out["results"],"P2")["completion_time"] == 12
        assert gantt_pids(out["gantt"])[0] == "P1"

    def test_sjf_idle_gap(self):
        """
        P1: AT=0, BT=2. P2: AT=10, BT=3.
        Idle [2,10]. CPU util = 5/13 ≈ 38.46%
        """
        procs = [
            {"pid":"P1","arrival_time":0, "burst_time":2},
            {"pid":"P2","arrival_time":10,"burst_time":3},
        ]
        out = sjf(procs)
        idle = [g for g in out["gantt"] if g["pid"] == "IDLE"]
        assert len(idle) == 1
        assert idle[0] == {"pid":"IDLE","start":2,"end":10}
        assert out["metrics"]["cpu_utilization"] == pytest.approx(38.46, abs=0.01)


# ═══════════════════════════════════════════════════════════════════════════════
#  Priority Scheduling Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestPriority:

    def test_single_process(self):
        out = priority_scheduling([
            {"pid":"P1","arrival_time":0,"burst_time":5,"priority":1}
        ])
        assert result_for(out["results"],"P1")["completion_time"] == 5

    def test_standard_priority_example(self):
        """
        Priority example (lower number = higher priority):
          P1: AT=0, BT=10, Pri=3
          P2: AT=1, BT=1,  Pri=1
          P3: AT=2, BT=2,  Pri=4
          P4: AT=3, BT=1,  Pri=5
          P5: AT=4, BT=5,  Pri=2

        At t=0: only P1 ready → P1 runs [0,10]   (non-preemptive)
        At t=10: P2(pri=1), P5(pri=2), P3(pri=4), P4(pri=5) ready
          → pick P2 [10,11]
        At t=11: P5(pri=2), P3(pri=4), P4(pri=5)
          → pick P5 [11,16]
        At t=16: P3(pri=4), P4(pri=5)
          → pick P3 [16,18]
        At t=18: P4 [18,19]

          P1: CT=10, TAT=10, WT=0
          P2: CT=11, TAT=10, WT=9
          P5: CT=16, TAT=12, WT=7
          P3: CT=18, TAT=16, WT=14
          P4: CT=19, TAT=16, WT=15
          Avg TAT = (10+10+12+16+16)/5 = 12.8
          Avg WT  = (0+9+7+14+15)/5    = 9.0
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":10,"priority":3},
            {"pid":"P2","arrival_time":1,"burst_time":1, "priority":1},
            {"pid":"P3","arrival_time":2,"burst_time":2, "priority":4},
            {"pid":"P4","arrival_time":3,"burst_time":1, "priority":5},
            {"pid":"P5","arrival_time":4,"burst_time":5, "priority":2},
        ]
        out = priority_scheduling(procs)
        assert result_for(out["results"],"P1")["completion_time"] == 10
        assert result_for(out["results"],"P2")["completion_time"] == 11
        assert result_for(out["results"],"P5")["completion_time"] == 16
        assert result_for(out["results"],"P3")["completion_time"] == 18
        assert result_for(out["results"],"P4")["completion_time"] == 19

        assert result_for(out["results"],"P1")["waiting_time"] == 0
        assert result_for(out["results"],"P2")["waiting_time"] == 9
        assert result_for(out["results"],"P5")["waiting_time"] == 7
        assert result_for(out["results"],"P3")["waiting_time"] == 14
        assert result_for(out["results"],"P4")["waiting_time"] == 15

        assert out["metrics"]["avg_turnaround"] == 12.8
        assert out["metrics"]["avg_waiting"]    == 9.0

    def test_priority_tie_broken_by_arrival_then_pid(self):
        """
        P1 and P2 have same priority=1. P1 arrives at t=0, P2 at t=0.
        Tie on priority → arrival_time → pid ASC → P1 before P2.
        """
        procs = [
            {"pid":"P2","arrival_time":0,"burst_time":3,"priority":1},
            {"pid":"P1","arrival_time":0,"burst_time":4,"priority":1},
        ]
        out = priority_scheduling(procs)
        pids = gantt_pids(out["gantt"])
        assert pids[0] == "P1"
        assert pids[1] == "P2"


# ═══════════════════════════════════════════════════════════════════════════════
#  Round Robin Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestRoundRobin:

    def test_single_process_quantum_larger_than_burst(self):
        """Single process, quantum > burst: runs in one slice."""
        out = round_robin([{"pid":"P1","arrival_time":0,"burst_time":3}], quantum=10)
        r = result_for(out["results"],"P1")
        assert r["completion_time"] == 3
        assert r["waiting_time"]    == 0
        assert r["response_time"]   == 0

    def test_standard_rr_example_q2(self):
        """
        Classic RR Q=2 example (all arrive at t=0):
          P1(BT=5), P2(BT=3), P3(BT=1), P4(BT=2)

        Queue order at t=0 (pid ASC): P1,P2,P3,P4

        t=0-2:  P1 runs, rem=3. New arrivals: none. Queue=[P2,P3,P4,P1]
        t=2-4:  P2 runs, rem=1. Queue=[P3,P4,P1,P2]
        t=4-5:  P3 runs (rem=1<Q), done CT=5. Queue=[P4,P1,P2]
        t=5-7:  P4 runs, rem=0, done CT=7. Queue=[P1,P2]
        t=7-9:  P1 runs, rem=1. Queue=[P2,P1]
        t=9-10: P2 runs (rem=1<Q), done CT=10. Queue=[P1]
        t=10-11:P1 runs (rem=1<Q), done CT=11.

          P1: CT=11, AT=0, BT=5, TAT=11, WT=6,  RT=0
          P2: CT=10, AT=0, BT=3, TAT=10, WT=7,  RT=2
          P3: CT=5,  AT=0, BT=1, TAT=5,  WT=4,  RT=4
          P4: CT=7,  AT=0, BT=2, TAT=7,  WT=5,  RT=5

          Avg TAT = (11+10+5+7)/4 = 8.25
          Avg WT  = (6+7+4+5)/4   = 5.5
          CPU util = 11/11 = 100%
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":5},
            {"pid":"P2","arrival_time":0,"burst_time":3},
            {"pid":"P3","arrival_time":0,"burst_time":1},
            {"pid":"P4","arrival_time":0,"burst_time":2},
        ]
        out = round_robin(procs, quantum=2)

        assert result_for(out["results"],"P1")["completion_time"] == 11
        assert result_for(out["results"],"P2")["completion_time"] == 10
        assert result_for(out["results"],"P3")["completion_time"] == 5
        assert result_for(out["results"],"P4")["completion_time"] == 7

        assert result_for(out["results"],"P1")["waiting_time"] == 6
        assert result_for(out["results"],"P2")["waiting_time"] == 7
        assert result_for(out["results"],"P3")["waiting_time"] == 4
        assert result_for(out["results"],"P4")["waiting_time"] == 5

        assert out["metrics"]["avg_turnaround"] == 8.25
        assert out["metrics"]["avg_waiting"]    == 5.5
        assert out["metrics"]["cpu_utilization"] == 100.0

    def test_rr_with_different_arrivals(self):
        """
        RR Q=3 with staggered arrivals:
          P1: AT=0, BT=5
          P2: AT=1, BT=3
          P3: AT=4, BT=1

        t=0: queue=[P1]. P1 runs [0,3], rem=2. At t=3: P2 arrived → queue=[P2,P1]
        t=3-6: P2 runs [3,6], rem=0, CT=6. At t=6: P3 arrived → queue=[P1,P3]
        t=6-8: P1 runs [6,8], rem=0, CT=8. queue=[P3]
        t=8-9: P3 runs [8,9], rem=0, CT=9.

          P1: CT=8,  TAT=8,  WT=3,  RT=0
          P2: CT=6,  TAT=5,  WT=2,  RT=2
          P3: CT=9,  TAT=5,  WT=4,  RT=4
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":5},
            {"pid":"P2","arrival_time":1,"burst_time":3},
            {"pid":"P3","arrival_time":4,"burst_time":1},
        ]
        out = round_robin(procs, quantum=3)
        assert result_for(out["results"],"P1")["completion_time"] == 8
        assert result_for(out["results"],"P2")["completion_time"] == 6
        assert result_for(out["results"],"P3")["completion_time"] == 9

        assert result_for(out["results"],"P1")["waiting_time"] == 3
        assert result_for(out["results"],"P2")["waiting_time"] == 2
        assert result_for(out["results"],"P3")["waiting_time"] == 4

    def test_rr_with_idle_gap(self):
        """
        P1: AT=0, BT=2  Q=3 → runs [0,2], done.
        P2: AT=5, BT=3  → IDLE [2,5], then P2 [5,8].
          CPU util = 5/(8-0)*100 = 62.5%
        """
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":2},
            {"pid":"P2","arrival_time":5,"burst_time":3},
        ]
        out = round_robin(procs, quantum=3)
        idle = [g for g in out["gantt"] if g["pid"] == "IDLE"]
        assert len(idle) == 1
        assert idle[0]["start"] == 2
        assert idle[0]["end"]   == 5
        assert out["metrics"]["cpu_utilization"] == pytest.approx(62.5, abs=0.01)

    def test_rr_gantt_completeness(self):
        """Total time covered by Gantt must equal makespan."""
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":6},
            {"pid":"P2","arrival_time":1,"burst_time":4},
            {"pid":"P3","arrival_time":2,"burst_time":2},
        ]
        out = round_robin(procs, quantum=2)
        g = out["gantt"]
        total_gantt = sum(seg["end"] - seg["start"] for seg in g)
        makespan = out["metrics"]["makespan"]
        assert total_gantt == makespan


# ═══════════════════════════════════════════════════════════════════════════════
#  Input Validation Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestValidation:

    def test_empty_process_list_raises(self):
        with pytest.raises(ValueError, match="empty"):
            fcfs([])

    def test_zero_burst_raises(self):
        with pytest.raises(ValueError, match="burst_time"):
            fcfs([{"pid":"P1","arrival_time":0,"burst_time":0}])

    def test_negative_burst_raises(self):
        with pytest.raises(ValueError, match="burst_time"):
            fcfs([{"pid":"P1","arrival_time":0,"burst_time":-3}])

    def test_negative_arrival_raises(self):
        with pytest.raises(ValueError, match="arrival_time"):
            fcfs([{"pid":"P1","arrival_time":-1,"burst_time":5}])

    def test_duplicate_pid_raises(self):
        procs = [
            {"pid":"P1","arrival_time":0,"burst_time":3},
            {"pid":"P1","arrival_time":1,"burst_time":4},
        ]
        with pytest.raises(ValueError, match="Duplicate"):
            fcfs(procs)

    def test_empty_pid_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            fcfs([{"pid":"","arrival_time":0,"burst_time":3}])

    def test_missing_priority_for_priority_algo_raises(self):
        with pytest.raises(ValueError):
            priority_scheduling([{"pid":"P1","arrival_time":0,"burst_time":5}])

    def test_zero_quantum_raises(self):
        with pytest.raises(ValueError, match="quantum"):
            round_robin([{"pid":"P1","arrival_time":0,"burst_time":5}], quantum=0)

    def test_negative_quantum_raises(self):
        with pytest.raises(ValueError, match="quantum"):
            round_robin([{"pid":"P1","arrival_time":0,"burst_time":5}], quantum=-1)

    def test_non_integer_quantum_raises(self):
        with pytest.raises(ValueError):
            round_robin([{"pid":"P1","arrival_time":0,"burst_time":5}], quantum="abc")

    def test_non_integer_burst_raises(self):
        with pytest.raises(ValueError, match="burst_time"):
            fcfs([{"pid":"P1","arrival_time":0,"burst_time":"five"}])


# ═══════════════════════════════════════════════════════════════════════════════
#  Output Structure Tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestOutputStructure:

    PROCS = [
        {"pid":"P1","arrival_time":0,"burst_time":4,"priority":2},
        {"pid":"P2","arrival_time":1,"burst_time":2,"priority":1},
    ]

    def _check_structure(self, out):
        assert "gantt"   in out
        assert "results" in out
        assert "metrics" in out
        assert "errors"  in out

        for g in out["gantt"]:
            assert "pid"   in g
            assert "start" in g
            assert "end"   in g
            assert g["end"] > g["start"]

        for r in out["results"]:
            for key in ("pid","arrival_time","burst_time","completion_time",
                        "turnaround_time","waiting_time","response_time"):
                assert key in r

        m = out["metrics"]
        for key in ("avg_turnaround","avg_waiting","avg_response","cpu_utilization"):
            assert key in m

    def test_fcfs_structure(self):
        self._check_structure(fcfs(self.PROCS))

    def test_sjf_structure(self):
        self._check_structure(sjf(self.PROCS))

    def test_priority_structure(self):
        self._check_structure(priority_scheduling(self.PROCS))

    def test_rr_structure(self):
        self._check_structure(round_robin(self.PROCS, quantum=2))

    def test_waiting_time_non_negative(self):
        """Waiting time must never be negative."""
        for fn in [fcfs, sjf]:
            out = fn(self.PROCS)
            for r in out["results"]:
                assert r["waiting_time"] >= 0, \
                    f"{fn.__name__}: {r['pid']} has negative waiting time"

    def test_cpu_util_bounded(self):
        """CPU utilisation must be in (0, 100] for any valid input."""
        for fn in [fcfs, sjf]:
            out = fn(self.PROCS)
            assert 0 < out["metrics"]["cpu_utilization"] <= 100.0

    def test_timeline_segments_integrity(self):
        """
        Timeline segment validation for all algorithms:
        - Segments have valid non-negative integer start and end
        - Each segment has start < end
        - Segments form a contiguous progression without overlaps or gaps
        - Total duration of all segments equals makespan
        """
        for algo_name, res in [
            ("fcfs", fcfs(self.PROCS)),
            ("sjf", sjf(self.PROCS)),
            ("priority", priority_scheduling(self.PROCS)),
            ("rr", round_robin(self.PROCS, quantum=2)),
        ]:
            gantt = res["gantt"]
            assert len(gantt) > 0, f"{algo_name} should produce at least one Gantt segment"
            for seg in gantt:
                assert "pid" in seg and "start" in seg and "end" in seg
                assert isinstance(seg["start"], int) and isinstance(seg["end"], int)
                assert seg["start"] >= 0, f"{algo_name}: start time must be non-negative"
                assert seg["end"] > seg["start"], f"{algo_name}: end must be strictly greater than start"

            # Contiguity check
            for idx in range(1, len(gantt)):
                assert gantt[idx]["start"] == gantt[idx - 1]["end"], (
                    f"{algo_name}: discontinuity between segment {idx-1} "
                    f"({gantt[idx-1]['end']}) and segment {idx} ({gantt[idx]['start']})"
                )

            total_timeline = gantt[-1]["end"] - gantt[0]["start"]
            assert total_timeline == res["metrics"]["makespan"], (
                f"{algo_name}: total timeline duration ({total_timeline}) does not match makespan ({res['metrics']['makespan']})"
            )

