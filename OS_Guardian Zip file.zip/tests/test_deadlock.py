"""
tests/test_deadlock.py
======================
Unit tests for Banker's Algorithm (deadlock avoidance) in algorithms/deadlock.py.
Covers:
  - Input validation and dimension checks
  - Need matrix calculation
  - Classic textbook safe state (Silberschatz example)
  - Unsafe state detection
  - Resource request granted
  - Resource request denied (insufficient available)
  - Resource request rejected (exceeds need)
  - Resource request rolled back (leaves system unsafe)
"""

import pytest
from algorithms.deadlock import (
    calculate_need,
    validate_bankers_inputs,
    bankers_safety,
    resource_request,
)


class TestBankersValidation:
    def test_empty_matrices_raise(self):
        with pytest.raises(ValueError, match="must not be empty"):
            calculate_need([], [])

    def test_dimension_mismatch_raise(self):
        alloc = [[1, 2], [0, 1]]
        max_mat = [[2, 2]]
        with pytest.raises(ValueError, match="Process count mismatch"):
            calculate_need(alloc, max_mat)

    def test_negative_values_raise(self):
        alloc = [[-1, 2]]
        max_mat = [[2, 2]]
        with pytest.raises(ValueError, match="non-negative"):
            calculate_need(alloc, max_mat)

    def test_allocation_exceeds_maximum_raise(self):
        alloc = [[3, 2]]
        max_mat = [[2, 2]]
        with pytest.raises(ValueError, match="Allocation exceeds Maximum"):
            calculate_need(alloc, max_mat)

    def test_available_mismatch_raise(self):
        alloc = [[1, 2]]
        max_mat = [[2, 2]]
        avail = [3]  # should have 2 elements
        with pytest.raises(ValueError, match="Available vector length"):
            validate_bankers_inputs(alloc, max_mat, avail)


class TestBankersSafety:
    @pytest.fixture
    def silberschatz_system(self):
        """Classic Silberschatz 5-process, 3-resource safe system."""
        allocation = [
            [0, 1, 0],  # P0
            [2, 0, 0],  # P1
            [3, 0, 2],  # P2
            [2, 1, 1],  # P3
            [0, 0, 2],  # P4
        ]
        maximum = [
            [7, 5, 3],  # P0
            [3, 2, 2],  # P1
            [9, 0, 2],  # P2
            [2, 2, 2],  # P3
            [4, 3, 3],  # P4
        ]
        available = [3, 3, 2]
        return allocation, maximum, available

    def test_need_matrix_calculation(self, silberschatz_system):
        alloc, maximum, _ = silberschatz_system
        need = calculate_need(alloc, maximum)
        expected_need = [
            [7, 4, 3],  # P0: [7-0, 5-1, 3-0]
            [1, 2, 2],  # P1: [3-2, 2-0, 2-0]
            [6, 0, 0],  # P2: [9-3, 0-0, 2-2]
            [0, 1, 1],  # P3: [2-2, 2-1, 2-1]
            [4, 3, 1],  # P4: [4-0, 3-0, 3-2]
        ]
        assert need == expected_need

    def test_silberschatz_is_safe(self, silberschatz_system):
        alloc, maximum, avail = silberschatz_system
        res = bankers_safety(alloc, maximum, avail)
        assert res["is_safe"] is True
        assert len(res["safe_sequence"]) == 5
        # In this system, P1 can always execute first because Need[P1]=(1,2,2) <= Available=(3,3,2)
        assert res["safe_sequence"][0] == "P1"
        assert len(res["steps"]) == 5
        # Final work should equal total resources in the system: sum(alloc) + avail = (7+3, 2+3, 5+2) = (10, 5, 7)
        assert res["final_work"] == [10, 5, 7]

    def test_unsafe_state_detection(self):
        # A system where available is too low to satisfy any process
        allocation = [
            [2, 0],
            [1, 2],
        ]
        maximum = [
            [5, 5],
            [4, 4],
        ]
        # Need: P0=(3,5), P1=(3,2). Available is (1, 1) -> neither can run
        available = [1, 1]
        res = bankers_safety(allocation, maximum, available)
        assert res["is_safe"] is False
        assert res["safe_sequence"] == []
        assert set(res["unfinished_processes"]) == {"P0", "P1"}


class TestBankersResourceRequest:
    @pytest.fixture
    def textbook_system(self):
        allocation = [
            [0, 1, 0],  # P0
            [2, 0, 0],  # P1
            [3, 0, 2],  # P2
            [2, 1, 1],  # P3
            [0, 0, 2],  # P4
        ]
        maximum = [
            [7, 5, 3],
            [3, 2, 2],
            [9, 0, 2],
            [2, 2, 2],
            [4, 3, 3],
        ]
        available = [3, 3, 2]
        return allocation, maximum, available

    def test_valid_safe_request_granted(self, textbook_system):
        alloc, maximum, avail = textbook_system
        # P1 requests [1, 0, 2]. Need[P1] is [1, 2, 2], Available is [3, 3, 2].
        # 1<=1, 0<=2, 2<=2 (<= Need) and 1<=3, 0<=3, 2<=2 (<= Available).
        req = [1, 0, 2]
        res = resource_request(alloc, maximum, avail, process_index=1, request_vector=req)
        assert res["granted"] is True
        assert res["rolled_back"] is False
        assert res["available"] == [2, 3, 0]
        assert res["allocation"][1] == [3, 0, 2]
        assert res["need"][1] == [0, 2, 0]
        assert res["safety_result"]["is_safe"] is True

    def test_request_exceeds_need_raises(self, textbook_system):
        alloc, maximum, avail = textbook_system
        # P1 has Need [1, 2, 2]. Request [2, 0, 0] exceeds Need for R0.
        with pytest.raises(ValueError, match="exceeds its declared remaining Need"):
            resource_request(alloc, maximum, avail, process_index=1, request_vector=[2, 0, 0])

    def test_request_exceeds_available_denied(self, textbook_system):
        alloc, maximum, avail = textbook_system
        # P0 has Need [7, 4, 3]. Available is [3, 3, 2].
        # Request [0, 2, 0] <= Need, but what if request is [0, 4, 0]?
        # 4 > Available[1] (3) -> denied without modifying state
        res = resource_request(alloc, maximum, avail, process_index=0, request_vector=[0, 4, 0])
        assert res["granted"] is False
        assert res["rolled_back"] is False
        assert "must wait" in res["message"]
        # State unchanged
        assert res["available"] == avail
        assert res["allocation"] == alloc

    def test_request_unsafe_rolled_back(self, textbook_system):
        alloc, maximum, avail = textbook_system
        # P0 has Need [7, 4, 3] and Available is [3, 3, 2].
        # If P0 requests [0, 3, 0], available becomes [3, 0, 2].
        # Under available [3, 0, 2], every process has Need for R1 > 0:
        # P0 need R1=1, P1 need R1=2, P2 need R1=0 (but R0 need 6 > 3),
        # P3 need R1=1 > 0, P4 need R1=3 > 0.
        # Zero processes can finish -> deadlocked/unsafe state!
        # The algorithm MUST detect this unsafe state and roll back.
        res = resource_request(alloc, maximum, avail, process_index=0, request_vector=[0, 3, 0])
        assert res["granted"] is False
        assert res["rolled_back"] is True
        assert "UNSAFE state" in res["message"]
        assert res["available"] == [3, 3, 2]  # Restored!
        assert res["allocation"] == alloc      # Restored!
