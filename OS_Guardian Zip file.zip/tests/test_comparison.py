"""
tests/test_comparison.py
========================
Unit tests for cross-algorithm performance comparisons in algorithms/comparison.py.
Covers:
  - CPU Scheduling comparative analysis (FCFS, SJF, Priority, Round Robin)
  - Memory Allocation comparative analysis (First Fit, Best Fit, Worst Fit)
  - Page Replacement comparative analysis (FIFO, LRU, Optimal)
  - Identification of optimal metrics
  - Input validation and edge-case handling
"""

import pytest
from algorithms.comparison import (
    compare_cpu_scheduling,
    compare_memory_allocation,
    compare_page_replacement,
)


class TestCPUComparison:
    @pytest.fixture
    def sample_processes(self):
        return [
            {"pid": "P1", "arrival_time": 0, "burst_time": 6, "priority": 3},
            {"pid": "P2", "arrival_time": 1, "burst_time": 4, "priority": 1},
            {"pid": "P3", "arrival_time": 2, "burst_time": 2, "priority": 2},
            {"pid": "P4", "arrival_time": 3, "burst_time": 8, "priority": 4},
        ]

    def test_cpu_comparison_table_structure(self, sample_processes):
        res = compare_cpu_scheduling(sample_processes, quantum=2)
        assert res["workload_process_count"] == 4
        table = res["comparison_table"]
        assert len(table) == 4

        algos = {row["algorithm"] for row in table}
        assert algos == {"FCFS", "SJF", "Priority", "Round Robin"}

        for row in table:
            assert row["avg_turnaround_time"] > 0
            assert row["avg_waiting_time"] >= 0
            assert row["cpu_utilization"] > 0

        assert "min_turnaround" in res["best_metrics"]
        assert "min_waiting" in res["best_metrics"]
        assert "max_utilization" in res["best_metrics"]

    def test_empty_processes_raise(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            compare_cpu_scheduling([])

    def test_focused_cpu_comparison(self, sample_processes):
        # Select 2 algorithms: FCFS and SJF
        res = compare_cpu_scheduling(sample_processes, quantum=2, selected_algorithms=["FCFS", "SJF"])
        assert len(res["comparison_table"]) == 2
        algos = {row["algorithm"] for row in res["comparison_table"]}
        assert algos == {"FCFS", "SJF"}
        assert "tradeoff_analysis" in res
        assert len(res["tradeoff_analysis"]["algorithm_insights"]) == 2

    def test_cpu_insufficient_selection_raises(self, sample_processes):
        with pytest.raises(ValueError, match="at least 2"):
            compare_cpu_scheduling(sample_processes, selected_algorithms=["FCFS"])


class TestMemoryComparison:
    @pytest.fixture
    def memory_workload(self):
        blocks = [100, 500, 200, 300, 600]
        processes = [212, 417, 112, 426]
        return blocks, processes

    def test_memory_comparison_table(self, memory_workload):
        blocks, procs = memory_workload
        res = compare_memory_allocation(blocks, procs)
        table = res["comparison_table"]
        assert len(table) == 3

        strategies = {row["strategy"] for row in table}
        assert strategies == {"First Fit", "Best Fit", "Worst Fit"}

        # In this classic case: Best Fit allocates all 4, First Fit allocates 3
        best_fit_row = next(r for r in table if r["strategy"] == "Best Fit")
        first_fit_row = next(r for r in table if r["strategy"] == "First Fit")
        assert best_fit_row["allocated_processes"] == 4
        assert first_fit_row["allocated_processes"] == 3

        assert res["best_metrics"]["max_allocated"] == "Best Fit"

    def test_empty_memory_workload_raises(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            compare_memory_allocation([], [100])

    def test_focused_memory_comparison(self, memory_workload):
        blocks, procs = memory_workload
        res = compare_memory_allocation(blocks, procs, selected_algorithms=["First Fit", "Best Fit"])
        assert len(res["comparison_table"]) == 2
        strategies = {row["strategy"] for row in res["comparison_table"]}
        assert strategies == {"First Fit", "Best Fit"}
        assert "tradeoff_analysis" in res


class TestPagingComparison:
    def test_paging_comparison_table(self):
        pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
        res = compare_page_replacement(pages, num_frames=3)
        table = res["comparison_table"]
        assert len(table) == 3

        algos = {row["algorithm"] for row in table}
        assert algos == {"FIFO", "LRU", "Optimal"}

        fifo_row = next(r for r in table if r["algorithm"] == "FIFO")
        lru_row = next(r for r in table if r["algorithm"] == "LRU")
        opt_row = next(r for r in table if r["algorithm"] == "Optimal")

        # In this 20-ref sequence: FIFO=15 faults, LRU=12 faults, Optimal=9 faults
        assert fifo_row["page_faults"] == 15
        assert lru_row["page_faults"] == 12
        assert opt_row["page_faults"] == 9
        assert opt_row["page_faults"] < fifo_row["page_faults"]

        assert res["best_metrics"]["min_faults"] == "Optimal"

    def test_invalid_frames_raise(self):
        with pytest.raises(ValueError, match="Number of frames must be positive"):
            compare_page_replacement([1, 2, 3], num_frames=0)

    def test_focused_paging_comparison(self):
        pages = [1, 2, 3, 4, 1, 2]
        res = compare_page_replacement(pages, num_frames=3, selected_algorithms=["FIFO", "LRU"])
        assert len(res["comparison_table"]) == 2
        algos = {row["algorithm"] for row in res["comparison_table"]}
        assert algos == {"FIFO", "LRU"}
        assert "tradeoff_analysis" in res
