"""
tests/conftest.py
==================
pytest fixtures shared across all test modules.
"""

import pytest
from app import create_app


@pytest.fixture()
def app():
    """Create the Flask app in testing mode."""
    application = create_app()
    application.config.update({
        "TESTING": True,
        "SECRET_KEY": "test-secret-key",
    })
    yield application


@pytest.fixture()
def client(app):
    """Provide a test client for the Flask application."""
    return app.test_client()
