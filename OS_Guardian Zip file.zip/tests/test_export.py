"""
tests/test_export.py
====================
Automated verification for Excel workbook exports.
"""

import io
import openpyxl
from algorithms.export_utils import (
    export_system_snapshot_excel,
    export_deadlock_analysis_excel,
    export_comparison_excel,
    export_history_excel,
)


def test_export_system_snapshot():
    fake_snapshot = {
        "timestamp": "2026-10-21 12:00:00",
        "cpu": {"percent": 15.2, "logical_cores": 8, "physical_cores": 4},
        "memory": {"total_mb": 16384, "available_mb": 8192, "used_mb": 8192, "percent": 50.0},
        "swap": {"total_mb": 4096, "used_mb": 1024, "free_mb": 3072, "percent": 25.0},
        "process_count": 2,
        "processes": [
            {"pid": 100, "name": "system.exe", "status": "Running", "cpu_percent": 2.5, "memory_mb": 150.0, "memory_percent": 1.0, "username": "SYSTEM"},
            {"pid": 200, "name": "app.exe", "status": "Running", "cpu_percent": 5.0, "memory_mb": 300.0, "memory_percent": 2.0, "username": "User"},
        ]
    }
    bio = export_system_snapshot_excel(fake_snapshot)
    assert isinstance(bio, io.BytesIO)
    wb = openpyxl.load_workbook(bio)
    assert "System Overview" in wb.sheetnames
    assert "Process List" in wb.sheetnames
    assert wb["Process List"].max_row == 3


def test_export_deadlock_analysis():
    fake_analysis = {
        "is_deadlocked": True,
        "deadlocked_processes": ["P1", "P2"],
        "safe_sequence": [],
        "summary": "Deadlock detected.",
        "step_trace": [
            {"step": 0, "action": "Init", "description": "Init step", "work": [0, 0]}
        ]
    }
    bio = export_deadlock_analysis_excel(fake_analysis)
    wb = openpyxl.load_workbook(bio)
    assert "Detection Summary" in wb.sheetnames
    assert wb["Detection Summary"]["B3"].value == "DEADLOCK DETECTED"


def test_export_comparison():
    fake_comp = {
        "comparison_table": [
            {"algorithm": "FCFS", "avg_waiting_time": 4.5, "avg_turnaround_time": 8.5},
            {"algorithm": "SJF", "avg_waiting_time": 2.5, "avg_turnaround_time": 6.5},
        ],
        "tradeoff_analysis": {
            "summary": "SJF was faster.",
            "algorithm_insights": [{"title": "FCFS", "pros": "Simple", "cons": "Convoy", "best_for": "Batch"}]
        }
    }
    bio = export_comparison_excel(fake_comp, subsystem="cpu")
    wb = openpyxl.load_workbook(bio)
    assert "CPU Benchmark" in wb.sheetnames


def test_export_history():
    records = [
        {"id": 1, "timestamp": "2026-10-21 10:00:00", "module_type": "scheduling", "algorithm": "FCFS", "summary_text": "Good run", "parameters": {}}
    ]
    bio = export_history_excel(records)
    wb = openpyxl.load_workbook(bio)
    assert "Simulation Audit Log" in wb.sheetnames
    assert wb["Simulation Audit Log"].max_row == 5
