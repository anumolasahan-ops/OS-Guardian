"""
tests/test_routes.py
=====================
Automated smoke tests for all Flask routes.

Tests verify:
  - Each page returns HTTP 200
  - Correct Content-Type header
  - Health check endpoint returns JSON with expected keys
  - Module pages contain their expected heading text
"""

import json
import pytest


class TestHealthEndpoint:
    """Tests for the /health JSON endpoint."""

    def test_health_returns_200(self, client):
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_returns_json(self, client):
        response = client.get("/health")
        assert response.content_type == "application/json"

    def test_health_payload(self, client):
        response = client.get("/health")
        data = json.loads(response.data)
        assert data["status"] == "ok"
        assert data["app"] == "OS Guardian"


class TestDashboard:
    """Tests for the main dashboard page."""

    def test_index_returns_200(self, client):
        response = client.get("/")
        assert response.status_code == 200

    def test_index_contains_title(self, client):
        response = client.get("/")
        assert b"OS Guardian" in response.data

    def test_index_contains_module_links(self, client):
        response = client.get("/")
        assert b"CPU Scheduling" in response.data
        assert b"Memory Allocation" in response.data
        assert b"Page Replacement" in response.data
        assert b"Deadlock" in response.data
        assert b"Synchronization" in response.data

    def test_index_contains_disclaimer(self, client):
        """Dashboard must display the educational simulator notice."""
        response = client.get("/")
        assert b"Educational Simulator" in response.data


class TestModulePages:
    """Smoke tests: each module page returns HTTP 200."""

    def test_scheduling_page(self, client):
        response = client.get("/scheduling")
        assert response.status_code == 200
        assert b"CPU Scheduling" in response.data

    def test_memory_page(self, client):
        response = client.get("/memory")
        assert response.status_code == 200
        assert b"Memory Allocation" in response.data

    def test_paging_page(self, client):
        response = client.get("/paging")
        assert response.status_code == 200
        assert b"Page Replacement" in response.data

    def test_deadlock_page(self, client):
        response = client.get("/deadlock")
        assert response.status_code == 200
        assert b"Deadlock" in response.data

    def test_synchronization_page(self, client):
        response = client.get("/synchronization")
        assert response.status_code == 200
        assert b"Synchronization" in response.data

    def test_history_page(self, client):
        response = client.get("/history")
        assert response.status_code == 200
        assert b"History" in response.data


class TestNotFound:
    """Ensure unknown routes return 404 rather than crashing."""

    def test_unknown_route_returns_404(self, client):
        response = client.get("/nonexistent-page-xyz")
        assert response.status_code == 404


class TestMemoryPostEndpoint:
    """Tests for POST /memory/run."""

    def test_memory_run_valid(self, client):
        payload = {
            "strategy": "first_fit",
            "blocks": [100, 500, 200],
            "processes": [{"pid": "P1", "size": 212}, {"pid": "P2", "size": 100}],
        }
        resp = client.post("/memory/run", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["strategy"] == "first_fit"
        assert len(data["allocations"]) == 2
        assert data["allocations"][0]["block_id"] == "B2"

    def test_memory_run_invalid_strategy(self, client):
        resp = client.post("/memory/run", json={"strategy": "invalid", "blocks": [100], "processes": [50]})
        assert resp.status_code == 400

    def test_memory_run_empty_data(self, client):
        resp = client.post("/memory/run", json={})
        assert resp.status_code == 400


class TestPagingPostEndpoint:
    """Tests for POST /paging/run."""

    def test_paging_run_valid(self, client):
        payload = {
            "algorithm": "fifo",
            "num_frames": 3,
            "pages": "7, 0, 1, 2, 0, 3",
        }
        resp = client.post("/paging/run", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["algorithm"] == "fifo"
        assert data["page_faults"] == 5
        assert len(data["steps"]) == 6

    def test_paging_run_invalid_algorithm(self, client):
        resp = client.post("/paging/run", json={"algorithm": "invalid", "pages": [1, 2], "num_frames": 3})
        assert resp.status_code == 400

    def test_paging_run_empty_pages(self, client):
        resp = client.post("/paging/run", json={"algorithm": "lru", "pages": "", "num_frames": 3})
        assert resp.status_code == 422



class TestDeadlockRoutes:
    """Tests for Deadlock Management routes."""

    @pytest.fixture
    def safe_payload(self):
        return {
            "allocation": [[0, 1, 0], [2, 0, 0], [3, 0, 2], [2, 1, 1], [0, 0, 2]],
            "maximum": [[7, 5, 3], [3, 2, 2], [9, 0, 2], [2, 2, 2], [4, 3, 3]],
            "available": [3, 3, 2],
        }

    def test_deadlock_run_valid(self, client, safe_payload):
        resp = client.post("/deadlock/run", json=safe_payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["is_safe"] is True
        assert len(data["safe_sequence"]) == 5

    def test_deadlock_run_empty_raises_400(self, client):
        resp = client.post("/deadlock/run", json={})
        assert resp.status_code == 400

    def test_deadlock_run_invalid_matrix_422(self, client):
        payload = {
            "allocation": [[5, 5]],  # alloc > max
            "maximum": [[2, 2]],
            "available": [1, 1],
        }
        resp = client.post("/deadlock/run", json=payload)
        assert resp.status_code == 422

    def test_deadlock_request_valid(self, client, safe_payload):
        payload = dict(safe_payload)
        payload["process_index"] = 1
        payload["request_vector"] = [1, 0, 2]
        resp = client.post("/deadlock/request", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["granted"] is True

    def test_deadlock_request_unsafe_rollback(self, client, safe_payload):
        payload = dict(safe_payload)
        payload["process_index"] = 0
        payload["request_vector"] = [0, 3, 0]
        resp = client.post("/deadlock/request", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["granted"] is False
        assert data["rolled_back"] is True


class TestSynchronizationRoutes:
    """Tests for Thread Synchronization routes."""

    def test_producer_consumer_run(self, client):
        resp = client.post("/synchronization/producer-consumer", json={
            "buffer_capacity": 4,
            "num_items": 6,
            "delay": 0.001,
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["success"] is True
        assert data["items_produced"] == 6

    def test_producer_consumer_invalid(self, client):
        resp = client.post("/synchronization/producer-consumer", json={
            "buffer_capacity": 0,
        })
        assert resp.status_code == 422

    def test_reader_writer_run(self, client):
        resp = client.post("/synchronization/reader-writer", json={
            "num_readers": 2,
            "num_writers": 2,
            "operations_per_thread": 1,
            "delay": 0.001,
        })
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["success"] is True
        assert data["mutual_exclusion_verified"] is True

    def test_reader_writer_invalid(self, client):
        resp = client.post("/synchronization/reader-writer", json={
            "num_readers": 50,
        })
        assert resp.status_code == 422


class TestHistoryRoutes:
    """Tests for History CRUD endpoints."""

    def test_history_crud_flow(self, client):
        # 1. Save record
        save_payload = {
            "module_type": "cpu_scheduling",
            "algorithm": "fcfs",
            "parameters": {"processes": [{"pid": "P1", "arrival": 0, "burst": 4}]},
            "results": {"gantt": [{"pid": "P1", "start": 0, "end": 4}]},
            "summary_metrics": {"avg_tat": 4.0},
            "summary_text": "Single process FCFS",
        }
        post_resp = client.post("/history/save", json=save_payload)
        assert post_resp.status_code == 201
        data = post_resp.get_json()
        rec_id = data["id"]
        assert rec_id > 0

        # 2. Get records
        get_resp = client.get("/history/records")
        assert get_resp.status_code == 200
        records = get_resp.get_json()["records"]
        assert any(r["id"] == rec_id for r in records)

        # 3. View single record
        view_resp = client.get(f"/history/view/{rec_id}")
        assert view_resp.status_code == 200
        assert view_resp.get_json()["algorithm"] == "fcfs"

        # 4. View non-existent
        view_404 = client.get("/history/view/99999")
        assert view_404.status_code == 404

        # 5. Delete record
        del_resp = client.post(f"/history/delete/{rec_id}")
        assert del_resp.status_code == 200

        # 6. Delete again -> 404
        del_404 = client.post(f"/history/delete/{rec_id}")
        assert del_404.status_code == 404

    def test_history_save_scheduling_valid(self, client):
        payload = {
            "module_type": "scheduling",
            "algorithm": "FCFS",
            "parameters": {
                "algorithm": "fcfs",
                "quantum": 2,
                "processes": [
                    {"pid": "P1", "arrival_time": 0, "burst_time": 4, "priority": 1},
                    {"pid": "P2", "arrival_time": 1, "burst_time": 3, "priority": 2}
                ]
            },
            "results": {
                "results": [
                    {"pid": "P1", "turnaround_time": 4, "waiting_time": 0},
                    {"pid": "P2", "turnaround_time": 6, "waiting_time": 3}
                ],
                "gantt": [{"pid": "P1", "start": 0, "end": 4}, {"pid": "P2", "start": 4, "end": 7}]
            },
            "summary_metrics": {
                "avg_turnaround": 5.0,
                "avg_waiting": 1.5,
                "avg_response": 1.5,
                "cpu_utilization": 100.0
            },
            "summary_text": "FCFS with 2 processes (Avg Wait: 1.5 ms, TAT: 5.0 ms)"
        }
        resp = client.post("/history/save", json=payload)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["status"] == "ok"
        rec_id = data["id"]
        assert rec_id > 0

        # Retrieve via /history/view/<id>
        view_resp = client.get(f"/history/view/{rec_id}")
        assert view_resp.status_code == 200
        rec = view_resp.get_json()
        assert rec["module_type"] == "scheduling"
        assert rec["algorithm"] == "FCFS"
        assert rec["parameters"]["quantum"] == 2
        assert rec["summary_metrics"]["avg_waiting"] == 1.5

        # Cleanup
        client.post(f"/history/delete/{rec_id}")

    def test_history_save_missing_module_type_returns_400(self, client):
        payload = {
            "algorithm": "FCFS",
            "parameters": {}
        }
        resp = client.post("/history/save", json=payload)
        assert resp.status_code == 400
        data = resp.get_json()
        assert "module_type and algorithm are required" in data["error"]

    def test_history_save_missing_algorithm_returns_400(self, client):
        payload = {
            "module_type": "scheduling",
            "parameters": {}
        }
        resp = client.post("/history/save", json=payload)
        assert resp.status_code == 400
        data = resp.get_json()
        assert "module_type and algorithm are required" in data["error"]

    def test_history_save_empty_body_returns_400(self, client):
        resp = client.post("/history/save", data="", content_type="application/json")
        assert resp.status_code == 400
        data = resp.get_json()
        assert "Invalid or empty JSON body" in data["error"]

    def test_history_filter_scheduling(self, client):
        # Save a scheduling record
        p = {
            "module_type": "scheduling",
            "algorithm": "Round Robin",
            "parameters": {"quantum": 3},
            "results": {},
            "summary_metrics": {"avg_waiting": 2.0}
        }
        resp = client.post("/history/save", json=p)
        assert resp.status_code == 201
        rec_id = resp.get_json()["id"]

        # Filter by scheduling
        f_resp = client.get("/history/records?module=scheduling")
        assert f_resp.status_code == 200
        records = f_resp.get_json()["records"]
        assert any(r["id"] == rec_id and r["module_type"] == "scheduling" for r in records)

        # Cleanup
        client.post(f"/history/delete/{rec_id}")

    def test_history_record_insertion_and_retrieval_regression(self, client):
        """
        Regression test: Inserts a simulation run into SQLite, queries the
        /history/records API endpoint, and verifies that the record and its
        summary metrics and counts are accurately returned.
        """
        payload = {
            "module_type": "system_monitor",
            "algorithm": "Windows Host Snapshot",
            "parameters": {"logical_cores": 8, "total_ram_mb": 16384},
            "results": {"cpu_percent": 24.5, "memory_percent": 62.1},
            "summary_metrics": {"cpu_percent": 24.5, "memory_percent": 62.1, "process_count": 180},
            "summary_text": "Host Snapshot: CPU 24.5% | RAM 62.1% | 180 active tasks",
        }
        # 1. Save
        post_resp = client.post("/history/save", json=payload)
        assert post_resp.status_code == 201
        rec_id = post_resp.get_json()["id"]
        assert rec_id > 0

        # 2. Retrieve via /history/records
        get_resp = client.get("/history/records")
        assert get_resp.status_code == 200
        data = get_resp.get_json()
        assert "records" in data
        assert "counts" in data
        assert data["counts"]["total"] >= 1
        assert data["counts"]["system_monitor"] >= 1

        matching_recs = [r for r in data["records"] if r["id"] == rec_id]
        assert len(matching_recs) == 1
        rec = matching_recs[0]
        assert rec["module_type"] == "system_monitor"
        assert rec["algorithm"] == "Windows Host Snapshot"
        assert rec["summary_text"] == "Host Snapshot: CPU 24.5% | RAM 62.1% | 180 active tasks"
        assert rec["summary_metrics"]["process_count"] == 180

        # 3. Verify single record endpoint
        view_resp = client.get(f"/history/view/{rec_id}")
        assert view_resp.status_code == 200
        assert view_resp.get_json()["id"] == rec_id

        # 4. Clean up
        del_resp = client.post(f"/history/delete/{rec_id}")
        assert del_resp.status_code == 200


class TestComparisonRoutes:
    """Tests for Performance Comparison endpoints."""

    def test_comparison_page(self, client):
        resp = client.get("/comparison")
        assert resp.status_code == 200
        assert b"Comparison" in resp.data

    def test_comparison_cpu(self, client):
        payload = {
            "subsystem": "cpu",
            "data": {
                "processes": [
                    {"pid": "P1", "arrival_time": 0, "burst_time": 4, "priority": 1},
                    {"pid": "P2", "arrival_time": 1, "burst_time": 2, "priority": 2},
                ],
                "quantum": 2,
            },
        }
        resp = client.post("/comparison/run", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data["comparison_table"]) == 4

    def test_comparison_memory(self, client):
        payload = {
            "subsystem": "memory",
            "data": {
                "blocks": [100, 200],
                "processes": [50, 120],
            },
        }
        resp = client.post("/comparison/run", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data["comparison_table"]) == 3

    def test_comparison_paging(self, client):
        payload = {
            "subsystem": "paging",
            "data": {
                "pages": [1, 2, 3, 1, 4],
                "num_frames": 3,
            },
        }
        resp = client.post("/comparison/run", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data["comparison_table"]) == 3

    def test_comparison_invalid_subsystem(self, client):
        resp = client.post("/comparison/run", json={"subsystem": "invalid", "data": {}})
        assert resp.status_code == 400


class TestSystemMonitorRoutes:
    """Tests for Windows host telemetry and formal deadlock detection."""

    def test_system_monitor_page(self, client):
        resp = client.get("/system-monitor")
        assert resp.status_code == 200
        assert b"Windows System Monitor" in resp.data

    def test_system_monitor_snapshot(self, client):
        resp = client.get("/system-monitor/snapshot")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "cpu" in data
        assert "memory" in data
        assert "processes" in data

    def test_deadlock_detection_endpoint_safe(self, client):
        payload = {
            "allocation": [[0, 1, 0], [2, 0, 0], [3, 0, 3]],
            "request": [[0, 0, 0], [2, 0, 2], [0, 0, 0]],
            "available": [0, 0, 0],
        }
        resp = client.post("/system-monitor/deadlock-detect", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["is_deadlocked"] is False
        assert len(data["safe_sequence"]) == 3

    def test_deadlock_detection_endpoint_deadlock(self, client):
        payload = {
            "allocation": [[1, 0], [0, 1]],
            "request": [[0, 1], [1, 0]],
            "available": [0, 0],
        }
        resp = client.post("/system-monitor/deadlock-detect", json=payload)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["is_deadlocked"] is True
        assert set(data["deadlocked_processes"]) == {"P0", "P1"}


class TestExportRoutes:
    """Tests for Excel export endpoints (.xlsx)."""

    def test_export_system_snapshot(self, client):
        resp = client.get("/system-monitor/export?type=snapshot")
        assert resp.status_code == 200
        assert "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in resp.content_type
        assert len(resp.data) > 1000

    def test_export_deadlock_analysis(self, client):
        resp = client.get("/system-monitor/export?type=deadlock")
        assert resp.status_code == 200
        assert "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in resp.content_type
        assert len(resp.data) > 1000

    def test_export_comparison(self, client):
        resp = client.get("/comparison/export?subsystem=cpu")
        assert resp.status_code == 200
        assert "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in resp.content_type
        assert len(resp.data) > 1000

    def test_export_history(self, client):
        resp = client.get("/history/export")
        assert resp.status_code == 200
        assert "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in resp.content_type
        assert len(resp.data) > 1000
