"""
tests/test_paging.py
====================
Automated test suite for Page Replacement algorithms:
  - FIFO
  - LRU
  - Optimal (Belady's Algorithm)

Includes hand-calculated expected results for:
  - Standard textbook benchmark sequence (Silberschatz)
  - Belady's Anomaly sequence
  - Hit rates, fault counts, and eviction sequence
  - Edge cases (frames >= page count, single frame, repeated pages)
  - Input validation (empty string, frame count <= 0)
"""

import pytest
from algorithms.page_replacement import fifo, lru, optimal


class TestPageReplacementTextbookCase:
    """
    Standard textbook benchmark:
    Pages: [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
    Frames: 3
    """
    PAGES = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1]
    NUM_FRAMES = 3

    def test_fifo_textbook_faults(self):
        """
        Textbook FIFO with 3 frames yields exactly 15 faults and 5 hits.
        Fault ratio = (15 / 20) * 100 = 75.0%
        """
        res = fifo(self.PAGES, self.NUM_FRAMES)
        assert res["total_references"] == 20
        assert res["page_faults"] == 15
        assert res["page_hits"] == 5
        assert res["fault_ratio"] == 75.0
        assert res["hit_ratio"] == 25.0

    def test_lru_textbook_faults(self):
        """
        Textbook LRU with 3 frames yields exactly 12 faults and 8 hits.
        Fault ratio = (12 / 20) * 100 = 60.0%
        """
        res = lru(self.PAGES, self.NUM_FRAMES)
        assert res["total_references"] == 20
        assert res["page_faults"] == 12
        assert res["page_hits"] == 8
        assert res["fault_ratio"] == 60.0
        assert res["hit_ratio"] == 40.0

    def test_optimal_textbook_faults(self):
        """
        Textbook Optimal with 3 frames yields exactly 9 faults and 11 hits.
        Fault ratio = (9 / 20) * 100 = 45.0%
        """
        res = optimal(self.PAGES, self.NUM_FRAMES)
        assert res["total_references"] == 20
        assert res["page_faults"] == 9
        assert res["page_hits"] == 11
        assert res["fault_ratio"] == 45.0
        assert res["hit_ratio"] == 55.0


class TestBeladysAnomalyFIFO:
    """
    Sequence: [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]
    Demonstrates Belady's Anomaly for FIFO:
    - 3 frames: 9 page faults
    - 4 frames: 10 page faults
    """
    PAGES = [1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5]

    def test_belady_fifo_3_frames(self):
        res = fifo(self.PAGES, 3)
        assert res["page_faults"] == 9

    def test_belady_fifo_4_frames(self):
        res = fifo(self.PAGES, 4)
        assert res["page_faults"] == 10  # More faults with more frames (anomaly!)


class TestPagingEdgeCases:
    def test_single_frame(self):
        """With 1 frame, alternating pages fault every time."""
        pages = [1, 2, 1, 2]
        res = fifo(pages, 1)
        assert res["page_faults"] == 4
        assert res["page_hits"] == 0

    def test_repeated_pages_consecutive(self):
        """Repeated identical requests hit continuously."""
        pages = [1, 1, 1, 1, 1]
        res = fifo(pages, 2)
        assert res["page_faults"] == 1
        assert res["page_hits"] == 4

    def test_string_format_support(self):
        """Comma/space-separated string is parsed identically to list."""
        res = fifo("7, 0, 1, 2", 3)
        assert res["total_references"] == 4
        assert res["page_faults"] == 4

    def test_frames_larger_than_page_count(self):
        """When frames >= unique pages, every first occurrence faults, later hits."""
        pages = [1, 2, 3, 1, 2]
        res = lru(pages, 5)
        assert res["page_faults"] == 3
        assert res["page_hits"] == 2


class TestPagingValidation:
    def test_empty_pages_raises(self):
        with pytest.raises(ValueError, match="empty"):
            fifo("", 3)

    def test_non_positive_frames_raises(self):
        with pytest.raises(ValueError, match="greater than 0"):
            fifo([1, 2, 3], 0)

    def test_invalid_frames_type_raises(self):
        with pytest.raises(ValueError, match="positive integer"):
            fifo([1, 2, 3], "three")
