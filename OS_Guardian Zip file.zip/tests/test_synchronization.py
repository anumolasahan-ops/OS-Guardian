"""
tests/test_synchronization.py
==============================
Unit tests for Thread Synchronization algorithms in algorithms/synchronization.py.
Covers:
  - Producer–Consumer bounded buffer coordination
  - Buffer capacity boundary enforcement (no overflow)
  - Full items consumed (no underflow)
  - Reader–Writer mutual exclusion verification
  - Writer exclusivity and concurrent readers
  - Input validation and timeout handling
"""

import pytest
from algorithms.synchronization import producer_consumer_demo, reader_writer_demo


class TestProducerConsumer:
    def test_normal_producer_consumer(self):
        res = producer_consumer_demo(buffer_capacity=5, num_items=8, delay=0.001)
        assert res["success"] is True
        assert res["items_produced"] == 8
        assert res["items_consumed"] == 8
        assert res["final_buffer"] == []
        assert res["peak_buffer_occupancy"] <= 5
        assert len(res["event_log"]) > 0

    def test_buffer_capacity_never_exceeded(self):
        capacity = 3
        res = producer_consumer_demo(buffer_capacity=capacity, num_items=12, delay=0.001)
        assert res["success"] is True
        assert res["peak_buffer_occupancy"] <= capacity

        # Verify every event buffer state in log respects capacity
        for event in res["event_log"]:
            assert len(event["buffer_state"]) <= capacity
            assert event["occupancy"] <= capacity

    def test_single_slot_buffer(self):
        res = producer_consumer_demo(buffer_capacity=1, num_items=5, delay=0.001)
        assert res["success"] is True
        assert res["items_produced"] == 5
        assert res["items_consumed"] == 5
        assert res["peak_buffer_occupancy"] <= 1

    def test_invalid_parameters_raise(self):
        with pytest.raises(ValueError, match="Buffer capacity must be a positive integer"):
            producer_consumer_demo(buffer_capacity=0, num_items=5)

        with pytest.raises(ValueError, match="Number of items must be a positive integer"):
            producer_consumer_demo(buffer_capacity=5, num_items=-1)

        with pytest.raises(ValueError, match="Buffer capacity must not exceed"):
            producer_consumer_demo(buffer_capacity=100, num_items=5)


class TestReaderWriter:
    def test_normal_reader_writer(self):
        res = reader_writer_demo(num_readers=3, num_writers=2, operations_per_thread=2, delay=0.001)
        assert res["success"] is True
        assert res["reads_completed"] == 6
        assert res["writes_completed"] == 4
        assert res["mutual_exclusion_verified"] is True
        assert res["violations"] == 0

    def test_mutual_exclusion_integrity(self):
        res = reader_writer_demo(num_readers=4, num_writers=3, operations_per_thread=2, delay=0.001)
        assert res["mutual_exclusion_verified"] is True

        # Verify no writer was ever active while another writer or reader was active
        for event in res["event_log"]:
            writers = event["active_writers"]
            readers = event["active_readers"]
            assert writers in (0, 1)
            if writers == 1:
                assert readers == 0

    def test_invalid_parameters_raise(self):
        with pytest.raises(ValueError, match="Number of readers must be between"):
            reader_writer_demo(num_readers=0, num_writers=2)

        with pytest.raises(ValueError, match="Number of writers must be between"):
            reader_writer_demo(num_readers=3, num_writers=0)

        with pytest.raises(ValueError, match="Operations per thread must be between"):
            reader_writer_demo(num_readers=3, num_writers=2, operations_per_thread=10)
