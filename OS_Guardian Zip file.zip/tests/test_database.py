"""
tests/test_database.py
======================
Unit tests for SQLite simulation persistence in database/db_utils.py.
Covers:
  - Table initialization
  - Insertion of simulation records
  - Retrieval and JSON deserialization
  - Filtering by module_type
  - Retrieval by ID and 404 handling
  - Deletion of records
  - Clear all / module-specific clear
  - Record counting
  - Input validation
"""

import pytest
from database.db_utils import (
    init_db,
    save_simulation,
    get_all_simulations,
    get_simulation_by_id,
    delete_simulation,
    clear_all_simulations,
    get_simulation_counts,
)


@pytest.fixture
def temp_db(tmp_path):
    """Provide an isolated temporary database for each test."""
    db_file = str(tmp_path / "test_os_guardian.db")
    init_db(db_file)
    return db_file


class TestDatabaseOperations:
    def test_save_and_retrieve_record(self, temp_db):
        params = {"processes": [{"pid": "P1", "arrival": 0, "burst": 5}]}
        results = {"gantt": [{"pid": "P1", "start": 0, "end": 5}]}
        metrics = {"avg_tat": 5.0, "avg_wt": 0.0}

        rec_id = save_simulation(
            module_type="cpu_scheduling",
            algorithm="fcfs",
            parameters=params,
            results=results,
            summary_metrics=metrics,
            summary_text="FCFS with 1 process",
            db_path=temp_db,
        )

        assert isinstance(rec_id, int)
        assert rec_id > 0

        # Retrieve record
        rec = get_simulation_by_id(rec_id, db_path=temp_db)
        assert rec is not None
        assert rec["id"] == rec_id
        assert rec["module_type"] == "cpu_scheduling"
        assert rec["algorithm"] == "fcfs"
        assert rec["parameters"] == params
        assert rec["results"] == results
        assert rec["summary_metrics"] == metrics
        assert rec["summary_text"] == "FCFS with 1 process"

    def test_get_all_and_filtering(self, temp_db):
        save_simulation("cpu_scheduling", "fcfs", {}, {}, {}, db_path=temp_db)
        save_simulation("cpu_scheduling", "sjf", {}, {}, {}, db_path=temp_db)
        save_simulation("memory", "first_fit", {}, {}, {}, db_path=temp_db)
        save_simulation("paging", "lru", {}, {}, {}, db_path=temp_db)

        all_recs = get_all_simulations(db_path=temp_db)
        assert len(all_recs) == 4

        cpu_recs = get_all_simulations(module_type="cpu_scheduling", db_path=temp_db)
        assert len(cpu_recs) == 2
        for r in cpu_recs:
            assert r["module_type"] == "cpu_scheduling"

        mem_recs = get_all_simulations(module_type="memory", db_path=temp_db)
        assert len(mem_recs) == 1
        assert mem_recs[0]["algorithm"] == "first_fit"

    def test_delete_record(self, temp_db):
        rec_id = save_simulation("cpu_scheduling", "rr", {}, {}, {}, db_path=temp_db)
        assert get_simulation_by_id(rec_id, db_path=temp_db) is not None

        deleted = delete_simulation(rec_id, db_path=temp_db)
        assert deleted is True
        assert get_simulation_by_id(rec_id, db_path=temp_db) is None

        # Deleting again should return False
        assert delete_simulation(rec_id, db_path=temp_db) is False

    def test_clear_all_simulations(self, temp_db):
        save_simulation("cpu_scheduling", "fcfs", {}, {}, {}, db_path=temp_db)
        save_simulation("memory", "best_fit", {}, {}, {}, db_path=temp_db)
        save_simulation("paging", "fifo", {}, {}, {}, db_path=temp_db)

        # Clear only memory
        cleared_mem = clear_all_simulations(module_type="memory", db_path=temp_db)
        assert cleared_mem == 1
        assert len(get_all_simulations(db_path=temp_db)) == 2

        # Clear remaining
        cleared_all = clear_all_simulations(db_path=temp_db)
        assert cleared_all == 2
        assert len(get_all_simulations(db_path=temp_db)) == 0

    def test_simulation_counts(self, temp_db):
        save_simulation("cpu_scheduling", "fcfs", {}, {}, {}, db_path=temp_db)
        save_simulation("cpu_scheduling", "sjf", {}, {}, {}, db_path=temp_db)
        save_simulation("paging", "lru", {}, {}, {}, db_path=temp_db)

        counts = get_simulation_counts(db_path=temp_db)
        assert counts["total"] == 3
        assert counts["cpu_scheduling"] == 2
        assert counts["paging"] == 1

    def test_missing_id_returns_none(self, temp_db):
        assert get_simulation_by_id(99999, db_path=temp_db) is None

    def test_validation_errors(self, temp_db):
        with pytest.raises(ValueError, match="module_type is required"):
            save_simulation("", "fcfs", {}, {}, {}, db_path=temp_db)

        with pytest.raises(ValueError, match="algorithm is required"):
            save_simulation("cpu_scheduling", "", {}, {}, {}, db_path=temp_db)
