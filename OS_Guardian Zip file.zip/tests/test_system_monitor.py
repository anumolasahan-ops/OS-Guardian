"""
tests/test_system_monitor.py
============================
Automated tests for Windows host system monitoring and multi-resource deadlock detection.
"""

import pytest
from algorithms.system_monitor import get_system_snapshot, detect_deadlock


def test_system_snapshot():
    snapshot = get_system_snapshot(max_processes=10)
    assert "timestamp" in snapshot
    assert "cpu" in snapshot
    assert snapshot["cpu"]["percent"] >= 0.0
    assert snapshot["cpu"]["logical_cores"] >= 1
    assert "memory" in snapshot
    assert snapshot["memory"]["total_mb"] > 0
    assert snapshot["memory"]["percent"] >= 0.0
    assert snapshot["process_count"] > 0
    assert isinstance(snapshot["processes"], list)
    assert len(snapshot["processes"]) <= 10

    if snapshot["processes"]:
        p = snapshot["processes"][0]
        assert "pid" in p
        assert "name" in p
        assert "cpu_percent" in p
        assert "memory_mb" in p


def test_deadlock_detection_safe_state():
    # Classic textbook safe case
    # 3 processes, 3 resource types
    allocation = [
        [0, 1, 0],
        [2, 0, 0],
        [3, 0, 3],
    ]
    request = [
        [0, 0, 0],
        [2, 0, 2],
        [0, 0, 0],
    ]
    available = [0, 0, 0]

    res = detect_deadlock(allocation, request, available)
    assert not res["is_deadlocked"]
    assert len(res["deadlocked_processes"]) == 0
    assert len(res["safe_sequence"]) == 3
    assert len(res["step_trace"]) >= 2


def test_deadlock_detection_deadlocked_state():
    # Classic deadlocked case
    # P1 requests R2 while holding R1
    # P2 requests R1 while holding R2
    allocation = [
        [1, 0],
        [0, 1],
    ]
    request = [
        [0, 1],
        [1, 0],
    ]
    available = [0, 0]

    res = detect_deadlock(allocation, request, available, ["P0", "P1"], ["R0", "R1"])
    assert res["is_deadlocked"]
    assert set(res["deadlocked_processes"]) == {"P0", "P1"}
    assert len(res["safe_sequence"]) == 0
    assert "DEADLOCK DETECTED" in res["summary"]


def test_deadlock_detection_dimension_mismatch():
    with pytest.raises(ValueError, match="resources"):
        detect_deadlock([[1, 2]], [[1]], [1, 2])
