/**
 * static/js/memory.js
 * ====================
 * Client-side controller for Memory Allocation module:
 *  - Dynamic rows for blocks and processes
 *  - Preset loading
 *  - API submission to /memory/run
 *  - Rendering allocation cards, detailed tables, and memory diagram
 */

'use strict';

let blockCounter = 0;
let procCounter = 0;
let lastMemoryRun = null;

document.addEventListener('DOMContentLoaded', () => {
  const addBlockBtn = document.getElementById('addBlockBtn');
  const addProcBtn = document.getElementById('addProcBtn');
  const runBtn = document.getElementById('runMemBtn');

  addBlockBtn.addEventListener('click', () => addBlockRow());
  addProcBtn.addEventListener('click', () => addProcRow());
  runBtn.addEventListener('click', runMemorySimulation);

  loadMemoryExample('standard');

  if (new URLSearchParams(window.location.search).has('autorun')) {
    setTimeout(runMemorySimulation, 200);
  }

  const btnSave = document.getElementById('btnSaveMemoryHistory');
  if (btnSave) {
    btnSave.addEventListener('click', async () => {
      if (!lastMemoryRun) {
        alert('Please run an allocation simulation before saving to history.');
        return;
      }
      try {
        const strategyNames = {
          first_fit: 'First Fit',
          best_fit: 'Best Fit',
          worst_fit: 'Worst Fit',
        };
        const algoName = strategyNames[lastMemoryRun.strategy] || lastMemoryRun.strategy;
        const metrics = (lastMemoryRun.data && lastMemoryRun.data.metrics) ? lastMemoryRun.data.metrics : {};
        const resp = await fetch('/history/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            module_type: 'memory',
            algorithm: algoName,
            parameters: {
              strategy: lastMemoryRun.strategy,
              blocks: lastMemoryRun.blocks,
              processes: lastMemoryRun.procs
            },
            results: lastMemoryRun.data,
            summary_metrics: metrics,
            summary_text: `${algoName}: ${metrics.allocated_processes_count ?? 0} allocated, ${metrics.unallocated_processes_count ?? 0} unallocated (Util: ${metrics.utilization_percentage ?? 0}%)`
          })
        });
        const res = await resp.json();
        if (resp.ok) {
          alert('Memory simulation saved to History! (ID: #' + res.id + ')');
        } else {
          alert(res.error || 'Failed to save to history');
        }
      } catch (err) {
        alert('Error saving history: ' + err.message);
      }
    });
  }
});

function addBlockRow(id, size) {
  blockCounter++;
  const bid = (typeof id === 'string') ? id : `B${blockCounter}`;
  const bsize = (typeof size === 'number') ? size : 100;

  const tbody = document.getElementById('blocksBody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text" class="form-control form-control-sm block-id-input" value="${esc(bid)}" maxlength="8" /></td>
    <td><input type="number" class="form-control form-control-sm block-size-input" value="${bsize}" min="1" max="99999" /></td>
    <td>
      <button class="btn btn-sm btn-outline-danger remove-block-btn" title="Remove block" type="button">
        <i class="bi bi-trash3"></i>
      </button>
    </td>
  `;
  tr.querySelector('.remove-block-btn').addEventListener('click', () => tr.remove());
  tbody.appendChild(tr);
}

function addProcRow(pid, size) {
  procCounter++;
  const processId = (typeof pid === 'string') ? pid : `P${procCounter}`;
  const processSize = (typeof size === 'number') ? size : 50;

  const tbody = document.getElementById('procsBody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text" class="form-control form-control-sm proc-pid-input" value="${esc(processId)}" maxlength="8" /></td>
    <td><input type="number" class="form-control form-control-sm proc-size-input" value="${processSize}" min="1" max="99999" /></td>
    <td>
      <button class="btn btn-sm btn-outline-danger remove-proc-btn" title="Remove process" type="button">
        <i class="bi bi-trash3"></i>
      </button>
    </td>
  `;
  tr.querySelector('.remove-proc-btn').addEventListener('click', () => tr.remove());
  tbody.appendChild(tr);
}

const MEMORY_EXAMPLES = {
  standard: {
    // Classic Silberschatz 5-block, 4-process textbook example
    blocks: [
      { id: 'B1', size: 100 },
      { id: 'B2', size: 500 },
      { id: 'B3', size: 200 },
      { id: 'B4', size: 300 },
      { id: 'B5', size: 600 },
    ],
    procs: [
      { pid: 'P1', size: 212 },
      { pid: 'P2', size: 417 },
      { pid: 'P3', size: 112 },
      { pid: 'P4', size: 426 },
    ],
  },
  tight: {
    blocks: [
      { id: 'B1', size: 150 },
      { id: 'B2', size: 250 },
      { id: 'B3', size: 350 },
    ],
    procs: [
      { pid: 'P1', size: 150 },
      { pid: 'P2', size: 240 },
      { pid: 'P3', size: 350 },
    ],
  },
  unallocated: {
    blocks: [
      { id: 'B1', size: 100 },
      { id: 'B2', size: 200 },
    ],
    procs: [
      { pid: 'P1', size: 150 },
      { pid: 'P2', size: 300 },
      { pid: 'P3', size: 80 },
    ],
  },
};

function loadMemoryExample(key) {
  const example = MEMORY_EXAMPLES[key] || MEMORY_EXAMPLES.standard;
  document.getElementById('blocksBody').innerHTML = '';
  document.getElementById('procsBody').innerHTML = '';
  blockCounter = 0;
  procCounter = 0;

  example.blocks.forEach(b => addBlockRow(b.id, b.size));
  example.procs.forEach(p => addProcRow(p.pid, p.size));
}

function getMemoryData() {
  const blockRows = document.querySelectorAll('#blocksBody tr');
  const blocks = Array.from(blockRows).map(row => ({
    id: row.querySelector('.block-id-input').value.trim(),
    size: parseInt(row.querySelector('.block-size-input').value, 10),
  }));

  const procRows = document.querySelectorAll('#procsBody tr');
  const procs = Array.from(procRows).map(row => ({
    pid: row.querySelector('.proc-pid-input').value.trim(),
    size: parseInt(row.querySelector('.proc-size-input').value, 10),
  }));

  return { blocks, procs };
}

async function runMemorySimulation() {
  const errorDiv = document.getElementById('memError');
  const runBtn = document.getElementById('runMemBtn');
  errorDiv.classList.add('d-none');

  const strategy = document.getElementById('strategySelect').value;
  const { blocks, procs } = getMemoryData();

  if (blocks.length === 0) {
    showMemError('Add at least one memory block.');
    return;
  }
  if (procs.length === 0) {
    showMemError('Add at least one process.');
    return;
  }

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Simulating...';

  try {
    const resp = await fetch('/memory/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ strategy, blocks, processes: procs }),
    });

    const data = await resp.json();
    if (!resp.ok) {
      showMemError(data.error || 'Server error occurred during allocation.');
      return;
    }

    lastMemoryRun = { strategy, blocks, procs, data };
    renderMemoryResults(data);
  } catch (err) {
    showMemError('Network error: ' + err.message);
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Run Allocation Simulation';
  }
}

function showMemError(msg) {
  const errDiv = document.getElementById('memError');
  errDiv.textContent = msg;
  errDiv.classList.remove('d-none');
}

function renderMemoryResults(data) {
  document.getElementById('memPlaceholder').classList.add('d-none');
  document.getElementById('memResultsPanel').classList.remove('d-none');

  const strategyNames = {
    first_fit: 'First Fit',
    best_fit: 'Best Fit',
    worst_fit: 'Worst Fit',
  };
  document.getElementById('memStrategyLabel').textContent = strategyNames[data.strategy] || data.strategy;

  renderMemMetricCards(data.metrics);
  renderMemoryDiagram(data.blocks);
  renderAllocationsTable(data.allocations);
  renderMemTrace(data.step_trace);
}

function renderMemTrace(trace) {
  const tbody = document.getElementById('memTraceBody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!trace || !trace.length) return;

  trace.forEach((step) => {
    const isAlloc = step.status === 'Allocated';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="ps-3 fw-semibold text-muted">#${step.step}</td>
      <td><strong>${esc(step.pid)}</strong></td>
      <td>${step.size} KB</td>
      <td>
        <span class="badge ${isAlloc ? 'bg-success' : 'bg-danger'}">${step.status}</span>
      </td>
      <td class="small">${esc(step.reason || step.action)}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderMemMetricCards(m) {
  document.getElementById('memMetricCards').innerHTML = `
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-success">${m.allocated_processes_count} / ${m.allocated_processes_count + m.unallocated_processes_count}</div>
        <div class="small text-muted">Allocated Processes</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold ${m.unallocated_processes_count > 0 ? 'text-danger' : 'text-secondary'}">${m.unallocated_processes_count}</div>
        <div class="small text-muted">Unallocated Processes</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-warning">${m.total_internal_fragmentation} KB</div>
        <div class="small text-muted">Total Internal Frag.</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-info">${m.utilization_percentage}%</div>
        <div class="small text-muted">Memory Utilisation</div>
      </div>
    </div>
    <div class="col-12">
      <div class="card border-0 bg-light shadow-sm">
        <div class="card-body py-2 small text-muted d-flex justify-content-between flex-wrap gap-2">
          <span><strong>Total Memory:</strong> ${m.total_memory} KB</span>
          <span><strong>Allocated:</strong> ${m.allocated_memory} KB</span>
          <span><strong>Free Capacity in Empty Blocks:</strong> ${m.free_blocks_memory} KB (${m.free_blocks_count} blocks)</span>
          ${m.unallocated_pids.length > 0 ? `<span class="text-danger"><strong>Unallocated:</strong> ${m.unallocated_pids.join(', ')}</span>` : '<span class="text-success"><strong>All processes allocated</strong></span>'}
        </div>
      </div>
    </div>
  `;
}

function renderMemoryDiagram(blocks) {
  const container = document.getElementById('memoryBlocksDiagram');
  container.innerHTML = '';

  blocks.forEach(b => {
    const isAllocated = b.allocated_process !== null;
    const allocatedPct = isAllocated ? Math.round((b.allocated_size / b.total_size) * 100) : 0;
    const fragPct = isAllocated ? (100 - allocatedPct) : 0;

    const blockDiv = document.createElement('div');
    blockDiv.className = 'border rounded p-2 bg-white';
    blockDiv.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-1 small">
        <div>
          <strong class="text-dark">${esc(b.id)}</strong>
          <span class="badge bg-secondary ms-1">${b.total_size} KB</span>
        </div>
        <div>
          ${isAllocated ? `<span class="badge bg-primary">Process ${esc(b.allocated_process)} (${b.allocated_size} KB)</span>` : '<span class="badge bg-light text-dark border">FREE</span>'}
          ${isAllocated && b.fragmentation > 0 ? `<span class="badge bg-warning text-dark ms-1">Frag: ${b.fragmentation} KB</span>` : ''}
        </div>
      </div>
      <div class="progress" style="height: 24px;">
        ${isAllocated ? `
          <div class="progress-bar bg-primary" role="progressbar" style="width: ${allocatedPct}%; font-size: 0.78rem;" title="${esc(b.allocated_process)}: ${b.allocated_size} KB">
            ${allocatedPct >= 15 ? `${esc(b.allocated_process)} (${b.allocated_size} KB)` : `${esc(b.allocated_process)}`}
          </div>
          ${b.fragmentation > 0 ? `
            <div class="progress-bar bg-warning text-dark fw-semibold" role="progressbar" style="width: ${fragPct}%; font-size: 0.75rem;" title="Internal Fragmentation: ${b.fragmentation} KB">
              ${fragPct >= 18 ? `Frag: ${b.fragmentation} KB` : ''}
            </div>
          ` : ''}
        ` : `
          <div class="progress-bar bg-light text-muted border-0 w-100 text-center" role="progressbar" style="font-size: 0.78rem;">
            Empty (${b.total_size} KB)
          </div>
        `}
      </div>
    `;
    container.appendChild(blockDiv);
  });
}

function renderAllocationsTable(allocations) {
  const tbody = document.getElementById('allocResultsBody');
  tbody.innerHTML = allocations.map(a => `
    <tr>
      <td class="ps-3 fw-semibold">${esc(a.pid)}</td>
      <td>${a.process_size} KB</td>
      <td>
        ${a.allocated ? '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Allocated</span>' : '<span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Unallocated</span>'}
      </td>
      <td>${a.allocated ? `<strong class="text-primary">${esc(a.block_id)}</strong>` : '<span class="text-muted">&mdash;</span>'}</td>
      <td>${a.allocated ? `${a.block_size} KB` : '<span class="text-muted">&mdash;</span>'}</td>
      <td>
        ${a.allocated ? (a.fragmentation > 0 ? `<span class="text-warning fw-semibold">${a.fragmentation} KB</span>` : '<span class="text-muted">0 KB (Exact fit)</span>') : '<span class="text-muted">&mdash;</span>'}
      </td>
    </tr>
  `).join('');
}

function esc(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
