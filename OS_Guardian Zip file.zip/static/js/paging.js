/**
 * static/js/paging.js
 * ====================
 * Client-side controller for Page Replacement module:
 *  - Presets for textbook scenarios
 *  - API submission to /paging/run
 *  - Rendering metric summary cards
 *  - Rendering step-by-step frame matrix table
 */

'use strict';

let lastPagingRun = null;

document.addEventListener('DOMContentLoaded', () => {
  const runBtn = document.getElementById('runPagingBtn');
  runBtn.addEventListener('click', runPagingSimulation);

  if (new URLSearchParams(window.location.search).has('autorun')) {
    setTimeout(runPagingSimulation, 200);
  }

  const btnSave = document.getElementById('btnSavePagingHistory');
  if (btnSave) {
    btnSave.addEventListener('click', async () => {
      if (!lastPagingRun) {
        alert('Please run a page replacement simulation before saving to history.');
        return;
      }
      try {
        const algoNames = {
          fifo: 'FIFO',
          lru: 'LRU',
          optimal: 'Optimal (OPT)',
        };
        const algoName = algoNames[lastPagingRun.algorithm] || lastPagingRun.algorithm;
        const resData = lastPagingRun.data || {};
        const resp = await fetch('/history/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            module_type: 'paging',
            algorithm: algoName,
            parameters: {
              algorithm: lastPagingRun.algorithm,
              num_frames: lastPagingRun.num_frames,
              pages: lastPagingRun.pagesRaw
            },
            results: resData,
            summary_metrics: {
              hits: resData.hits ?? resData.page_hits ?? 0,
              faults: resData.faults ?? resData.page_faults ?? 0,
              hit_ratio: resData.hit_ratio ?? 0,
              fault_ratio: resData.fault_ratio ?? 0
            },
            summary_text: `${algoName} with ${lastPagingRun.num_frames} frames (Faults: ${resData.faults ?? resData.page_faults ?? 0}, Hits: ${resData.hits ?? resData.page_hits ?? 0})`
          })
        });
        const res = await resp.json();
        if (resp.ok) {
          alert('Paging simulation saved to History! (ID: #' + res.id + ')');
        } else {
          alert(res.error || 'Failed to save to history');
        }
      } catch (err) {
        alert('Error saving history: ' + err.message);
      }
    });
  }
});

const PAGING_PRESETS = {
  textbook: {
    // Classic 20-ref Silberschatz reference string
    pages: '7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1',
    frames: 3,
  },
  belady: {
    // String demonstrating Belady's Anomaly under FIFO (1,2,3,4,1,2,5,1,2,3,4,5)
    pages: '1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5',
    frames: 3,
  },
  simple: {
    pages: '1, 3, 0, 3, 5, 6, 3, 2',
    frames: 3,
  },
};

function loadPagingPreset(key) {
  const preset = PAGING_PRESETS[key] || PAGING_PRESETS.textbook;
  document.getElementById('pageRefInput').value = preset.pages;
  document.getElementById('framesCountInput').value = preset.frames;
}

async function runPagingSimulation() {
  const errDiv = document.getElementById('pagingError');
  const runBtn = document.getElementById('runPagingBtn');
  errDiv.classList.add('d-none');

  const algorithm = document.getElementById('pagingAlgoSelect').value;
  const num_frames = parseInt(document.getElementById('framesCountInput').value, 10);
  const pagesRaw = document.getElementById('pageRefInput').value.trim();

  if (!pagesRaw) {
    showPagingError('Provide at least one page reference.');
    return;
  }
  if (isNaN(num_frames) || num_frames <= 0) {
    showPagingError('Number of frames must be a positive integer.');
    return;
  }

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Simulating...';

  try {
    const resp = await fetch('/paging/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ algorithm, num_frames, pages: pagesRaw }),
    });

    const data = await resp.json();
    if (!resp.ok) {
      showPagingError(data.error || 'Server error occurred during simulation.');
      return;
    }

    lastPagingRun = { algorithm, num_frames, pagesRaw, data };
    renderPagingResults(data);
  } catch (err) {
    showPagingError('Network error: ' + err.message);
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Run Page Replacement';
  }
}

function showPagingError(msg) {
  const errDiv = document.getElementById('pagingError');
  errDiv.textContent = msg;
  errDiv.classList.remove('d-none');
}

function renderPagingResults(data) {
  document.getElementById('pagingPlaceholder').classList.add('d-none');
  document.getElementById('pagingResultsPanel').classList.remove('d-none');

  const algoNames = {
    fifo: 'FIFO (First In First Out)',
    lru: 'LRU (Least Recently Used)',
    optimal: "Optimal (Belady's)",
  };
  document.getElementById('pagingAlgoLabel').textContent = algoNames[data.algorithm] || data.algorithm;

  renderPagingMetricCards(data);
  renderFramesMatrix(data);
}

function renderPagingMetricCards(d) {
  document.getElementById('pagingMetricCards').innerHTML = `
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-primary">${d.total_references}</div>
        <div class="small text-muted">Total References</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-danger">${d.page_faults}</div>
        <div class="small text-muted">Page Faults</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-success">${d.page_hits}</div>
        <div class="small text-muted">Page Hits</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-info">${d.fault_ratio}%</div>
        <div class="small text-muted">Fault Ratio</div>
        <div class="text-muted" style="font-size: .65rem;">Hit Ratio: ${d.hit_ratio}%</div>
      </div>
    </div>
  `;
}

function renderFramesMatrix(data) {
  const head = document.getElementById('framesMatrixHead');
  const body = document.getElementById('framesMatrixBody');
  const numFrames = data.num_frames;
  const steps = data.steps;

  // Header row 1: Reference page numbers
  let hHtml = `
    <tr>
      <th style="min-width: 110px;" class="bg-light text-start ps-3">Reference</th>
  `;
  steps.forEach(s => {
    hHtml += `<th style="min-width: 44px;" class="fw-bold fs-6">${esc(s.page)}</th>`;
  });
  hHtml += `</tr>`;
  head.innerHTML = hHtml;

  // Body rows: Frame 1 to Frame N
  let bHtml = '';
  for (let fIdx = 0; fIdx < numFrames; fIdx++) {
    bHtml += `<tr>`;
    bHtml += `<td class="text-start ps-3 fw-semibold bg-light text-muted">Frame ${fIdx + 1}</td>`;
    steps.forEach(s => {
      const pageInFrame = s.frames[fIdx];
      if (pageInFrame !== null && pageInFrame !== undefined) {
        // Highlight cell if this frame was updated in this step
        const isCurrentPage = pageInFrame === s.page;
        const cellClass = isCurrentPage ? (s.hit ? 'bg-success bg-opacity-25 fw-bold text-success' : 'bg-primary bg-opacity-10 fw-bold text-primary') : '';
        bHtml += `<td class="${cellClass}">${esc(pageInFrame)}</td>`;
      } else {
        bHtml += `<td class="text-muted opacity-25">&mdash;</td>`;
      }
    });
    bHtml += `</tr>`;
  }

  // Status row: HIT or FAULT
  bHtml += `<tr class="border-top border-2">`;
  bHtml += `<td class="text-start ps-3 fw-semibold bg-light">Status</td>`;
  steps.forEach(s => {
    if (s.hit) {
      bHtml += `<td class="bg-success text-white fw-bold small">HIT</td>`;
    } else {
      bHtml += `<td class="bg-danger text-white fw-bold small">FAULT</td>`;
    }
  });
  bHtml += `</tr>`;

  // Replaced row: evicted page if any
  bHtml += `<tr>`;
  bHtml += `<td class="text-start ps-3 fw-semibold bg-light small text-muted">Victim Evicted</td>`;
  steps.forEach(s => {
    if (s.replaced !== null && s.replaced !== undefined) {
      bHtml += `<td class="text-danger small fw-semibold">${esc(s.replaced)}</td>`;
    } else {
      bHtml += `<td class="text-muted small">&mdash;</td>`;
    }
  });
  bHtml += `</tr>`;

  body.innerHTML = bHtml;
}

function esc(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
