/**
 * static/js/synchronization.js
 * =============================
 * Client controller for Thread Synchronization module:
 *  - Producer–Consumer simulation with bounded buffer
 *  - Reader–Writer simulation with mutual exclusion verification
 *  - Event log tables & visual state indicators
 *  - History persistence via POST /history/save
 */

'use strict';

let lastPCResult = null;
let lastRWResult = null;

document.addEventListener('DOMContentLoaded', () => {
  const runPCBtn = document.getElementById('runPCBtn');
  const runRWBtn = document.getElementById('runRWBtn');
  const savePCBtn = document.getElementById('savePCHistoryBtn');
  const saveRWBtn = document.getElementById('saveRWHistoryBtn');

  runPCBtn.addEventListener('click', runPCSimulation);
  runRWBtn.addEventListener('click', runRWSimulation);
  savePCBtn.addEventListener('click', savePCToHistory);
  saveRWBtn.addEventListener('click', saveRWToHistory);

  if (new URLSearchParams(window.location.search).has('autorun')) {
    setTimeout(runPCSimulation, 200);
  }
});

// ─────────────────────────────────────────────
//  Producer–Consumer
// ─────────────────────────────────────────────

function loadPCPreset(capacity, items) {
  document.getElementById('bufferCapacityInput').value = capacity;
  document.getElementById('numItemsInput').value = items;
}

async function runPCSimulation() {
  const errDiv = document.getElementById('pcError');
  const runBtn = document.getElementById('runPCBtn');
  errDiv.classList.add('d-none');

  const capacity = parseInt(document.getElementById('bufferCapacityInput').value, 10);
  const items = parseInt(document.getElementById('numItemsInput').value, 10);

  if (isNaN(capacity) || capacity <= 0 || isNaN(items) || items <= 0) {
    errDiv.textContent = 'Please enter valid positive integers for capacity and items.';
    errDiv.classList.remove('d-none');
    return;
  }

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Running...';

  try {
    const resp = await fetch('/synchronization/producer-consumer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ buffer_capacity: capacity, num_items: items, delay: 0.002 }),
    });

    const data = await resp.json();
    if (!resp.ok) {
      errDiv.textContent = data.error || 'Execution error';
      errDiv.classList.remove('d-none');
      return;
    }

    lastPCResult = data;
    renderPCResults(data);
    document.getElementById('savePCHistoryBtn').disabled = false;
  } catch (err) {
    errDiv.textContent = `Network error: ${err.message}`;
    errDiv.classList.remove('d-none');
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Start Simulation';
  }
}

function renderPCResults(data) {
  document.getElementById('pcPlaceholder').classList.add('d-none');
  document.getElementById('pcResults').classList.remove('d-none');

  document.getElementById('pcProducedCount').textContent = data.items_produced;
  document.getElementById('pcConsumedCount').textContent = data.items_consumed;
  document.getElementById('pcPeakOccupancy').textContent = `${data.peak_buffer_occupancy} / ${data.buffer_capacity}`;
  document.getElementById('pcWaitsCount').textContent = `${data.buffer_full_events} / ${data.buffer_empty_events}`;

  // Buffer slots visualization
  const slotsDiv = document.getElementById('pcBufferSlots');
  slotsDiv.innerHTML = '';
  for (let s = 0; s < data.buffer_capacity; s++) {
    const slotEl = document.createElement('div');
    const isOccupied = s < data.final_buffer.length;
    slotEl.className = `p-3 rounded text-center border ${isOccupied ? 'bg-primary text-white' : 'bg-light text-muted'}`;
    slotEl.style.width = '70px';
    slotEl.style.height = '65px';
    slotEl.innerHTML = `
      <div style="font-size: 0.7rem;">Slot ${s + 1}</div>
      <div class="fw-bold fs-6">${isOccupied ? '#' + data.final_buffer[s] : 'EMPTY'}</div>
    `;
    slotsDiv.appendChild(slotEl);
  }

  // Event log table
  const tbody = document.getElementById('pcLogBody');
  tbody.innerHTML = '';
  data.event_log.forEach(ev => {
    const tr = document.createElement('tr');
    let actionBadge = '';
    if (ev.action === 'PRODUCED') actionBadge = '<span class="badge bg-success">PRODUCED</span>';
    else if (ev.action === 'CONSUMED') actionBadge = '<span class="badge bg-primary">CONSUMED</span>';
    else if (ev.action === 'BUFFER_FULL_WAIT') actionBadge = '<span class="badge bg-danger">FULL WAIT</span>';
    else actionBadge = '<span class="badge bg-secondary">EMPTY WAIT</span>';

    tr.innerHTML = `
      <td class="fw-bold">${ev.seq}</td>
      <td>${ev.timestamp_ms}</td>
      <td><span class="badge bg-dark">${ev.thread}</span></td>
      <td>${actionBadge}</td>
      <td>${ev.item ? '#' + ev.item : '—'}</td>
      <td><code>[${ev.buffer_state.join(', ')}]</code> (${ev.occupancy}/${ev.capacity})</td>
      <td class="text-start small text-muted">${ev.note}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function savePCToHistory() {
  if (!lastPCResult) return;
  const saveBtn = document.getElementById('savePCHistoryBtn');
  saveBtn.disabled = true;

  try {
    const resp = await fetch('/history/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        module_type: 'synchronization',
        algorithm: 'Producer-Consumer',
        parameters: {
          buffer_capacity: lastPCResult.buffer_capacity,
          total_items: lastPCResult.total_items,
        },
        results: {
          items_produced: lastPCResult.items_produced,
          items_consumed: lastPCResult.items_consumed,
          peak_occupancy: lastPCResult.peak_buffer_occupancy,
          events_count: lastPCResult.event_log.length,
        },
        summary_metrics: {
          produced: lastPCResult.items_produced,
          consumed: lastPCResult.items_consumed,
          capacity: lastPCResult.buffer_capacity,
        },
        summary_text: `Producer-Consumer (Cap=${lastPCResult.buffer_capacity}, Items=${lastPCResult.total_items})`,
      }),
    });
    const res = await resp.json();
    if (resp.ok) {
      saveBtn.className = 'btn btn-success';
      saveBtn.innerHTML = '<i class="bi bi-check-lg me-1"></i>Saved!';
      alert('Producer-Consumer simulation saved to History! (ID: #' + res.id + ')');
      setTimeout(() => {
        saveBtn.className = 'btn btn-outline-secondary';
        saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
        saveBtn.disabled = false;
      }, 2500);
    } else {
      alert(res.error || 'Failed to save to history');
      saveBtn.disabled = false;
      saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
    }
  } catch (err) {
    saveBtn.disabled = false;
  }
}

// ─────────────────────────────────────────────
//  Reader–Writer
// ─────────────────────────────────────────────

function loadRWPreset(readers, writers, ops) {
  document.getElementById('numReadersInput').value = readers;
  document.getElementById('numWritersInput').value = writers;
  document.getElementById('rwOpsInput').value = ops;
}

async function runRWSimulation() {
  const errDiv = document.getElementById('rwError');
  const runBtn = document.getElementById('runRWBtn');
  errDiv.classList.add('d-none');

  const readers = parseInt(document.getElementById('numReadersInput').value, 10);
  const writers = parseInt(document.getElementById('numWritersInput').value, 10);
  const ops = parseInt(document.getElementById('rwOpsInput').value, 10);

  if (isNaN(readers) || readers <= 0 || isNaN(writers) || writers <= 0 || isNaN(ops) || ops <= 0) {
    errDiv.textContent = 'Please enter valid positive thread counts and operation limits.';
    errDiv.classList.remove('d-none');
    return;
  }

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Running...';

  try {
    const resp = await fetch('/synchronization/reader-writer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        num_readers: readers,
        num_writers: writers,
        operations_per_thread: ops,
        delay: 0.002,
      }),
    });

    const data = await resp.json();
    if (!resp.ok) {
      errDiv.textContent = data.error || 'Execution error';
      errDiv.classList.remove('d-none');
      return;
    }

    lastRWResult = data;
    renderRWResults(data);
    document.getElementById('saveRWHistoryBtn').disabled = false;
  } catch (err) {
    errDiv.textContent = `Network error: ${err.message}`;
    errDiv.classList.remove('d-none');
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Start Simulation';
  }
}

function renderRWResults(data) {
  document.getElementById('rwPlaceholder').classList.add('d-none');
  document.getElementById('rwResults').classList.remove('d-none');

  document.getElementById('rwReadsCount').textContent = data.reads_completed;
  document.getElementById('rwWritesCount').textContent = data.writes_completed;
  document.getElementById('rwPeakReaders').textContent = data.peak_concurrent_readers;
  document.getElementById('rwMutexStatus').textContent = data.mutual_exclusion_verified ? 'PASS' : 'FAIL';
  document.getElementById('rwFinalDataVal').textContent = data.shared_data_value;

  const safetyBadge = document.getElementById('rwSafetyBadge');
  safetyBadge.className = data.mutual_exclusion_verified ? 'badge bg-success' : 'badge bg-danger';
  safetyBadge.textContent = `${data.violations} Violations Detected`;

  // Event log table
  const tbody = document.getElementById('rwLogBody');
  tbody.innerHTML = '';
  data.event_log.forEach(ev => {
    const tr = document.createElement('tr');
    let actionBadge = '';
    if (ev.action === 'START_READ') actionBadge = '<span class="badge bg-info">START READ</span>';
    else if (ev.action === 'FINISH_READ') actionBadge = '<span class="badge bg-secondary">FINISH READ</span>';
    else if (ev.action === 'START_WRITE') actionBadge = '<span class="badge bg-danger">START WRITE</span>';
    else if (ev.action === 'FINISH_WRITE') actionBadge = '<span class="badge bg-dark">FINISH WRITE</span>';
    else actionBadge = '<span class="badge bg-warning text-dark">WAIT ENTRY</span>';

    const roleBadge = ev.role === 'Reader' ? '<span class="badge bg-info-subtle text-info">Reader</span>' : '<span class="badge bg-danger-subtle text-danger">Writer</span>';

    tr.innerHTML = `
      <td class="fw-bold">${ev.seq}</td>
      <td>${ev.timestamp_ms}</td>
      <td><span class="badge bg-dark">${ev.thread}</span></td>
      <td>${roleBadge}</td>
      <td>${actionBadge}</td>
      <td><code>R:${ev.active_readers} | W:${ev.active_writers}</code></td>
      <td><span class="badge bg-light text-dark border">${ev.shared_value}</span></td>
      <td class="text-start small text-muted">${ev.note}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function saveRWToHistory() {
  if (!lastRWResult) return;
  const saveBtn = document.getElementById('saveRWHistoryBtn');
  saveBtn.disabled = true;

  try {
    const resp = await fetch('/history/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        module_type: 'synchronization',
        algorithm: 'Reader-Writer',
        parameters: {
          num_readers: lastRWResult.num_readers,
          num_writers: lastRWResult.num_writers,
          ops_per_thread: lastRWResult.operations_per_thread,
        },
        results: {
          reads_completed: lastRWResult.reads_completed,
          writes_completed: lastRWResult.writes_completed,
          peak_concurrent_readers: lastRWResult.peak_concurrent_readers,
          shared_data_value: lastRWResult.shared_data_value,
        },
        summary_metrics: {
          reads: lastRWResult.reads_completed,
          writes: lastRWResult.writes_completed,
          peak_readers: lastRWResult.peak_concurrent_readers,
        },
        summary_text: `Reader-Writer (${lastRWResult.num_readers}R, ${lastRWResult.num_writers}W, Val=${lastRWResult.shared_data_value})`,
      }),
    });
    const res = await resp.json();
    if (resp.ok) {
      saveBtn.className = 'btn btn-success';
      saveBtn.innerHTML = '<i class="bi bi-check-lg me-1"></i>Saved!';
      alert('Reader-Writer simulation saved to History! (ID: #' + res.id + ')');
      setTimeout(() => {
        saveBtn.className = 'btn btn-outline-secondary';
        saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
        saveBtn.disabled = false;
      }, 2500);
    } else {
      alert(res.error || 'Failed to save to history');
      saveBtn.disabled = false;
      saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
    }
  } catch (err) {
    saveBtn.disabled = false;
  }
}
