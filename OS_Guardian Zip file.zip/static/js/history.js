/**
 * OS Guardian - History Controller
 * Loads, filters, previews, and deletes simulation runs from SQLite.
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('[OS Guardian History] Initializing history controller...');

  const tbody = document.getElementById('history-tbody');
  const emptyState = document.getElementById('history-empty');
  const btnRefresh = document.getElementById('btn-refresh-history');
  const btnClear = document.getElementById('btn-clear-history');
  const filterButtons = document.querySelectorAll('.filter-btn');
  const detailsModalEl = document.getElementById('detailsModal');

  let detailsModal = null;
  function getModal() {
    if (!detailsModal && window.bootstrap && detailsModalEl) {
      try {
        detailsModal = new bootstrap.Modal(detailsModalEl);
      } catch (e) {
        console.warn('[OS Guardian History] Could not instantiate bootstrap.Modal:', e);
      }
    }
    return detailsModal;
  }

  let currentFilter = 'all';

  const MODULE_META = {
    scheduling: { label: 'CPU Scheduling', badge: 'bg-primary' },
    cpu_scheduling: { label: 'CPU Scheduling', badge: 'bg-primary' },
    memory: { label: 'Memory Allocation', badge: 'bg-success' },
    paging: { label: 'Page Replacement', badge: 'bg-info text-dark' },
    deadlock: { label: 'Deadlock Management', badge: 'bg-danger' },
    synchronization: { label: 'Synchronization', badge: 'bg-warning text-dark' },
    sync: { label: 'Synchronization', badge: 'bg-warning text-dark' },
    comparison: { label: 'Comparison', badge: 'bg-dark' },
    system_monitor: { label: 'System Monitor', badge: 'bg-secondary' }
  };

  async function loadHistory() {
    try {
      console.log('[OS Guardian History] Requesting /history/records...');
      const resp = await fetch('/history/records');
      const data = await resp.json();

      console.log('[OS Guardian History] Response received:', data);

      if (!resp.ok) {
        console.error('[OS Guardian History] Error response from backend:', data);
        alert(data.error || 'Failed to fetch history');
        return;
      }

      const allRecords = data.records || [];
      console.log(`[OS Guardian History] Total records returned: ${allRecords.length}`);

      updateCounts(allRecords, data.counts);

      let filteredRecords = allRecords;
      if (currentFilter !== 'all') {
        filteredRecords = allRecords.filter(r => {
          const mod = (r.module_type || r.module || '').toLowerCase().trim();
          if (currentFilter === 'scheduling') {
            return mod === 'scheduling' || mod === 'cpu_scheduling';
          }
          if (currentFilter === 'synchronization') {
            return mod === 'synchronization' || mod === 'sync';
          }
          return mod === currentFilter;
        });
      }

      renderTable(filteredRecords);
    } catch (err) {
      console.error('[OS Guardian History] Network or script error loading history:', err);
    }
  }

  function updateCounts(records, backendCounts) {
    const counts = {
      all: records.length,
      scheduling: 0,
      memory: 0,
      paging: 0,
      deadlock: 0,
      synchronization: 0,
      comparison: 0,
      system_monitor: 0
    };

    records.forEach(r => {
      const raw = (r.module_type || r.module || '').toLowerCase().trim();
      if (raw === 'scheduling' || raw === 'cpu_scheduling') {
        counts.scheduling++;
      } else if (raw === 'synchronization' || raw === 'sync') {
        counts.synchronization++;
      } else if (counts[raw] !== undefined) {
        counts[raw]++;
      }
    });

    if (backendCounts) {
      if (backendCounts.total !== undefined) counts.all = backendCounts.total;
      if (backendCounts.scheduling !== undefined) counts.scheduling = backendCounts.scheduling;
      if (backendCounts.memory !== undefined) counts.memory = backendCounts.memory;
      if (backendCounts.paging !== undefined) counts.paging = backendCounts.paging;
      if (backendCounts.deadlock !== undefined) counts.deadlock = backendCounts.deadlock;
      if (backendCounts.synchronization !== undefined) counts.synchronization = backendCounts.synchronization;
      if (backendCounts.comparison !== undefined) counts.comparison = backendCounts.comparison;
      if (backendCounts.system_monitor !== undefined) counts.system_monitor = backendCounts.system_monitor;
    }

    const setBadge = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setBadge('count-all', counts.all);
    setBadge('count-scheduling', counts.scheduling);
    setBadge('count-memory', counts.memory);
    setBadge('count-paging', counts.paging);
    setBadge('count-deadlock', counts.deadlock);
    setBadge('count-synchronization', counts.synchronization);
    setBadge('count-comparison', counts.comparison);
    setBadge('count-system_monitor', counts.system_monitor);
  }

  function formatSummary(record) {
    if (record.summary_text && String(record.summary_text).trim()) {
      return record.summary_text;
    }

    const sm = record.summary_metrics || {};
    const res = record.results || {};
    const mod = (record.module_type || record.module || '').toLowerCase().trim();

    try {
      if (mod === 'scheduling' || mod === 'cpu_scheduling') {
        const wt = sm.avg_waiting ?? res.metrics?.avg_waiting ?? '-';
        const tat = sm.avg_turnaround ?? res.metrics?.avg_turnaround ?? '-';
        const util = sm.cpu_utilization ?? res.metrics?.cpu_utilization ?? '-';
        return `Avg Wait: ${wt} ms | Avg TAT: ${tat} ms | Util: ${util}%`;
      }
      if (mod === 'memory') {
        const alloc = sm.allocated_processes_count ?? res.summary?.allocated_processes_count ?? '-';
        const unalloc = sm.unallocated_processes_count ?? res.summary?.unallocated_processes_count ?? '-';
        const util = sm.utilization_percentage ?? res.summary?.utilization_percentage ?? '-';
        return `Allocated: ${alloc} | Unallocated: ${unalloc} | Util: ${util}%`;
      }
      if (mod === 'paging') {
        const hits = sm.hits ?? sm.page_hits ?? res.page_hits ?? 0;
        const faults = sm.faults ?? sm.page_faults ?? res.page_faults ?? 0;
        return `Page Hits: ${hits} | Page Faults: ${faults}`;
      }
      if (mod === 'deadlock') {
        if (res.is_safe !== undefined) {
          return res.is_safe
            ? `SAFE State (${(res.safe_sequence || []).join(' → ')})`
            : 'UNSAFE State (Deadlock risk)';
        }
      }
      if (mod === 'synchronization') {
        if (sm.produced !== undefined && sm.consumed !== undefined) {
          return `Produced: ${sm.produced} | Consumed: ${sm.consumed}`;
        }
        if (sm.reads !== undefined && sm.writes !== undefined) {
          return `Reads: ${sm.reads} | Writes: ${sm.writes} | Peak Readers: ${sm.peak_readers}`;
        }
      }
      if (mod === 'comparison') {
        if (sm.min_waiting_time) return `Lowest wait time: ${sm.min_waiting_time}`;
        if (sm.most_allocated) return `Most allocated: ${sm.most_allocated}`;
        if (sm.lowest_page_faults) return `Lowest faults: ${sm.lowest_page_faults}`;
      }
      if (mod === 'system_monitor') {
        const cpu = sm.cpu_percent ?? res.cpu?.percent ?? sm.cpu ?? '-';
        const mem = sm.memory_percent ?? res.memory?.percent ?? sm.memory ?? '-';
        const procs = sm.process_count ?? res.process_count ?? sm.procs ?? '-';
        return `CPU: ${cpu}% | RAM: ${mem}% | Procs: ${procs}`;
      }
    } catch (e) {
      // Fallback
    }

    return JSON.stringify(sm || res).substring(0, 90) + '...';
  }

  function renderTable(records) {
    if (!tbody) return;
    tbody.innerHTML = '';
    if (records.length === 0) {
      if (emptyState) emptyState.style.display = 'block';
      return;
    }
    if (emptyState) emptyState.style.display = 'none';

    records.forEach(r => {
      const tr = document.createElement('tr');
      const rawMod = (r.module_type || r.module || '').toLowerCase().trim();
      const meta = MODULE_META[rawMod] || { label: r.module_type || r.module || 'Module', badge: 'bg-secondary' };
      const summaryText = formatSummary(r);

      tr.innerHTML = `
        <td class="fw-bold text-muted">#${r.id}</td>
        <td class="small text-secondary">${r.timestamp}</td>
        <td><span class="badge ${meta.badge}">${meta.label}</span></td>
        <td class="fw-semibold">${r.algorithm}</td>
        <td class="small text-truncate" style="max-width: 320px;" title="${escapeHtml(summaryText)}">
          ${escapeHtml(summaryText)}
        </td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1 btn-view-record" data-id="${r.id}" title="Inspect full details">
            <i class="bi bi-eye"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger btn-del-record" data-id="${r.id}" title="Delete record">
            <i class="bi bi-trash"></i>
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Filter pills
  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      filterButtons.forEach(b => {
        b.classList.remove('active', 'btn-dark');
        b.classList.add('btn-outline-secondary');
      });
      btn.classList.add('active', 'btn-dark');
      btn.classList.remove('btn-outline-secondary');

      currentFilter = btn.dataset.filter;
      loadHistory();
    });
  });

  // Table actions (view / delete)
  if (tbody) {
    tbody.addEventListener('click', async (e) => {
      const viewBtn = e.target.closest('.btn-view-record');
      if (viewBtn) {
        const id = viewBtn.dataset.id;
        try {
          const resp = await fetch(`/history/view/${id}`);
          const data = await resp.json();
          if (!resp.ok) {
            alert(data.error || 'Failed to fetch details');
            return;
          }
          const rec = data.record || data;
          const rawMod = (rec.module_type || rec.module || '').toLowerCase().trim();
          const meta = MODULE_META[rawMod] || { label: rec.module_type || rec.module };

          document.getElementById('modal-record-id').textContent = '#' + rec.id;
          document.getElementById('modal-module').textContent = meta.label || rec.module_type;
          document.getElementById('modal-algorithm').textContent = rec.algorithm;
          document.getElementById('modal-timestamp').textContent = rec.timestamp;
          document.getElementById('modal-inputs').textContent = JSON.stringify(rec.parameters || rec.inputs, null, 2);
          document.getElementById('modal-results').textContent = JSON.stringify(rec.results, null, 2);

          const modal = getModal();
          if (modal) {
            modal.show();
          }
        } catch (err) {
          alert('Error viewing record: ' + err.message);
        }
        return;
      }

      const delBtn = e.target.closest('.btn-del-record');
      if (delBtn) {
        const id = delBtn.dataset.id;
        if (confirm(`Are you sure you want to delete simulation record #${id}?`)) {
          try {
            const resp = await fetch(`/history/delete/${id}`, { method: 'POST' });
            const res = await resp.json();
            if (resp.ok) {
              loadHistory();
            } else {
              alert(res.error || 'Failed to delete record');
            }
          } catch (err) {
            alert('Error deleting record: ' + err.message);
          }
        }
      }
    });
  }

  // Refresh
  if (btnRefresh) {
    btnRefresh.addEventListener('click', loadHistory);
  }

  // Clear all
  if (btnClear) {
    btnClear.addEventListener('click', async () => {
      if (confirm('Are you sure you want to clear ALL simulation records from SQLite? This cannot be undone.')) {
        try {
          const resp = await fetch('/history/clear', { method: 'POST' });
          const res = await resp.json();
          if (resp.ok) {
            loadHistory();
          } else {
            alert(res.error || 'Failed to clear history');
          }
        } catch (err) {
          alert('Error clearing history: ' + err.message);
        }
      }
    });
  }

  // Initial load
  loadHistory();
});
