/**
 * OS Guardian - System Monitor & Deadlock Detection Controller
 * Manages live Windows telemetry via psutil and formal deadlock detection analysis.
 */

document.addEventListener('DOMContentLoaded', () => {
  let cachedSnapshot = null;
  let cachedAnalysis = null;

  // -------------------------------------------------------------------------
  // 1. LIVE TELEMETRY LOGIC
  // -------------------------------------------------------------------------
  const statCpu = document.getElementById('stat-cpu');
  const statCores = document.getElementById('stat-cores');
  const statRam = document.getElementById('stat-ram');
  const statRamMb = document.getElementById('stat-ram-mb');
  const statSwap = document.getElementById('stat-swap');
  const statSwapMb = document.getElementById('stat-swap-mb');
  const statProcs = document.getElementById('stat-procs');
  const procTbody = document.getElementById('processes-tbody');
  const procSearch = document.getElementById('proc-search-input');
  const btnRefresh = document.getElementById('btn-refresh-telemetry');
  const btnSaveSnapshot = document.getElementById('btn-save-snapshot');
  const timestampEl = document.getElementById('snapshot-timestamp');

  async function fetchTelemetry() {
    btnRefresh.disabled = true;
    btnRefresh.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Sampling...';

    try {
      const resp = await fetch('/system-monitor/snapshot');
      const data = await resp.json();

      if (!resp.ok) {
        alert(data.error || 'Failed to fetch host telemetry');
        return;
      }

      cachedSnapshot = data;
      renderTelemetry(data);
    } catch (err) {
      console.error('Telemetry fetch error:', err);
      procTbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Failed to read host telemetry: ${err.message}</td></tr>`;
    } finally {
      btnRefresh.disabled = false;
      btnRefresh.innerHTML = '<i class="bi bi-arrow-clockwise me-1"></i>Refresh';
    }
  }

  function renderTelemetry(data) {
    const cpu = data.cpu || {};
    const mem = data.memory || {};
    const swap = data.swap || {};

    statCpu.textContent = `${Number(cpu.percent || 0).toFixed(1)}%`;
    statCores.textContent = `${cpu.logical_cores || 1} Logical (${cpu.physical_cores || 1} Phys) Cores`;

    statRam.textContent = `${Number(mem.percent || 0).toFixed(1)}%`;
    statRamMb.textContent = `${Math.round(mem.used_mb || 0)} / ${Math.round(mem.total_mb || 0)} MB`;

    statSwap.textContent = `${Number(swap.percent || 0).toFixed(1)}%`;
    statSwapMb.textContent = `${Math.round(swap.used_mb || 0)} / ${Math.round(swap.total_mb || 0)} MB`;

    statProcs.textContent = data.process_count || 0;
    timestampEl.textContent = `Updated: ${data.timestamp || 'Just now'}`;

    renderProcessTable(data.processes || []);
  }

  function renderProcessTable(procs) {
    procTbody.innerHTML = '';
    const query = (procSearch.value || '').toLowerCase().trim();

    const filtered = procs.filter(p => {
      if (!query) return true;
      const pidStr = String(p.pid);
      const nameStr = String(p.name || '').toLowerCase();
      const userStr = String(p.username || '').toLowerCase();
      return pidStr.includes(query) || nameStr.includes(query) || userStr.includes(query);
    });

    if (filtered.length === 0) {
      procTbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No processes match your filter query.</td></tr>';
      return;
    }

    filtered.forEach(p => {
      const tr = document.createElement('tr');
      const isHighCpu = (p.cpu_percent || 0) > 10.0;
      const isHighMem = (p.memory_percent || 0) > 5.0;

      tr.innerHTML = `
        <td class="ps-3 fw-bold text-muted">${p.pid}</td>
        <td class="fw-semibold text-dark">${escapeHtml(p.name)}</td>
        <td><span class="badge bg-light text-dark border">${escapeHtml(p.status)}</span></td>
        <td class="text-end fw-semibold ${isHighCpu ? 'text-danger' : ''}">${Number(p.cpu_percent).toFixed(1)}%</td>
        <td class="text-end">${Number(p.memory_mb).toFixed(1)} MB</td>
        <td class="text-end ${isHighMem ? 'text-warning fw-bold' : ''}">${Number(p.memory_percent).toFixed(1)}%</td>
        <td class="pe-3 small text-secondary text-truncate" style="max-width: 160px;" title="${escapeHtml(p.username)}">${escapeHtml(p.username)}</td>
      `;
      procTbody.appendChild(tr);
    });
  }

  procSearch.addEventListener('input', () => {
    if (cachedSnapshot && cachedSnapshot.processes) {
      renderProcessTable(cachedSnapshot.processes);
    }
  });

  btnRefresh.addEventListener('click', fetchTelemetry);

  btnSaveSnapshot.addEventListener('click', async () => {
    if (!cachedSnapshot) {
      alert('No snapshot available to save.');
      return;
    }

    try {
      const cpu = cachedSnapshot.cpu || {};
      const mem = cachedSnapshot.memory || {};
      const procs = cachedSnapshot.process_count || 0;

      const resp = await fetch('/history/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module_type: 'system_monitor',
          algorithm: 'Windows Host Snapshot',
          parameters: {
            logical_cores: cpu.logical_cores,
            physical_cores: cpu.physical_cores,
            total_ram_mb: mem.total_mb,
            total_swap_mb: cachedSnapshot.swap?.total_mb
          },
          results: cachedSnapshot,
          summary_metrics: {
            cpu_percent: cpu.percent,
            memory_percent: mem.percent,
            process_count: procs
          },
          summary_text: `Host Snapshot: CPU ${cpu.percent}% | RAM ${mem.percent}% | ${procs} active tasks`
        })
      });

      const res = await resp.json();
      if (resp.ok) {
        alert(`Host snapshot successfully archived to SQLite history! (Record ID: #${res.id})`);
      } else {
        alert(res.error || 'Failed to save snapshot');
      }
    } catch (err) {
      alert('Error saving snapshot: ' + err.message);
    }
  });

  // -------------------------------------------------------------------------
  // 2. DEADLOCK DETECTION LOGIC
  // -------------------------------------------------------------------------
  const allocInput = document.getElementById('dd-alloc-input');
  const requestInput = document.getElementById('dd-request-input');
  const availInput = document.getElementById('dd-avail-input');
  const btnRunDeadlock = document.getElementById('btn-run-deadlock-detect');
  const btnPresetSafe = document.getElementById('btn-dd-preset-safe');
  const btnPresetDeadlock = document.getElementById('btn-dd-preset-deadlock');

  const ddResultsCard = document.getElementById('dd-results-card');
  const ddPlaceholder = document.getElementById('dd-placeholder');
  const ddResultTitle = document.getElementById('dd-result-title');
  const ddOutcomeAlert = document.getElementById('dd-outcome-alert');
  const ddTraceTbody = document.getElementById('dd-trace-tbody');

  btnPresetSafe.addEventListener('click', () => {
    allocInput.value = '0, 1, 0\n2, 0, 0\n3, 0, 3';
    requestInput.value = '0, 0, 0\n2, 0, 2\n0, 0, 0';
    availInput.value = '0, 0, 0';
  });

  btnPresetDeadlock.addEventListener('click', () => {
    allocInput.value = '1, 0\n0, 1';
    requestInput.value = '0, 1\n1, 0';
    availInput.value = '0, 0';
  });

  function parseMatrix(text) {
    return text
      .trim()
      .split('\n')
      .map(row =>
        row
          .split(/[\s,]+/)
          .map(s => parseInt(s.trim(), 10))
          .filter(n => !isNaN(n))
      )
      .filter(r => r.length > 0);
  }

  function parseVector(text) {
    return text
      .split(/[\s,]+/)
      .map(s => parseInt(s.trim(), 10))
      .filter(n => !isNaN(n));
  }

  btnRunDeadlock.addEventListener('click', async () => {
    const allocation = parseMatrix(allocInput.value);
    const request = parseMatrix(requestInput.value);
    const available = parseVector(availInput.value);

    if (allocation.length === 0 || request.length === 0 || available.length === 0) {
      alert('Please provide valid matrix and vector inputs.');
      return;
    }

    if (allocation.length !== request.length) {
      alert(`Allocation process count (${allocation.length}) must match Request process count (${request.length}).`);
      return;
    }

    btnRunDeadlock.disabled = true;
    btnRunDeadlock.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Analyzing graph...';

    try {
      const resp = await fetch('/system-monitor/deadlock-detect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allocation, request, available })
      });
      const data = await resp.json();

      if (!resp.ok) {
        alert(data.error || 'Deadlock detection failed');
        return;
      }

      cachedAnalysis = data;
      renderDeadlockResults(data);
    } catch (err) {
      alert('Network error while running deadlock detection: ' + err.message);
    } finally {
      btnRunDeadlock.disabled = false;
      btnRunDeadlock.innerHTML = '<i class="bi bi-search me-1"></i>Analyze for Deadlock';
    }
  });

  function renderDeadlockResults(data) {
    ddPlaceholder.style.display = 'none';
    ddResultsCard.style.display = 'block';

    const isDeadlocked = data.is_deadlocked;

    if (isDeadlocked) {
      ddResultTitle.innerHTML = '<i class="bi bi-x-circle-fill text-danger me-2"></i>Deadlock Detected!';
      ddOutcomeAlert.className = 'alert alert-danger py-2 px-3 mb-3 fw-semibold';
      ddOutcomeAlert.innerHTML = `
        <div class="d-flex align-items-center">
          <i class="bi bi-shield-x fs-4 me-2"></i>
          <div>
            <strong>Deadlocked Processes:</strong> ${data.deadlocked_processes.join(', ')}<br>
            <span class="small font-monospace">${data.summary}</span>
          </div>
        </div>
      `;
    } else {
      ddResultTitle.innerHTML = '<i class="bi bi-check-circle-fill text-success me-2"></i>System Safe — No Deadlock';
      ddOutcomeAlert.className = 'alert alert-success py-2 px-3 mb-3 fw-semibold';
      ddOutcomeAlert.innerHTML = `
        <div class="d-flex align-items-center">
          <i class="bi bi-shield-check fs-4 me-2"></i>
          <div>
            <strong>Safe Execution Sequence:</strong> ${data.safe_sequence.join(' &rarr; ')}<br>
            <span class="small">${data.summary}</span>
          </div>
        </div>
      `;
    }

    // Step trace table
    ddTraceTbody.innerHTML = '';
    const steps = data.step_trace || [];
    steps.forEach(s => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="fw-bold text-muted">${s.step}</td>
        <td><span class="badge bg-light text-dark border">${escapeHtml(s.action)}</span></td>
        <td class="text-start small">${escapeHtml(s.description)}</td>
        <td><code>[${(s.work || []).join(', ')}]</code></td>
      `;
      ddTraceTbody.appendChild(tr);
    });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Initial load on page view
  fetchTelemetry();
});
