/**
 * static/js/scheduling.js
 * ========================
 * Handles the CPU Scheduling page:
 *   - Dynamic process input table
 *   - POST to /scheduling/run
 *   - Renders Gantt chart via Chart.js (horizontal floating bar)
 *   - Renders metric summary cards and results table
 *
 * Root-cause fixes applied (bug report 2026-10-13):
 *
 *   BUG 1 – parsing:false broke floating-bar detection
 *     Chart.js 4 uses its parsing pipeline to detect the `x:[min,max]`
 *     floating-bar format.  When `parsing:false` is set, that step is
 *     bypassed and the bars are treated as zero-width → invisible.
 *     Fix: remove `parsing:false`.
 *
 *   BUG 2 – canvas height set AFTER chart creation
 *     With `maintainAspectRatio:false`, Chart.js reads the container's
 *     CSS dimensions at creation time.  Setting `style.height` on the
 *     <canvas> after `new Chart()` has no effect on the rendered size.
 *     Fix: set a fixed pixel height on the wrapper <div> via CSS class
 *     `gantt-wrapper` BEFORE the Chart constructor runs.
 *
 *   BUG 3 – y-axis missing type:'category' declaration
 *     With multiple single-point datasets that all share the same y-label
 *     ('CPU'), Chart.js 4 must be told the axis is a category axis;
 *     otherwise it may auto-detect 'linear' and discard string labels.
 *     Fix: add type:'category' to the y-scale definition.
 */

'use strict';

// ─────────────────────────────────────────────
//  State
// ─────────────────────────────────────────────
let processCount = 0;
let ganttChartInstance = null;
let lastSchedulingRun = null;

// Distinct colours for up to 16 processes + IDLE
const PROCESS_COLORS = [
  '#4e79a7','#f28e2b','#e15759','#76b7b2',
  '#59a14f','#edc948','#b07aa1','#ff9da7',
  '#9c755f','#bab0ac','#d4a6c8','#86bcb6',
  '#f1ce63','#a0cbe8','#ffbe7d','#8cd17d',
];
const IDLE_COLOR = '#dee2e6';

// ─────────────────────────────────────────────
//  Initialisation
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const algoSelect   = document.getElementById('algorithmSelect');
  const quantumGroup = document.getElementById('quantumGroup');
  const addRowBtn    = document.getElementById('addRowBtn');
  const runBtn       = document.getElementById('runBtn');

  // Show/hide quantum input and priority column on algo change
  algoSelect.addEventListener('change', () => {
    const algo = algoSelect.value;
    quantumGroup.classList.toggle('d-none', algo !== 'rr');
    document.getElementById('priorityHeader').classList.toggle('d-none', algo !== 'priority');
    document.querySelectorAll('.priority-cell').forEach(td =>
      td.classList.toggle('d-none', algo !== 'priority')
    );
  });

  addRowBtn.addEventListener('click', addProcessRow);
  runBtn.addEventListener('click', runSimulation);

  // Seed with default rows
  loadExample('basic');

  if (new URLSearchParams(window.location.search).has('autorun')) {
    setTimeout(runSimulation, 200);
  }

  const btnSave = document.getElementById('btnSaveSchedulingHistory');
  if (btnSave) {
    btnSave.addEventListener('click', async () => {
      if (!lastSchedulingRun) {
        alert('Please run a simulation before saving to history.');
        return;
      }
      try {
        const algoName = ALGO_LABELS[lastSchedulingRun.algo] || lastSchedulingRun.algo;
        const metrics = (lastSchedulingRun.data && lastSchedulingRun.data.metrics) ? lastSchedulingRun.data.metrics : {};
        const resp = await fetch('/history/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            module_type: 'scheduling',
            algorithm: algoName,
            parameters: {
              algorithm: lastSchedulingRun.algo,
              quantum: lastSchedulingRun.quantum,
              processes: lastSchedulingRun.processes
            },
            results: lastSchedulingRun.data,
            summary_metrics: metrics,
            summary_text: `${algoName} with ${lastSchedulingRun.processes.length} processes (Avg Wait: ${metrics.avg_waiting ?? '-'} ms, TAT: ${metrics.avg_turnaround ?? '-'} ms)`
          })
        });
        const res = await resp.json();
        if (resp.ok) {
          alert('CPU simulation saved to History! (ID: #' + res.id + ')');
        } else {
          alert(res.error || 'Failed to save to history');
        }
      } catch (err) {
        alert('Error saving history: ' + err.message);
      }
    });
  }
});

// ─────────────────────────────────────────────
//  Process table management
// ─────────────────────────────────────────────
function addProcessRow(pid, arrival, burst, priority) {
  processCount++;
  const isPriority  = document.getElementById('algorithmSelect').value === 'priority';
  const pidVal      = (typeof pid      === 'string') ? pid      : `P${processCount}`;
  const arrivalVal  = (typeof arrival  === 'number') ? arrival  : 0;
  const burstVal    = (typeof burst    === 'number') ? burst    : 1;
  const priorityVal = (typeof priority === 'number') ? priority : 1;

  const tbody = document.getElementById('processBody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text"   class="form-control form-control-sm pid-input"
               value="${escHtml(pidVal)}" maxlength="8" /></td>
    <td><input type="number" class="form-control form-control-sm arrival-input"
               value="${arrivalVal}" min="0" max="999" /></td>
    <td><input type="number" class="form-control form-control-sm burst-input"
               value="${burstVal}"   min="1" max="999" /></td>
    <td class="priority-cell ${isPriority ? '' : 'd-none'}">
      <input type="number" class="form-control form-control-sm priority-input"
             value="${priorityVal}" min="1" max="99" />
    </td>
    <td>
      <button class="btn btn-sm btn-outline-danger remove-btn" title="Remove">
        <i class="bi bi-trash3"></i>
      </button>
    </td>`;
  tr.querySelector('.remove-btn').addEventListener('click', () => tr.remove());
  tbody.appendChild(tr);
}

function getProcesses() {
  const rows = document.querySelectorAll('#processBody tr');
  return Array.from(rows).map(row => {
    const pid      = row.querySelector('.pid-input').value.trim();
    const arrival  = row.querySelector('.arrival-input').value;
    const burst    = row.querySelector('.burst-input').value;
    const priInput = row.querySelector('.priority-input');
    return {
      pid,
      arrival_time: parseInt(arrival,   10),
      burst_time:   parseInt(burst,     10),
      priority:     parseInt(priInput ? priInput.value : '1', 10),
    };
  });
}

// ─────────────────────────────────────────────
//  Example loaders
// ─────────────────────────────────────────────
const EXAMPLES = {
  basic: [
    { pid:'P1', arrival:0, burst:8, priority:3 },
    { pid:'P2', arrival:1, burst:4, priority:1 },
    { pid:'P3', arrival:2, burst:9, priority:2 },
    { pid:'P4', arrival:3, burst:5, priority:4 },
  ],
  idle: [
    { pid:'P1', arrival:0,  burst:3, priority:2 },
    { pid:'P2', arrival:7,  burst:4, priority:1 },
    { pid:'P3', arrival:12, burst:2, priority:3 },
  ],
  ties: [
    { pid:'P1', arrival:0, burst:5, priority:2 },
    { pid:'P2', arrival:0, burst:5, priority:1 },
    { pid:'P3', arrival:0, burst:3, priority:2 },
  ],
};

function loadExample(name) {
  document.getElementById('processBody').innerHTML = '';
  processCount = 0;
  const data = EXAMPLES[name] || EXAMPLES.basic;
  data.forEach(d => addProcessRow(d.pid, d.arrival, d.burst, d.priority));
}

// ─────────────────────────────────────────────
//  Run simulation
// ─────────────────────────────────────────────
async function runSimulation() {
  const errorDiv = document.getElementById('inputError');
  const runBtn   = document.getElementById('runBtn');
  errorDiv.classList.add('d-none');

  const algo      = document.getElementById('algorithmSelect').value;
  const quantum   = parseInt(document.getElementById('quantumInput').value, 10);
  const processes = getProcesses();

  if (processes.length === 0) {
    showError('Add at least one process before running.');
    return;
  }

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Running…';

  try {
    const resp = await fetch('/scheduling/run', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ algorithm: algo, quantum, processes }),
    });
    const data = await resp.json();

    if (!resp.ok) {
      showError(data.error || 'Server error. Please check your inputs.');
      return;
    }

    lastSchedulingRun = { algo, quantum, processes, data };
    renderResults(data, algo, quantum);
  } catch (err) {
    showError('Network error: ' + err.message);
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = '<i class="bi bi-play-fill me-1"></i>Run Simulation';
  }
}

function showError(msg) {
  const div = document.getElementById('inputError');
  div.textContent = msg;
  div.classList.remove('d-none');
}

// ─────────────────────────────────────────────
//  Render results
// ─────────────────────────────────────────────
function renderResults(data, algo, quantum) {
  document.getElementById('resultsPlaceholder').classList.add('d-none');
  document.getElementById('resultsPanel').classList.remove('d-none');

  renderMetricCards(data.metrics, algo, quantum);
  renderGantt(data.gantt, algo, quantum);
  renderResultsTable(data.results, data.metrics);
  renderExecutionTrace(data.execution_trace || data.gantt);
}

function renderExecutionTrace(trace) {
  const tbody = document.getElementById('executionTraceBody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!trace || !trace.length) return;

  trace.forEach((slot, idx) => {
    const isIdle = slot.pid === 'IDLE';
    const duration = slot.duration !== undefined ? slot.duration : (slot.end - slot.start);
    const start = slot.start;
    const end = slot.end;
    const desc = slot.description || (isIdle ? 'CPU Idle — waiting for processes in ready queue' : `Process ${slot.pid} executing`);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="ps-3 fw-semibold text-muted">#${slot.step || (idx + 1)}</td>
      <td><span class="badge bg-light text-dark border">${start} ms → ${end} ms</span></td>
      <td>
        <span class="badge ${isIdle ? 'bg-secondary' : 'bg-primary'}">${slot.pid}</span>
      </td>
      <td class="small">${desc}</td>
      <td class="text-end pe-3 fw-bold">${duration} ms</td>
    `;
    tbody.appendChild(tr);
  });
}

// ── Metric cards ──────────────────────────────
const ALGO_LABELS = {
  fcfs:     'FCFS',
  sjf:      'SJF',
  priority: 'Priority',
  rr:       'Round Robin',
};

function renderMetricCards(metrics, algo, quantum) {
  const label = algo === 'rr'
    ? `Round Robin (Q=${quantum})`
    : ALGO_LABELS[algo];

  document.getElementById('metricCards').innerHTML = `
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-primary">${metrics.avg_turnaround}</div>
        <div class="small text-muted">Avg Turnaround</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-success">${metrics.avg_waiting}</div>
        <div class="small text-muted">Avg Waiting</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-warning">${metrics.avg_response}</div>
        <div class="small text-muted">Avg Response</div>
      </div>
    </div>
    <div class="col-6 col-md-3">
      <div class="card border-0 shadow-sm text-center py-3">
        <div class="fs-4 fw-bold text-info">${metrics.cpu_utilization}%</div>
        <div class="small text-muted">CPU Utilisation</div>
        <div class="text-muted" style="font-size:.65rem;">burst ÷ makespan × 100</div>
      </div>
    </div>
    <div class="col-12">
      <div class="card border-0 bg-light shadow-sm">
        <div class="card-body py-2 small text-muted">
          <strong>Algorithm:</strong> ${label} &nbsp;|&nbsp;
          <strong>Total Burst:</strong> ${metrics.total_burst} &nbsp;|&nbsp;
          <strong>Makespan:</strong> ${metrics.makespan}
        </div>
      </div>
    </div>`;
}

// ── Gantt chart ───────────────────────────────
function renderGantt(gantt, algo, quantum) {
  document.getElementById('ganttAlgoLabel').textContent =
    algo === 'rr' ? `Round Robin (Q=${quantum})` : ALGO_LABELS[algo];

  // Assign colours: one colour per unique pid, IDLE always grey
  const pidSet = [...new Set(gantt.map(g => g.pid).filter(p => p !== 'IDLE'))].sort();
  const colorMap = {};
  pidSet.forEach((pid, i) => { colorMap[pid] = PROCESS_COLORS[i % PROCESS_COLORS.length]; });
  colorMap['IDLE'] = IDLE_COLOR;

  /*
   * FIX BUG 1: removed `parsing:false`.
   *
   * Chart.js 4 floating-bar format requires the parsing pipeline to
   * interpret `x: [min, max]` as a range.  `parsing:false` bypasses that
   * step, causing every bar to render with zero width (invisible).
   * Solution: let Chart.js parse normally with the standard floating-bar
   * object format { x: [start, end], y: 'CPU' }.
   */
  const datasets = gantt.map(seg => ({
    label:           seg.pid,
    data:            [{ x: [seg.start, seg.end], y: 'CPU' }],
    backgroundColor: colorMap[seg.pid],
    borderColor:     'rgba(255,255,255,0.7)',
    borderWidth:     1,
    borderRadius:    3,
    borderSkipped:   false,
  }));

  const maxTime = Math.max(...gantt.map(g => g.end));

  // Destroy previous instance before re-creating
  if (ganttChartInstance) {
    ganttChartInstance.destroy();
    ganttChartInstance = null;
  }

  /*
   * FIX BUG 2: set the wrapper div height BEFORE new Chart() is called.
   *
   * With maintainAspectRatio:false, Chart.js reads the parent container's
   * offsetHeight at construction time.  Setting canvas.style.height after
   * construction has no effect.  We size the wrapper <div id="gantt-wrapper">
   * instead, which the canvas fills via width:100%/height:100%.
   */
  const wrapper = document.getElementById('gantt-wrapper');
  wrapper.style.height = '110px';

  const ctx = document.getElementById('ganttChart').getContext('2d');

  ganttChartInstance = new Chart(ctx, {
    type: 'bar',
    data: { datasets },
    options: {
      indexAxis: 'y',
      responsive:          true,
      maintainAspectRatio: false,
      // NOTE: parsing:false intentionally removed (see BUG 1 fix above)
      animation:           { duration: 400 },
      scales: {
        x: {
          type:  'linear',
          min:   0,
          max:   maxTime,
          title: { display: true, text: 'Time Units' },
          ticks: { stepSize: 1, maxTicksLimit: 30 },
          grid:  { color: 'rgba(0,0,0,0.05)' },
        },
        /*
         * FIX BUG 3: declare type:'category' explicitly.
         *
         * When every dataset contributes only one data point with y:'CPU',
         * Chart.js 4 may auto-detect the axis type as 'linear' and reject
         * the string label, rendering nothing.  Declaring 'category'
         * forces correct string-label handling across all datasets.
         */
        y: {
          type:    'category',
          labels:  ['CPU'],
          stacked: true,
          grid:    { display: false },
          ticks:   { font: { weight: 'bold' } },
        },
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            title: items  => `Process: ${items[0].dataset.label}`,
            label: item  => {
              const [s, e] = item.raw.x;
              return `  Time ${s} → ${e}  (duration: ${e - s})`;
            },
          },
        },
      },
    },
    plugins: [{
      // Inline process labels drawn directly on each bar
      id: 'ganttLabels',
      afterDatasetsDraw(chart) {
        const { ctx: c } = chart;
        chart.data.datasets.forEach((ds, di) => {
          const meta = chart.getDatasetMeta(di);
          if (meta.hidden) return;
          meta.data.forEach(bar => {
            const seg   = gantt[di];
            const dur   = seg.end - seg.start;
            const label = dur >= 1 ? seg.pid : '';
            const width = Math.abs(bar.x - bar.base) || bar.width || 0;
            if (width < 14 || !label) return;
            const centerX = (bar.base + bar.x) / 2;
            const centerY = bar.y;
            c.save();
            c.fillStyle    = seg.pid === 'IDLE' ? '#555' : '#fff';
            c.font         = `bold ${Math.min(12, Math.max(9, width / (label.length + 1)))}px sans-serif`;
            c.textAlign    = 'center';
            c.textBaseline = 'middle';
            c.fillText(label, centerX, centerY);
            c.restore();
          });
        });
      },
    }],
  });

  // Render colour legend below chart
  const legendDiv = document.getElementById('ganttLegend');
  legendDiv.innerHTML =
    pidSet.map(pid =>
      `<span class="d-inline-flex align-items-center gap-1">
         <span style="width:12px;height:12px;border-radius:2px;
                      background:${colorMap[pid]};display:inline-block;"></span>
         ${escHtml(pid)}
       </span>`
    ).join('') +
    `<span class="d-inline-flex align-items-center gap-1">
       <span style="width:12px;height:12px;border-radius:2px;
                    background:${IDLE_COLOR};display:inline-block;
                    border:1px solid #aaa;"></span>
       IDLE
     </span>`;
}

// ── Results table ─────────────────────────────
function renderResultsTable(results, metrics) {
  const tbody = document.getElementById('resultsBody');
  const tfoot = document.getElementById('resultsFoot');

  const sorted = [...results].sort((a, b) =>
    a.pid < b.pid ? -1 : a.pid > b.pid ? 1 : 0
  );

  tbody.innerHTML = sorted.map(r => `
    <tr>
      <td class="ps-3 fw-semibold">${escHtml(r.pid)}</td>
      <td>${r.arrival_time}</td>
      <td>${r.burst_time}</td>
      <td>${r.completion_time}</td>
      <td class="text-primary fw-semibold">${r.turnaround_time}</td>
      <td class="text-success fw-semibold">${r.waiting_time}</td>
      <td class="text-warning fw-semibold">${r.response_time}</td>
    </tr>`).join('');

  tfoot.innerHTML = `
    <tr>
      <td class="ps-3" colspan="4">Averages</td>
      <td class="text-primary">${metrics.avg_turnaround}</td>
      <td class="text-success">${metrics.avg_waiting}</td>
      <td class="text-warning">${metrics.avg_response}</td>
    </tr>`;
}

// ─────────────────────────────────────────────
//  Utility
// ─────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
