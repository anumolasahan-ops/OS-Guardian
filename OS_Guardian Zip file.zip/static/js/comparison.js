/**
 * OS Guardian - Performance Comparison Controller
 * Handles benchmarking across CPU Scheduling, Memory Allocation, and Page Replacement.
 * Supports focused comparison (2-4 algorithms) with grounded trade-off analysis.
 */

document.addEventListener('DOMContentLoaded', () => {
  let cpuChartInstance = null;
  let memChartInstance = null;
  let pagingChartInstance = null;

  let lastCpuData = null;
  let lastMemData = null;
  let lastPagingData = null;

  function renderTradeoffs(containerId, tradeoffs) {
    const el = document.getElementById(containerId);
    if (!el || !tradeoffs) return;

    let html = '';
    if (tradeoffs.summary) {
      html += `<div class="alert alert-primary py-2 px-3 mb-3 fw-semibold"><i class="bi bi-info-circle-fill me-2"></i>${tradeoffs.summary}</div>`;
    }
    if (Array.isArray(tradeoffs.algorithm_insights)) {
      html += '<div class="row g-2">';
      tradeoffs.algorithm_insights.forEach(item => {
        html += `
          <div class="col-md-6">
            <div class="p-3 border rounded bg-white h-100 shadow-sm">
              <strong class="text-dark d-block mb-2 border-bottom pb-1">${item.title}</strong>
              <div class="mb-1 small"><strong class="text-success"><i class="bi bi-plus-circle me-1"></i>Strengths:</strong> ${item.pros}</div>
              <div class="mb-1 small"><strong class="text-danger"><i class="bi bi-dash-circle me-1"></i>Weaknesses:</strong> ${item.cons}</div>
              ${item.best_for ? `<div class="small text-muted mt-2 pt-1 border-top"><strong class="text-secondary"><i class="bi bi-star me-1"></i>Ideal For:</strong> ${item.best_for}</div>` : ''}
            </div>
          </div>
        `;
      });
      html += '</div>';
    }
    el.innerHTML = html;
  }

  // =========================================================================
  // 1. CPU SCHEDULING BENCHMARK
  // =========================================================================

  const cpuTbody = document.getElementById('cpu-procs-tbody');
  const btnAddCpuProc = document.getElementById('btn-add-cpu-proc');
  const btnRunCpu = document.getElementById('btn-run-cpu-comparison');
  const btnCpuPresetStd = document.getElementById('btn-cpu-preset-std');
  const btnCpuPresetConvoy = document.getElementById('btn-cpu-preset-convoy');
  const btnSaveCpuHistory = document.getElementById('btn-save-cpu-history');

  const standardCpuProcs = [
    { pid: 'P1', arrival: 0, burst: 6, priority: 2 },
    { pid: 'P2', arrival: 1, burst: 8, priority: 1 },
    { pid: 'P3', arrival: 2, burst: 7, priority: 3 },
    { pid: 'P4', arrival: 3, burst: 3, priority: 4 }
  ];

  const convoyCpuProcs = [
    { pid: 'P1', arrival: 0, burst: 30, priority: 3 },
    { pid: 'P2', arrival: 1, burst: 2, priority: 2 },
    { pid: 'P3', arrival: 2, burst: 3, priority: 1 },
    { pid: 'P4', arrival: 3, burst: 1, priority: 4 }
  ];

  function populateCpuTable(procs) {
    cpuTbody.innerHTML = '';
    procs.forEach((p, idx) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td><input type="text" class="form-control form-control-sm text-center pid-input" value="${p.pid || 'P' + (idx + 1)}" /></td>
        <td><input type="number" class="form-control form-control-sm text-center arrival-input" value="${p.arrival}" min="0" /></td>
        <td><input type="number" class="form-control form-control-sm text-center burst-input" value="${p.burst}" min="1" /></td>
        <td><input type="number" class="form-control form-control-sm text-center priority-input" value="${p.priority || 1}" min="1" /></td>
        <td class="text-center">
          <button class="btn btn-sm btn-outline-danger btn-del-cpu" type="button" title="Delete process">
            <i class="bi bi-x"></i>
          </button>
        </td>
      `;
      cpuTbody.appendChild(row);
    });
  }

  cpuTbody.addEventListener('click', (e) => {
    if (e.target.closest('.btn-del-cpu')) {
      const row = e.target.closest('tr');
      if (cpuTbody.querySelectorAll('tr').length > 1) {
        row.remove();
      } else {
        alert('At least one process is required.');
      }
    }
  });

  btnAddCpuProc.addEventListener('click', () => {
    const count = cpuTbody.querySelectorAll('tr').length + 1;
    const row = document.createElement('tr');
    row.innerHTML = `
      <td><input type="text" class="form-control form-control-sm text-center pid-input" value="P${count}" /></td>
      <td><input type="number" class="form-control form-control-sm text-center arrival-input" value="0" min="0" /></td>
      <td><input type="number" class="form-control form-control-sm text-center burst-input" value="5" min="1" /></td>
      <td><input type="number" class="form-control form-control-sm text-center priority-input" value="1" min="1" /></td>
      <td class="text-center">
        <button class="btn btn-sm btn-outline-danger btn-del-cpu" type="button"><i class="bi bi-x"></i></button>
      </td>
    `;
    cpuTbody.appendChild(row);
  });

  btnCpuPresetStd.addEventListener('click', () => {
    document.getElementById('cpu-quantum').value = 2;
    populateCpuTable(standardCpuProcs);
  });

  btnCpuPresetConvoy.addEventListener('click', () => {
    document.getElementById('cpu-quantum').value = 3;
    populateCpuTable(convoyCpuProcs);
  });

  // Initial load
  populateCpuTable(standardCpuProcs);

  btnRunCpu.addEventListener('click', async () => {
    const rows = cpuTbody.querySelectorAll('tr');
    const processes = [];
    for (const r of rows) {
      const pid = r.querySelector('.pid-input').value.trim();
      const arrival = parseInt(r.querySelector('.arrival-input').value, 10);
      const burst = parseInt(r.querySelector('.burst-input').value, 10);
      const priority = parseInt(r.querySelector('.priority-input').value, 10);

      if (!pid || isNaN(arrival) || arrival < 0 || isNaN(burst) || burst <= 0) {
        alert('Please provide valid process parameters (Burst must be positive).');
        return;
      }
      processes.push({
        pid,
        arrival,
        arrival_time: arrival,
        burst,
        burst_time: burst,
        priority: isNaN(priority) ? 1 : priority
      });
    }

    const quantum = parseInt(document.getElementById('cpu-quantum').value, 10);
    if (isNaN(quantum) || quantum <= 0) {
      alert('Time quantum must be a positive integer.');
      return;
    }

    const checkedBoxes = document.querySelectorAll('.cpu-algo-check:checked');
    const selected_algorithms = Array.from(checkedBoxes).map(cb => cb.value);
    if (selected_algorithms.length < 2) {
      alert('Please select at least 2 algorithms to compare.');
      return;
    }

    btnRunCpu.disabled = true;
    btnRunCpu.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Evaluating algorithms...';

    try {
      const payload = {
        subsystem: 'cpu',
        processes,
        quantum,
        selected_algorithms,
        data: { processes, quantum, selected_algorithms }
      };

      const resp = await fetch('/comparison/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();
      if (!resp.ok) {
        alert(data.error || 'Comparison error');
        return;
      }

      lastCpuData = { processes, quantum, selected_algorithms, results: data };
      renderCpuResults(data);
    } catch (err) {
      alert('Network error while running CPU comparison: ' + err.message);
    } finally {
      btnRunCpu.disabled = false;
      btnRunCpu.innerHTML = '<i class="bi bi-play-circle-fill me-1"></i>Run CPU Scheduling Benchmark';
    }
  });

  function renderCpuResults(data) {
    document.getElementById('cpu-placeholder').style.display = 'none';
    document.getElementById('cpu-results-card').style.display = 'block';

    const results = data.results || {};
    const best = data.best_performer || data.best_metrics || {};

    // Highlights
    const hlContainer = document.getElementById('cpu-highlights');
    hlContainer.innerHTML = `
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Lowest Waiting Time</small>
          <span class="badge bg-success fs-6">${best.min_waiting_time || best.min_waiting || '-'}</span>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Lowest Turnaround</small>
          <span class="badge bg-primary fs-6">${best.min_turnaround_time || best.min_turnaround || '-'}</span>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Lowest Response Time</small>
          <span class="badge bg-info text-dark fs-6">${best.min_response_time || best.min_response || '-'}</span>
        </div>
      </div>
    `;

    // Table
    const tbody = document.getElementById('cpu-results-tbody');
    tbody.innerHTML = '';
    const activeAlgos = data.selected_algorithms || ['FCFS', 'SJF', 'Priority', 'Round Robin'];
    const metricsData = { labels: [], waiting: [], turnaround: [], response: [] };

    activeAlgos.forEach((algo) => {
      const item = results[algo];
      if (!item) return;
      const s = item.summary || item.metrics;
      if (!s) return;

      metricsData.labels.push(algo);
      metricsData.waiting.push(s.avg_waiting);
      metricsData.turnaround.push(s.avg_turnaround);
      metricsData.response.push(s.avg_response);

      const isBestWait = (best.min_waiting_time === algo || best.min_waiting === algo);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="fw-bold ${isBestWait ? 'table-success text-success' : ''}">
          ${algo} ${isBestWait ? '<i class="bi bi-trophy-fill text-warning ms-1" title="Lowest Avg Wait"></i>' : ''}
        </td>
        <td>${Number(s.avg_turnaround).toFixed(2)} ms</td>
        <td class="fw-bold">${Number(s.avg_waiting).toFixed(2)} ms</td>
        <td>${Number(s.avg_response).toFixed(2)} ms</td>
        <td>${Number(s.cpu_utilization).toFixed(1)}%</td>
        <td>${s.makespan} ms</td>
      `;
      tbody.appendChild(tr);
    });

    // Chart
    const ctx = document.getElementById('cpuComparisonChart').getContext('2d');
    if (cpuChartInstance) cpuChartInstance.destroy();

    cpuChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: metricsData.labels,
        datasets: [
          {
            label: 'Avg Turnaround (ms)',
            data: metricsData.turnaround,
            backgroundColor: 'rgba(13, 110, 253, 0.75)',
            borderColor: '#0d6efd',
            borderWidth: 1
          },
          {
            label: 'Avg Waiting (ms)',
            data: metricsData.waiting,
            backgroundColor: 'rgba(25, 135, 84, 0.75)',
            borderColor: '#198754',
            borderWidth: 1
          },
          {
            label: 'Avg Response (ms)',
            data: metricsData.response,
            backgroundColor: 'rgba(255, 193, 7, 0.75)',
            borderColor: '#ffc107',
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top' },
          tooltip: { mode: 'index', intersect: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Time (ms)' }
          }
        }
      }
    });

    // Trade-off insights
    renderTradeoffs('cpu-tradeoffs-content', data.tradeoff_analysis);
  }

  btnSaveCpuHistory.addEventListener('click', async () => {
    if (!lastCpuData) return;
    try {
      const resp = await fetch('/history/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module_type: 'comparison',
          algorithm: 'CPU Scheduling Suite',
          parameters: {
            processes: lastCpuData.processes,
            quantum: lastCpuData.quantum,
            selected_algorithms: lastCpuData.selected_algorithms
          },
          results: lastCpuData.results,
          summary_metrics: lastCpuData.results.best_performer || lastCpuData.results.best_metrics || {},
          summary_text: `CPU Benchmark (${(lastCpuData.selected_algorithms || []).join(', ')}): Lowest wait: ${lastCpuData.results?.best_performer?.min_waiting || 'SJF'}`
        })
      });
      const res = await resp.json();
      if (resp.ok) {
        alert('CPU benchmark saved to History successfully! (ID: #' + res.id + ')');
      } else {
        alert(res.error || 'Failed to save to history');
      }
    } catch (err) {
      alert('Error saving history: ' + err.message);
    }
  });

  // =========================================================================
  // 2. MEMORY ALLOCATION BENCHMARK
  // =========================================================================

  const btnRunMem = document.getElementById('btn-run-mem-comparison');
  const btnMemPresetStd = document.getElementById('btn-mem-preset-std');
  const btnMemPresetTight = document.getElementById('btn-mem-preset-tight');
  const btnSaveMemHistory = document.getElementById('btn-save-mem-history');

  btnMemPresetStd.addEventListener('click', () => {
    document.getElementById('mem-blocks-input').value = '100, 500, 200, 300, 600';
    document.getElementById('mem-procs-input').value = '212, 417, 112, 426';
  });

  btnMemPresetTight.addEventListener('click', () => {
    document.getElementById('mem-blocks-input').value = '200, 200, 200, 200';
    document.getElementById('mem-procs-input').value = '180, 190, 210, 150';
  });

  btnRunMem.addEventListener('click', async () => {
    const blocksStr = document.getElementById('mem-blocks-input').value;
    const procsStr = document.getElementById('mem-procs-input').value;

    const blocks = blocksStr.split(/[\s,]+/).map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));
    const processes = procsStr.split(/[\s,]+/).map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));

    if (blocks.length === 0 || processes.length === 0 || blocks.some(b => b <= 0) || processes.some(p => p <= 0)) {
      alert('Memory blocks and process sizes must contain positive numbers.');
      return;
    }

    const checkedBoxes = document.querySelectorAll('.mem-algo-check:checked');
    const selected_algorithms = Array.from(checkedBoxes).map(cb => cb.value);
    if (selected_algorithms.length < 2) {
      alert('Please select at least 2 memory strategies to compare.');
      return;
    }

    btnRunMem.disabled = true;
    btnRunMem.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Comparing strategies...';

    try {
      const payload = {
        subsystem: 'memory',
        blocks,
        processes,
        selected_algorithms,
        data: { blocks, processes, selected_algorithms }
      };

      const resp = await fetch('/comparison/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();
      if (!resp.ok) {
        alert(data.error || 'Comparison error');
        return;
      }

      lastMemData = { blocks, processes, selected_algorithms, results: data };
      renderMemResults(data);
    } catch (err) {
      alert('Network error while running Memory comparison: ' + err.message);
    } finally {
      btnRunMem.disabled = false;
      btnRunMem.innerHTML = '<i class="bi bi-play-circle-fill me-1"></i>Run Memory Allocation Benchmark';
    }
  });

  function renderMemResults(data) {
    document.getElementById('mem-placeholder').style.display = 'none';
    document.getElementById('mem-results-card').style.display = 'block';

    const results = data.results || {};
    const best = data.best_performer || data.best_metrics || {};

    // Highlights
    const hlContainer = document.getElementById('mem-highlights');
    hlContainer.innerHTML = `
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Most Processes Allocated</small>
          <span class="badge bg-success fs-6">${best.most_allocated || best.max_allocated || '-'}</span>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Least Internal Fragmentation</small>
          <span class="badge bg-primary fs-6">${best.least_fragmentation || best.min_internal_frag || '-'}</span>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Highest Memory Utilization</small>
          <span class="badge bg-info text-dark fs-6">${best.highest_utilization || best.max_utilization || '-'}</span>
        </div>
      </div>
    `;

    // Table
    const tbody = document.getElementById('mem-results-tbody');
    tbody.innerHTML = '';
    const chartLabels = [];
    const chartUtil = [];
    const chartFrag = [];

    const activeStrategies = data.selected_algorithms || ['First Fit', 'Best Fit', 'Worst Fit'];

    activeStrategies.forEach((title) => {
      const item = results[title] || results[title.toLowerCase().replace(' ', '_')];
      if (!item) return;
      const s = item.summary || item.metrics;
      if (!s) return;

      chartLabels.push(title);
      chartUtil.push(s.utilization_percentage);
      chartFrag.push(s.total_internal_fragmentation);

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="fw-bold">${title}</td>
        <td><span class="badge bg-success">${s.allocated_processes_count}</span></td>
        <td><span class="badge bg-${s.unallocated_processes_count > 0 ? 'danger' : 'secondary'}">${s.unallocated_processes_count}</span></td>
        <td>${s.allocated_memory} KB</td>
        <td class="fw-bold">${s.total_internal_fragmentation} KB</td>
        <td><strong>${Number(s.utilization_percentage).toFixed(1)}%</strong></td>
      `;
      tbody.appendChild(tr);
    });

    // Chart
    const ctx = document.getElementById('memComparisonChart').getContext('2d');
    if (memChartInstance) memChartInstance.destroy();

    memChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: chartLabels,
        datasets: [
          {
            label: 'Memory Utilization (%)',
            data: chartUtil,
            backgroundColor: 'rgba(13, 110, 253, 0.75)',
            borderColor: '#0d6efd',
            borderWidth: 1,
            yAxisID: 'y'
          },
          {
            label: 'Internal Fragmentation (KB)',
            data: chartFrag,
            backgroundColor: 'rgba(220, 53, 69, 0.75)',
            borderColor: '#dc3545',
            borderWidth: 1,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: { display: true, text: 'Utilization (%)' },
            min: 0,
            max: 100
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            grid: { drawOnChartArea: false },
            title: { display: true, text: 'Fragmentation (KB)' }
          }
        }
      }
    });

    // Trade-off insights
    renderTradeoffs('mem-tradeoffs-content', data.tradeoff_analysis);
  }

  btnSaveMemHistory.addEventListener('click', async () => {
    if (!lastMemData) return;
    try {
      const resp = await fetch('/history/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module_type: 'comparison',
          algorithm: 'Memory Allocation Suite',
          parameters: {
            blocks: lastMemData.blocks,
            processes: lastMemData.processes,
            selected_algorithms: lastMemData.selected_algorithms
          },
          results: lastMemData.results,
          summary_metrics: lastMemData.results.best_performer || lastMemData.results.best_metrics || {},
          summary_text: `Memory Benchmark (${(lastMemData.selected_algorithms || []).join(', ')}): Most allocated: ${lastMemData.results?.best_performer?.most_allocated || 'Best Fit'}`
        })
      });
      const res = await resp.json();
      if (resp.ok) {
        alert('Memory benchmark saved to History! (ID: #' + res.id + ')');
      } else {
        alert(res.error || 'Failed to save to history');
      }
    } catch (err) {
      alert('Error saving history: ' + err.message);
    }
  });

  // =========================================================================
  // 3. PAGE REPLACEMENT BENCHMARK
  // =========================================================================

  const btnRunPaging = document.getElementById('btn-run-paging-comparison');
  const btnPagingPresetStd = document.getElementById('btn-paging-preset-std');
  const btnPagingPresetBelady = document.getElementById('btn-paging-preset-belady');
  const btnSavePagingHistory = document.getElementById('btn-save-paging-history');

  btnPagingPresetStd.addEventListener('click', () => {
    document.getElementById('paging-frames-input').value = 3;
    document.getElementById('paging-refs-input').value = '7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1';
  });

  btnPagingPresetBelady.addEventListener('click', () => {
    document.getElementById('paging-frames-input').value = 3;
    document.getElementById('paging-refs-input').value = '1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5';
  });

  btnRunPaging.addEventListener('click', async () => {
    const frameCount = parseInt(document.getElementById('paging-frames-input').value, 10);
    const refsStr = document.getElementById('paging-refs-input').value;

    const reference_string = refsStr.split(/[\s,]+/).map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));

    if (isNaN(frameCount) || frameCount <= 0 || reference_string.length === 0) {
      alert('Please provide a valid frame count (> 0) and reference string.');
      return;
    }

    const checkedBoxes = document.querySelectorAll('.paging-algo-check:checked');
    const selected_algorithms = Array.from(checkedBoxes).map(cb => cb.value);
    if (selected_algorithms.length < 2) {
      alert('Please select at least 2 page replacement algorithms to compare.');
      return;
    }

    btnRunPaging.disabled = true;
    btnRunPaging.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Testing replacement algorithms...';

    try {
      const payload = {
        subsystem: 'paging',
        frame_count: frameCount,
        num_frames: frameCount,
        reference_string,
        pages: reference_string,
        selected_algorithms,
        data: {
          num_frames: frameCount,
          pages: reference_string,
          selected_algorithms
        }
      };

      const resp = await fetch('/comparison/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();
      if (!resp.ok) {
        alert(data.error || 'Comparison error');
        return;
      }

      lastPagingData = { frame_count: frameCount, reference_string, selected_algorithms, results: data };
      renderPagingResults(data);
    } catch (err) {
      alert('Network error while running Paging comparison: ' + err.message);
    } finally {
      btnRunPaging.disabled = false;
      btnRunPaging.innerHTML = '<i class="bi bi-play-circle-fill me-1"></i>Run Page Replacement Benchmark';
    }
  });

  function renderPagingResults(data) {
    document.getElementById('paging-placeholder').style.display = 'none';
    document.getElementById('paging-results-card').style.display = 'block';

    const results = data.results || {};
    const best = data.best_performer || data.best_metrics || {};

    const algoNames = {
      fifo: 'FIFO',
      FIFO: 'FIFO',
      lru: 'LRU',
      LRU: 'LRU',
      optimal: 'Optimal',
      Optimal: 'Optimal'
    };

    // Highlights
    const hlContainer = document.getElementById('paging-highlights');
    hlContainer.innerHTML = `
      <div class="col-md-6">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Lowest Page Faults</small>
          <span class="badge bg-success fs-6">${best.lowest_page_faults || best.min_faults || '-'}</span>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-2 border rounded bg-light text-center">
          <small class="text-muted d-block">Highest Hit Ratio</small>
          <span class="badge bg-primary fs-6">${best.highest_hit_ratio || best.max_hits || '-'}</span>
        </div>
      </div>
    `;

    // Table
    const tbody = document.getElementById('paging-results-tbody');
    tbody.innerHTML = '';
    const chartLabels = [];
    const chartHits = [];
    const chartFaults = [];

    const activeAlgos = data.selected_algorithms || ['FIFO', 'LRU', 'Optimal'];

    activeAlgos.forEach((key) => {
      const item = results[key] || results[key.toLowerCase()];
      if (!item) return;
      const title = algoNames[key] || key;

      chartLabels.push(title);
      chartHits.push(item.page_hits);
      chartFaults.push(item.page_faults);

      const isBest = (best.lowest_page_faults === key || best.min_faults === key);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="fw-bold ${isBest ? 'table-success text-success' : ''}">
          ${title} ${isBest ? '<i class="bi bi-trophy-fill text-warning ms-1" title="Minimum Faults"></i>' : ''}
        </td>
        <td>${item.total_references}</td>
        <td class="text-success fw-bold">${item.page_hits}</td>
        <td class="text-danger fw-bold">${item.page_faults}</td>
        <td>${(item.hit_ratio * 100).toFixed(1)}%</td>
        <td>${(item.fault_ratio * 100).toFixed(1)}%</td>
      `;
      tbody.appendChild(tr);
    });

    // Chart
    const ctx = document.getElementById('pagingComparisonChart').getContext('2d');
    if (pagingChartInstance) pagingChartInstance.destroy();

    pagingChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: chartLabels,
        datasets: [
          {
            label: 'Page Hits',
            data: chartHits,
            backgroundColor: 'rgba(25, 135, 84, 0.75)',
            borderColor: '#198754',
            borderWidth: 1
          },
          {
            label: 'Page Faults',
            data: chartFaults,
            backgroundColor: 'rgba(220, 53, 69, 0.75)',
            borderColor: '#dc3545',
            borderWidth: 1
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top' },
          tooltip: { mode: 'index', intersect: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: { display: true, text: 'Count' }
          }
        }
      }
    });

    // Trade-off insights
    renderTradeoffs('paging-tradeoffs-content', data.tradeoff_analysis);
  }

  btnSavePagingHistory.addEventListener('click', async () => {
    if (!lastPagingData) return;
    try {
      const resp = await fetch('/history/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module_type: 'comparison',
          algorithm: 'Page Replacement Suite',
          parameters: {
            frame_count: lastPagingData.frame_count,
            reference_string: lastPagingData.reference_string,
            selected_algorithms: lastPagingData.selected_algorithms
          },
          results: lastPagingData.results,
          summary_metrics: lastPagingData.results.best_performer || lastPagingData.results.best_metrics || {},
          summary_text: `Paging Benchmark (${(lastPagingData.selected_algorithms || []).join(', ')}): Lowest faults: ${lastPagingData.results?.best_performer?.lowest_page_faults || 'Optimal'}`
        })
      });
      const res = await resp.json();
      if (resp.ok) {
        alert('Paging benchmark saved to History! (ID: #' + res.id + ')');
      } else {
        alert(res.error || 'Failed to save to history');
      }
    } catch (err) {
      alert('Error saving history: ' + err.message);
    }
  });

});
