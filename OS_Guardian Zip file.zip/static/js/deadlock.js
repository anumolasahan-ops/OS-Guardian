/**
 * static/js/deadlock.js
 * =====================
 * Client controller for Banker's Algorithm Deadlock Management module.
 *  - Dynamic matrix input builders
 *  - Preset configurations (Silberschatz safe & unsafe states)
 *  - Safety algorithm execution via POST /deadlock/run
 *  - Need matrix & step-by-step trace rendering
 *  - Resource request simulation via POST /deadlock/request
 *  - History persistence via POST /history/save
 */

'use strict';

let currentProcessCount = 5;
let currentResourceCount = 3;
let lastSimulationResult = null;

const DEADLOCK_PRESETS = {
  silberschatz: {
    n_proc: 5,
    n_res: 3,
    allocation: [
      [0, 1, 0],
      [2, 0, 0],
      [3, 0, 2],
      [2, 1, 1],
      [0, 0, 2],
    ],
    maximum: [
      [7, 5, 3],
      [3, 2, 2],
      [9, 0, 2],
      [2, 2, 2],
      [4, 3, 3],
    ],
    available: [3, 3, 2],
  },
  unsafe: {
    n_proc: 3,
    n_res: 2,
    allocation: [
      [2, 0],
      [1, 2],
      [3, 1],
    ],
    maximum: [
      [5, 5],
      [4, 4],
      [6, 4],
    ],
    available: [1, 0],
  },
};

document.addEventListener('DOMContentLoaded', () => {
  const rebuildBtn = document.getElementById('rebuildMatricesBtn');
  const runSafetyBtn = document.getElementById('runSafetyBtn');
  const submitReqBtn = document.getElementById('submitRequestBtn');
  const saveBtn = document.getElementById('saveDeadlockHistoryBtn');

  rebuildBtn.addEventListener('click', () => {
    currentProcessCount = parseInt(document.getElementById('procCountSelect').value, 10);
    currentResourceCount = parseInt(document.getElementById('resCountSelect').value, 10);
    buildMatrixInputs(currentProcessCount, currentResourceCount);
  });

  runSafetyBtn.addEventListener('click', runSafetySimulation);
  submitReqBtn.addEventListener('click', submitResourceRequest);
  saveBtn.addEventListener('click', saveDeadlockToHistory);

  // Initialize with textbook preset
  loadDeadlockPreset('silberschatz');

  if (new URLSearchParams(window.location.search).has('autorun')) {
    setTimeout(runSafetySimulation, 200);
  }
});

function getResourceName(idx) {
  return idx < 26 ? String.fromCharCode(65 + idx) : `R${idx}`;
}

function buildMatrixInputs(numProcs, numRes, initialData = null) {
  currentProcessCount = numProcs;
  currentResourceCount = numRes;

  document.getElementById('procCountSelect').value = numProcs;
  document.getElementById('resCountSelect').value = numRes;

  // Available Inputs
  const availContainer = document.getElementById('availableContainer');
  availContainer.innerHTML = '';
  for (let j = 0; j < numRes; j++) {
    const resName = getResourceName(j);
    const val = initialData?.available?.[j] ?? 3;
    const div = document.createElement('div');
    div.className = 'input-group input-group-sm';
    div.style.width = '105px';
    div.innerHTML = `
      <span class="input-group-text fw-bold">${resName}</span>
      <input type="number" class="form-control text-center avail-input" data-col="${j}" value="${val}" min="0" max="999" />
    `;
    availContainer.appendChild(div);
  }

  // Header helpers
  const buildHeaders = (theadId) => {
    const thead = document.getElementById(theadId);
    let html = '<tr><th>Proc</th>';
    for (let j = 0; j < numRes; j++) {
      html += `<th>${getResourceName(j)}</th>`;
    }
    html += '</tr>';
    thead.innerHTML = html;
  };

  buildHeaders('allocationHead');
  buildHeaders('maximumHead');

  // Body helpers
  const buildBody = (tbodyId, fieldKey, defaultVal = 0) => {
    const tbody = document.getElementById(tbodyId);
    tbody.innerHTML = '';
    for (let i = 0; i < numProcs; i++) {
      const tr = document.createElement('tr');
      let html = `<td class="fw-semibold text-muted small">P${i}</td>`;
      for (let j = 0; j < numRes; j++) {
        const val = initialData?.[fieldKey]?.[i]?.[j] ?? defaultVal;
        html += `
          <td>
            <input type="number" class="form-control form-control-sm text-center ${fieldKey}-input"
                   data-row="${i}" data-col="${j}" value="${val}" min="0" max="999" />
          </td>
        `;
      }
      tr.innerHTML = html;
      tbody.appendChild(tr);
    }
  };

  buildBody('allocationBody', 'allocation', 0);
  buildBody('maximumBody', 'maximum', 5);

  // Update Request Process dropdown & Request vector inputs
  const reqProcSelect = document.getElementById('reqProcSelect');
  reqProcSelect.innerHTML = '';
  for (let i = 0; i < numProcs; i++) {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = `P${i}`;
    reqProcSelect.appendChild(opt);
  }

  const reqInputs = document.getElementById('reqVectorInputs');
  reqInputs.innerHTML = '';
  for (let j = 0; j < numRes; j++) {
    const resName = getResourceName(j);
    const div = document.createElement('div');
    div.className = 'input-group input-group-sm';
    div.innerHTML = `
      <span class="input-group-text">${resName}</span>
      <input type="number" class="form-control text-center req-input" data-col="${j}" value="0" min="0" max="99" />
    `;
    reqInputs.appendChild(div);
  }
}

function loadDeadlockPreset(name) {
  const preset = DEADLOCK_PRESETS[name] || DEADLOCK_PRESETS.silberschatz;
  buildMatrixInputs(preset.n_proc, preset.n_res, preset);
}

function extractMatrix(inputClass, numProcs, numRes) {
  const inputs = document.querySelectorAll(`.${inputClass}`);
  const matrix = Array.from({ length: numProcs }, () => Array(numRes).fill(0));
  inputs.forEach(input => {
    const r = parseInt(input.dataset.row, 10);
    const c = parseInt(input.dataset.col, 10);
    const val = parseInt(input.value, 10);
    matrix[r][c] = isNaN(val) ? 0 : val;
  });
  return matrix;
}

function extractAvailable(numRes) {
  const inputs = document.querySelectorAll('.avail-input');
  const arr = Array(numRes).fill(0);
  inputs.forEach(input => {
    const c = parseInt(input.dataset.col, 10);
    const val = parseInt(input.value, 10);
    arr[c] = isNaN(val) ? 0 : val;
  });
  return arr;
}

async function runSafetySimulation() {
  const errDiv = document.getElementById('deadlockError');
  errDiv.classList.add('d-none');

  const allocation = extractMatrix('allocation-input', currentProcessCount, currentResourceCount);
  const maximum = extractMatrix('maximum-input', currentProcessCount, currentResourceCount);
  const available = extractAvailable(currentResourceCount);

  try {
    const resp = await fetch('/deadlock/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ allocation, maximum, available }),
    });

    const data = await resp.json();
    if (!resp.ok) {
      errDiv.textContent = data.error || 'Validation error.';
      errDiv.classList.remove('d-none');
      return;
    }

    lastSimulationResult = data;
    renderSafetyResults(data);
    document.getElementById('saveDeadlockHistoryBtn').disabled = false;
  } catch (err) {
    errDiv.textContent = `Network error: ${err.message}`;
    errDiv.classList.remove('d-none');
  }
}

function renderSafetyResults(data) {
  document.getElementById('deadlockPlaceholder').classList.add('d-none');
  const resultsDiv = document.getElementById('deadlockResults');
  resultsDiv.classList.remove('d-none');

  // Status Banner
  const banner = document.getElementById('safetyStatusBanner');
  banner.className = 'alert d-flex align-items-center mb-3 ' + (data.is_safe ? 'alert-success' : 'alert-danger');
  if (data.is_safe) {
    const seqBadges = data.safe_sequence.map(p => `<span class="badge bg-success fs-6 mx-1">${p}</span>`).join('<i class="bi bi-arrow-right text-muted mx-1"></i>');
    banner.innerHTML = `
      <i class="bi bi-check-circle-fill fs-3 me-3 text-success flex-shrink-0"></i>
      <div>
        <h5 class="fw-bold mb-1 text-success">SAFE STATE DETECTED</h5>
        <div class="mb-1">${data.explanation}</div>
        <div class="d-flex align-items-center flex-wrap mt-2">
          <strong class="me-2 small">Safe Sequence:</strong>
          <div>${seqBadges}</div>
        </div>
      </div>
    `;
  } else {
    banner.innerHTML = `
      <i class="bi bi-exclamation-triangle-fill fs-3 me-3 text-danger flex-shrink-0"></i>
      <div>
        <h5 class="fw-bold mb-1 text-danger">UNSAFE STATE DETECTED</h5>
        <div>${data.explanation}</div>
      </div>
    `;
  }

  // Need Table
  const needHead = document.getElementById('needHead');
  let headHtml = '<tr><th>Proc</th>';
  for (let j = 0; j < data.resource_names.length; j++) {
    headHtml += `<th>${data.resource_names[j]}</th>`;
  }
  headHtml += '</tr>';
  needHead.innerHTML = headHtml;

  const needBody = document.getElementById('needBody');
  needBody.innerHTML = '';
  for (let i = 0; i < data.need_matrix.length; i++) {
    const tr = document.createElement('tr');
    let rowHtml = `<td class="fw-semibold text-muted small">${data.process_names[i]}</td>`;
    for (let j = 0; j < data.need_matrix[i].length; j++) {
      rowHtml += `<td class="fw-bold text-danger">${data.need_matrix[i][j]}</td>`;
    }
    tr.innerHTML = rowHtml;
    needBody.appendChild(tr);
  }

  // Steps Table
  const stepsBody = document.getElementById('stepsBody');
  stepsBody.innerHTML = '';
  if (data.steps && data.steps.length > 0) {
    data.steps.forEach(st => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="fw-bold">${st.step_number}</td>
        <td><span class="badge bg-primary">${st.process_name}</span></td>
        <td><code>[${st.work_before.join(', ')}]</code></td>
        <td><code>[${st.need.join(', ')}] &le; [${st.work_before.join(', ')}]</code></td>
        <td><code class="text-success">[${st.work_after.join(', ')}]</code></td>
      `;
      stepsBody.appendChild(tr);
    });
  } else {
    stepsBody.innerHTML = `<tr><td colspan="5" class="text-muted py-3">No process could satisfy its Need from Available resources.</td></tr>`;
  }
}

async function submitResourceRequest() {
  const outcomeBanner = document.getElementById('requestOutcomeBanner');
  outcomeBanner.classList.add('d-none');

  const allocation = extractMatrix('allocation-input', currentProcessCount, currentResourceCount);
  const maximum = extractMatrix('maximum-input', currentProcessCount, currentResourceCount);
  const available = extractAvailable(currentResourceCount);

  const procIndex = parseInt(document.getElementById('reqProcSelect').value, 10);
  const reqInputs = document.querySelectorAll('.req-input');
  const reqVector = [];
  reqInputs.forEach(inp => reqVector.push(parseInt(inp.value, 10) || 0));

  try {
    const resp = await fetch('/deadlock/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        allocation,
        maximum,
        available,
        process_index: procIndex,
        request_vector: reqVector,
      }),
    });

    const res = await resp.json();
    outcomeBanner.classList.remove('d-none');

    if (!resp.ok) {
      outcomeBanner.className = 'alert alert-danger mt-3 small';
      outcomeBanner.innerHTML = `<i class="bi bi-x-circle me-1"></i>${res.error || 'Validation error'}`;
      return;
    }

    if (res.granted) {
      outcomeBanner.className = 'alert alert-success mt-3 small';
      outcomeBanner.innerHTML = `
        <strong><i class="bi bi-check-circle-fill me-1"></i>REQUEST GRANTED:</strong> ${res.message}
      `;
      // Update matrices on screen to match new granted state
      buildMatrixInputs(currentProcessCount, currentResourceCount, {
        allocation: res.allocation,
        maximum: res.maximum,
        available: res.available,
      });
      // Re-run safety visualization with updated matrices
      runSafetySimulation();
    } else {
      outcomeBanner.className = 'alert alert-warning mt-3 small';
      outcomeBanner.innerHTML = `
        <strong><i class="bi bi-exclamation-triangle-fill me-1"></i>REQUEST DENIED / ROLLED BACK:</strong> ${res.message}
      `;
    }
  } catch (err) {
    outcomeBanner.className = 'alert alert-danger mt-3 small';
    outcomeBanner.innerHTML = `Network error: ${err.message}`;
    outcomeBanner.classList.remove('d-none');
  }
}

async function saveDeadlockToHistory() {
  if (!lastSimulationResult) return;
  const saveBtn = document.getElementById('saveDeadlockHistoryBtn');
  saveBtn.disabled = true;
  saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving...';

  const summaryMetrics = {
    is_safe: lastSimulationResult.is_safe,
    safe_sequence: lastSimulationResult.safe_sequence.join(' -> ') || 'None',
    process_count: currentProcessCount,
    resource_count: currentResourceCount,
  };

  try {
    const resp = await fetch('/history/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        module_type: 'deadlock',
        algorithm: "Banker's Algorithm",
        parameters: {
          allocation: lastSimulationResult.allocation,
          maximum: lastSimulationResult.maximum,
          available: lastSimulationResult.available,
        },
        results: {
          is_safe: lastSimulationResult.is_safe,
          safe_sequence: lastSimulationResult.safe_sequence,
          steps_count: lastSimulationResult.steps.length,
        },
        summary_metrics: summaryMetrics,
        summary_text: lastSimulationResult.is_safe
          ? `Safe state (${lastSimulationResult.safe_sequence.join(' -> ')})`
          : 'Unsafe state (Deadlock potential)',
      }),
    });

    const res = await resp.json();
    if (resp.ok) {
      saveBtn.className = 'btn btn-success';
      saveBtn.innerHTML = '<i class="bi bi-check-lg me-1"></i>Saved!';
      alert('Deadlock simulation saved to History! (ID: #' + res.id + ')');
      setTimeout(() => {
        saveBtn.className = 'btn btn-outline-secondary';
        saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
        saveBtn.disabled = false;
      }, 2500);
    } else {
      alert(res.error || 'Failed to save to history');
      saveBtn.disabled = false;
      saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
    }
  } catch (err) {
    saveBtn.disabled = false;
    saveBtn.innerHTML = '<i class="bi bi-save me-1"></i>Save';
  }
}
